import {test} from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {spawn} from 'node:child_process';
import {DatabaseSync} from 'node:sqlite';
import {fileURLToPath} from 'node:url';
import {fetchCapped,configureSourcePolicy} from '../deployment/widget-hub/worker.js';
import {addressAllowed,createPinnedFetch} from './egress.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const SERVER=path.join(here,'server.mjs');

test('addressAllowed: strict mode blocks private, loopback, link-local, mapped and ULA addresses',()=>{
  for(const a of ['127.0.0.1','10.1.2.3','172.20.0.1','192.168.1.5','100.64.0.1','169.254.169.254','0.0.0.0','224.0.0.1','::1','::','fe80::1','fc00::1','fd12::1','ff02::1','::ffff:127.0.0.1','::ffff:192.168.1.5','not-an-ip'])
    assert.equal(addressAllowed(a,false),false,a);
  for(const a of ['8.8.8.8','1.1.1.1','2606:4700:4700::1111','::ffff:8.8.8.8'])assert.equal(addressAllowed(a,false),true,a);
});
test('addressAllowed: relaxed mode allows LAN but still blocks metadata, 0.x, multicast, link-local',()=>{
  for(const a of ['127.0.0.1','10.1.2.3','192.168.1.5','::1','fd12::1'])assert.equal(addressAllowed(a,true),true,a);
  for(const a of ['169.254.169.254','0.0.0.0','224.0.0.1','fe80::1','::ffff:169.254.169.254'])assert.equal(addressAllowed(a,true),false,a);
});

function localServer(){return new Promise(r=>{const s=http.createServer((q,res)=>{res.writeHead(200,{'content-type':'text/plain'});res.end('hello '+q.headers.host);}).listen(0,'127.0.0.1',()=>r(s));});}

test('pinned fetch: domain resolving to a private IP is refused by default (DNS rebinding)',async()=>{
  const s=await localServer();const port=s.address().port;
  try{
    const f=createPinnedFetch({},{lookup:(h,cb)=>cb(null,[{address:'127.0.0.1',family:4}])});
    await assert.rejects(f('http://evil.example:'+port+'/x'),e=>e.code==='EBLOCKED');
    const f2=createPinnedFetch({},{lookup:(h,cb)=>cb(null,[{address:'10.0.0.5',family:4},{address:'169.254.169.254',family:4}])});
    await assert.rejects(f2('http://evil.example:'+port+'/x'),e=>e.code==='EBLOCKED');
    await assert.rejects(f('http://127.0.0.1:'+port+'/x'),e=>e.code==='EBLOCKED');   // literal IP
  }finally{s.close();}
});
test('pinned fetch: trusted origin or SOURCE_ADDRESS_CHECK=false reaches LAN, but never metadata',async()=>{
  const s=await localServer();const port=s.address().port;
  try{
    const lk=(h,cb)=>cb(null,[{address:'127.0.0.1',family:4}]);
    const trusted=createPinnedFetch({TRUSTED_SOURCE_ORIGINS:'http://nas.lan:'+port},{lookup:lk});
    const r=await trusted('http://nas.lan:'+port+'/x');assert.equal(r.status,200);assert.match(await r.text(),/^hello nas\.lan/);
    await assert.rejects(trusted('http://other.lan:'+port+'/x'),e=>e.code==='EBLOCKED');   // not on the list
    const open=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'},{lookup:lk});
    assert.equal((await open('http://any.lan:'+port+'/x')).status,200);
    const meta=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'},{lookup:(h,cb)=>cb(null,[{address:'169.254.169.254',family:4}])});
    await assert.rejects(meta('http://metadata.example/x'),e=>e.code==='EBLOCKED');
  }finally{s.close();}
});
test('pinned fetch: abort signal cancels',async()=>{
  const s=http.createServer(()=>{}).listen(0,'127.0.0.1');await new Promise(r=>s.once('listening',r));
  try{
    const f=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'});
    await assert.rejects(f('http://127.0.0.1:'+s.address().port+'/',{signal:AbortSignal.timeout(200)}));
  }finally{s.closeAllConnections?.();s.close();}
});

// ---- 启动前检查(子进程跑真实的 server.mjs) ----
function start(env){
  const child=spawn(process.execPath,['--disable-warning=ExperimentalWarning',SERVER],{env:{...process.env,ADMIN_SECRET:'x',ASSET_DIR:path.join(here,'..','deployment','widget-hub','public'),...env},stdio:['ignore','pipe','pipe']});
  let out='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>out+=d);
  const wait=(re,ms=8000)=>new Promise((res,rej)=>{const t=setTimeout(()=>rej(new Error('timeout; output:\n'+out)),ms);const iv=setInterval(()=>{if(re.test(out)){clearTimeout(t);clearInterval(iv);res(out);}},50);});
  return {child,wait,out:()=>out,stop:()=>new Promise(r=>{child.once('exit',r);child.kill('SIGTERM');setTimeout(()=>child.kill('SIGKILL'),5000);})};
}
const tmp=()=>fs.mkdtempSync(path.join(os.tmpdir(),'hubt-'));
const freePort=()=>new Promise(r=>{const s=http.createServer().listen(0,()=>{const p=s.address().port;s.close(()=>r(p));});});
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

test('preflight: foreign SQLite or non-SQLite hub.db is left untouched and the server does not start',async()=>{
  for(const make of [d=>{const c=new DatabaseSync(path.join(d,'hub.db'));c.exec('create table foo(a)');c.close();},d=>fs.writeFileSync(path.join(d,'hub.db'),'garbage garbage garbage')]){
    const data=tmp(),backup=tmp();make(data);const before=sha(path.join(data,'hub.db'));
    const p=start({DATA_DIR:data,BACKUP_DIR:backup,PORT:String(await freePort())});
    try{await p.wait(/认不出旧库格式/);assert.doesNotMatch(p.out(),/listening/);}finally{await p.stop();}
    assert.equal(sha(path.join(data,'hub.db')),before);
    assert.deepEqual(fs.readdirSync(backup),[]);
    assert.deepEqual(fs.readdirSync(data).sort(),['hub.db']);   // no WAL/kv files created
  }
});
test('preflight: valid DB is backed up (baseline first, no duplicate when unchanged); /healthz works',async()=>{
  const data=tmp(),backup=tmp(),port=await freePort();
  let p=start({DATA_DIR:data,BACKUP_DIR:backup,PORT:String(port)});
  try{await p.wait(/listening/);}finally{await p.stop();}   // first run creates a fresh DB, nothing to back up
  assert.deepEqual(fs.readdirSync(backup),[]);
  p=start({DATA_DIR:data,BACKUP_DIR:backup,PORT:String(port)});   // second run: existing DB gets backed up as baseline
  try{
    await p.wait(/listening/);
    assert.deepEqual(fs.readdirSync(backup),['baseline']);
    assert.ok(fs.existsSync(path.join(backup,'baseline','hub.db')));
    const r=await fetch('http://127.0.0.1:'+port+'/healthz');assert.equal(r.status,200);assert.equal(await r.text(),'ok');
  }finally{await p.stop();}
});
test('preflight: unwritable backup location refuses to start; data unchanged',async()=>{
  const data=tmp(),port=await freePort();
  let p=start({DATA_DIR:data,BACKUP_DIR:tmp(),PORT:String(port)});try{await p.wait(/listening/);}finally{await p.stop();}
  const file=path.join(tmp(),'iamafile');fs.writeFileSync(file,'x');   // BACKUP_DIR below a regular file can never be created
  const before=sha(path.join(data,'hub.db'));
  p=start({DATA_DIR:data,BACKUP_DIR:path.join(file,'sub'),PORT:String(port)});
  try{await p.wait(/备份失败/);assert.doesNotMatch(p.out(),/listening/);}finally{await p.stop();}
  assert.equal(sha(path.join(data,'hub.db')),before);
});

test('pinned fetch: decompresses gzip/deflate/br responses like the built-in fetch',async()=>{
  const text='模块代码 '.repeat(200);
  const s=http.createServer((q,res)=>{
    const enc=q.url.slice(1);const raw=Buffer.from(text);
    const out=enc==='gzip'?zlib.gzipSync(raw):enc==='deflate'?zlib.deflateSync(raw):enc==='br'?zlib.brotliCompressSync(raw):raw;
    res.writeHead(200,enc==='plain'?{}:{'content-encoding':enc,'content-length':out.length});res.end(out);
  }).listen(0,'127.0.0.1');await new Promise(r=>s.once('listening',r));
  try{
    const f=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'});
    for(const enc of ['gzip','deflate','br','plain']){
      const r=await f('http://127.0.0.1:'+s.address().port+'/'+enc);
      assert.equal(await r.text(),text,enc);
      assert.equal(r.headers.get('content-encoding'),null,enc);
    }
  }finally{s.close();}
});

test('pinned fetch + fetchCapped: endless response is cut at the size cap and the connection is closed',async t=>{
  let closed=false;
  const s=http.createServer((q,res)=>{res.writeHead(200);const iv=setInterval(()=>res.write(Buffer.alloc(16384)),1);res.on('close',()=>{closed=true;clearInterval(iv);});}).listen(0,'127.0.0.1');
  await new Promise(r=>s.once('listening',r));
  const orig=globalThis.fetch;globalThis.fetch=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'});configureSourcePolicy({check:'false'});
  try{
    await assert.rejects(fetchCapped('http://127.0.0.1:'+s.address().port+'/',100000),/文件过大/);
    await new Promise(r=>setTimeout(r,300));assert.equal(closed,true);
  }finally{configureSourcePolicy({});globalThis.fetch=orig;s.closeAllConnections?.();s.close();}
});
test('pinned fetch: IPv4 addresses are preferred over IPv6',async()=>{
  const s=await localServer();const port=s.address().port;
  try{
    const f=createPinnedFetch({SOURCE_ADDRESS_CHECK:'false'},{lookup:(h,cb)=>cb(null,[{address:'::1',family:6},{address:'127.0.0.1',family:4}])});
    assert.equal((await f('http://dual.example:'+port+'/')).status,200);
  }finally{s.close();}
});

test('preflight: a volume holding the other Docker implementation\'s rex.sqlite is refused and no empty hub.db is created',async()=>{
  const data=tmp(),backup=tmp();
  const c=new DatabaseSync(path.join(data,'rex.sqlite'));c.exec('create table settings(key text primary key,value text);create table modules(id text)');c.close();
  const before=sha(path.join(data,'rex.sqlite'));
  const p=start({DATA_DIR:data,BACKUP_DIR:backup,PORT:String(await freePort())});
  try{await p.wait(/rex\.sqlite/);assert.doesNotMatch(p.out(),/listening/);}finally{await p.stop();}
  assert.equal(sha(path.join(data,'rex.sqlite')),before);
  assert.deepEqual(fs.readdirSync(data).sort().filter(n=>!n.startsWith('rex.sqlite')),[]);   // no hub.db / kv.db created
  assert.deepEqual(fs.readdirSync(backup),[]);
});
