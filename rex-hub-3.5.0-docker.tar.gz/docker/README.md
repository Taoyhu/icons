# Docker 运行方式(与 Cloudflare 版同一份代码)

`docker/server.mjs` 在 Node.js 22 上直接加载 `deployment/widget-hub/worker.js`,用本地文件模拟 Cloudflare 的三样东西:
D1 → `data/hub.db`(node:sqlite)、KV → `data/kv.db`、Durable Object → 进程内单例;定时任务每分钟触发一次。
功能、接口、备份格式(format 7)与 CF 版完全一致,以后改一份代码两边同步。

## 启动
```
echo "ADMIN_SECRET=换成强密码" > docker/.env
docker compose -f docker/compose.yaml up -d --build
```
默认端口 8083。数据都在卷 `rex-data-v3`(`/app/data`),备份就是备份这个卷,或用网页「设置」里的完整备份。

## 环境变量
| 变量 | 说明 |
|---|---|
| `ADMIN_SECRET`(或 `ADMIN_PASSWORD`) | 首次启动密码;库里已有后台密码时以库为准 |
| `PUBLIC_URL` | 生成订阅链接用的对外地址;留空则用请求的 Host |
| `TRUST_PROXY` | 反向代理后设为 true |
| `SOURCE_ADDRESS_CHECK` | 设为 false 允许内网/局域网来源(仍拒绝 169.254.x.x、0.x、组播);默认 true |
| `TRUSTED_SOURCE_ORIGINS` | 逗号分隔的可信 origin,如 `http://192.168.1.5:8080`;命中则允许 |
| `DISABLE_SCHEDULER` | true 则不跑每六小时的订阅检查 |
| `PORT` / `DATA_DIR` | 容器内端口(默认 8080)/ 数据目录(默认 /app/data) |

## 与另一套 Docker 实现的关系(重要)
还有一套独立的 Docker 实现(`server.js`、`storage.js`,发行包名如 `Rex-Widgets-Hub-docker-v3.x`),它把**全部数据放在单个文件 `rex.sqlite`**,升级自带快照和离线恢复工具。本目录这套把数据放在**两个文件** `hub.db` 和 `kv.db`,两者**不能共用同一个数据卷**。
- 已经在用那套(数据卷里有 `rex.sqlite`)的,继续用它自己的发行包升级,**不要**把本版指到那个卷。
- 本版启动时一发现数据目录里有 `rex.sqlite`,就报错、不修改数据、不新建空库,30 秒后退出。
- 想从那套换到本版:在旧站「设置」导出完整备份 → 换一个全新的数据卷 → 在新站「设置 → 恢复」导入。导入前不要删旧容器和旧卷。

## 已验证 / 未验证
已在本机用 `node docker/server.mjs` 实测:登录与限流、上传预览并提交、建合集、`.rex` 订阅输出、完整备份导出、重启后数据与密码保留。
**未验证**:`docker build` 和容器内运行(本环境无法拉取基础镜像)、旧备份导入、Rex 真机导入、订阅同步访问外网。

## 启动前检查与备份(`hub.db` / `kv.db`)
- `hub.db` 不是 SQLite、或缺 `modules`/`settings` 表时,不打开、不修改数据,日志报错,等 30 秒后以退出码 3 退出(避免 `restart: unless-stopped` 刷屏)。认得出就先把 `hub.db`、`kv.db`(含 `-wal`/`-shm`)复制到 `BACKUP_DIR`(默认 `/app/backup`),保留最近 `BACKUP_KEEP`=5 份。数据与已有备份完全相同时跳过;第一份放在 `baseline/`,永不自动删除。备份失败也不启动。
- 备份放在单独的卷 `rex-backup-v3`(`/app/backup`),不在数据卷里;该卷继承镜像里 `node` 的属主,不需要手动授权。改成挂宿主机目录时,目录必须对容器内用户 `node`(uid 1000)可写,否则会因「备份失败」不启动。
- 反代后 `TRUST_PROXY=true` 时,客户端 IP 取 `X-Forwarded-For` 的最后一项(反代追加的那项);反代必须追加或覆盖该头。
- 未验证:`docker build`(本环境没有 Docker 服务)。

### 还原(出问题时)
先用 `docker volume ls` 确认两个卷的实际名字(compose 会加项目名前缀,下面的 `<数据卷>`、`<备份卷>` 换成实际名字)。
```
docker compose -f docker/compose.yaml down
# 备份卷里有 baseline(第一份)和 pre-start-<时间>;下面用 baseline,换成要还原的那份
docker run --rm -v <数据卷>:/app/data -v <备份卷>:/app/backup alpine \
  sh -c 'rm -f /app/data/hub.db* /app/data/kv.db* && cp /app/backup/baseline/hub.db* /app/backup/baseline/kv.db* /app/data/ 2>/dev/null; chown -R 1000:1000 /app/data'
docker compose -f docker/compose.yaml up -d
```
还原会覆盖当前数据,先确认选对备份。

### 其他保护
- **出站防 DNS 重绑定**(`docker/egress.mjs`):抓取订阅/模块时先解析域名,逐个检查结果 IP,只用通过检查的 IP 连接。默认拒绝内网/本机/CGNAT/IPv6 本地段;`SOURCE_ADDRESS_CHECK=false` 或可信 origin 放行内网后仍拒绝 169.254.x.x、0.x、组播、IPv6 链路本地。
- **健康检查** `GET /healthz`:真实查询一次 hub.db 和 kv.db,失败返回 503。
- **请求超时** 默认 10 分钟(`REQUEST_TIMEOUT_MS`);**优雅停止**会等进行中的请求(最多 50 秒)再退出。
- **固定 Node 版本**:`.env` 里写 `NODE_IMAGE=node:22.xx-alpine`(先确认该标签存在)。`node:sqlite` 在 Node 22 仍是实验功能,升级大版本前先跑 `npm test`。
- **构建烟雾测试**:在能拉取基础镜像的机器上 `bash scripts/docker-smoke.sh`(用临时卷,不碰现有数据)。
- `npm test` 现在包含 `docker/docker.test.mjs`:出站防护、认不出旧库时不动数据、备份、`/healthz`。
