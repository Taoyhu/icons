// Runs the unmodified Cloudflare Worker (deployment/widget-hub/worker.js) on plain Node.js.
// D1 -> node:sqlite, KV -> a second SQLite file, Durable Object -> one in-process instance,
// ASSETS -> static folder, Cron -> setInterval. One codebase, two runtimes.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import crypto from 'node:crypto';
import {createGzip,gzipSync} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import application, {HubCoordinator, configureSourcePolicy} from '../deployment/widget-hub/worker.js';
configureSourcePolicy({check:process.env.SOURCE_ADDRESS_CHECK,trusted:process.env.TRUSTED_SOURCE_ORIGINS});


import {createPinnedFetch} from './egress.mjs';
globalThis.fetch=createPinnedFetch(process.env);

const here=path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR=process.env.DATA_DIR||path.join(here,'..','data');
const PORT=Number(process.env.PORT||8080);
const TRUST_PROXY=/^(1|true|yes)$/i.test(process.env.TRUST_PROXY||'');
const PUBLIC_URL=(process.env.PUBLIC_URL||'').replace(/\/+$/,'');
const ASSET_DIR=process.env.ASSET_DIR||path.join(here,'..','deployment','widget-hub','public');
fs.mkdirSync(DATA_DIR,{recursive:true});

// ---------- 启动前检查旧库并备份(NAS 沿用旧数据卷用) ----------
// 认不出格式就停下,不碰数据;认得出就先把 hub.db / kv.db(含 -wal/-shm)复制到 BACKUP_DIR,再打开。
const BACKUP_DIR=process.env.BACKUP_DIR||'/app/backup';
const BACKUP_KEEP=Math.max(1,Number(process.env.BACKUP_KEEP||5));
function haltWith(msg){
  console.error('[preflight] '+msg);console.error('[preflight] 数据未被修改。等待 30 秒后退出,避免重启循环刷屏。');
  setTimeout(()=>process.exit(3),30000);
  return new Promise(()=>{});
}
await (async function preflight(){
  // 另一套 Docker 实现(server.js,Docker v3.x)把全部数据放在单个 rex.sqlite;本版用 hub.db + kv.db,两者不能共用同一数据卷。
  // 不在这里提示就会在同一个卷里悄悄新建一个空库。
  for(const other of ['rex.sqlite','rex.sqlite-wal']){
    const f=path.join(DATA_DIR,other);
    if(fs.existsSync(f)&&fs.statSync(f).size>0)return haltWith('数据目录里有 '+other+':这是另一套 Docker 实现(单文件 rex.sqlite,server.js)的数据,本版使用 hub.db 和 kv.db,不能共用。请继续用原来的那套 Docker 版升级;要换到本版,先在旧站「设置」导出完整备份,换新的数据卷,再在新站「设置 → 恢复」导入。');
  }
  const hub=path.join(DATA_DIR,'hub.db');
  if(!fs.existsSync(hub)||fs.statSync(hub).size===0)return;
  const fd=fs.openSync(hub,'r'),head=Buffer.alloc(16);fs.readSync(fd,head,0,16,0);fs.closeSync(fd);
  if(head.toString('latin1')!=='SQLite format 3\0')return haltWith('hub.db 不是 SQLite 文件,认不出旧库格式。请在旧站导出完整备份,改用新数据卷后在新站「设置 → 恢复」导入。');
  let tables;
  try{
    const probe=new DatabaseSync(hub,{readOnly:true});
    tables=new Set(probe.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r=>r.name));probe.close();
  }catch(e){return haltWith('无法只读打开 hub.db:'+e.message);}
  if(tables.size&&!(tables.has('modules')&&tables.has('settings')))return haltWith('hub.db 里没有 Rex Hub 的 modules/settings 表(现有表:'+[...tables].join(',')+'),认不出旧库格式。');
  try{
    const files=['hub.db','hub.db-wal','hub.db-shm','kv.db','kv.db-wal','kv.db-shm'].filter(f=>fs.existsSync(path.join(DATA_DIR,f)));
    const hash=crypto.createHash('sha256');for(const f of files){hash.update(f+'\0');hash.update(fs.readFileSync(path.join(DATA_DIR,f)));}
    const digest=hash.digest('hex');
    fs.mkdirSync(BACKUP_DIR,{recursive:true});
    const existing=fs.readdirSync(BACKUP_DIR).filter(n=>n.startsWith('pre-start-')||n==='baseline').sort();
    const sameAsAny=existing.some(n=>{try{return fs.readFileSync(path.join(BACKUP_DIR,n,'.digest'),'utf8').trim()===digest;}catch{return false;}});
    if(sameAsAny){console.log('[preflight] 数据与已有备份相同,跳过备份');return;}
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    // 第一份(首次接管旧卷时的原样)放进 baseline,永不轮替删除;之后的放 pre-start-*,只保留最近 BACKUP_KEEP 份。
    const dest=path.join(BACKUP_DIR,fs.existsSync(path.join(BACKUP_DIR,'baseline'))?'pre-start-'+stamp:'baseline');
    fs.mkdirSync(dest,{recursive:true});
    for(const f of files)fs.copyFileSync(path.join(DATA_DIR,f),path.join(dest,f));
    fs.writeFileSync(path.join(dest,'.digest'),digest);
    const dirs=fs.readdirSync(BACKUP_DIR).filter(n=>n.startsWith('pre-start-')).sort();
    for(const d of dirs.slice(0,Math.max(0,dirs.length-BACKUP_KEEP)))fs.rmSync(path.join(BACKUP_DIR,d),{recursive:true,force:true});
    console.log('[preflight] 已备份到 '+dest);
  }catch(e){return haltWith('备份失败,为安全起见不启动:'+e.message+(/EACCES|EPERM|EROFS/.test(e.code||'')?'。备份目录 '+BACKUP_DIR+' 不可写:容器内用户是 node(uid 1000),请让该目录对它可写(例如给宿主机目录 chown 1000:1000,或改用 Docker 具名卷)。':''));}
})();

// ---------- D1 ----------
const sql=new DatabaseSync(path.join(DATA_DIR,'hub.db'));
sql.exec('PRAGMA journal_mode=WAL;PRAGMA synchronous=NORMAL;PRAGMA busy_timeout=5000;PRAGMA foreign_keys=OFF;');
const isRead=q=>/^\s*(select|with|pragma)\b/i.test(q);
function statement(query){
  // Compile lazily like D1: a batch may reference a table created by an earlier statement in the same batch.
  let compiled=null;const stmt=()=>compiled||(compiled=sql.prepare(query));let args=[];
  const norm=a=>a.map(v=>v===undefined?null:typeof v==='boolean'?(v?1:0):v);
  const self={
    bind(...a){args=norm(a);return self;},
    async first(){return stmt().get(...args)||null;},
    async all(){return {results:stmt().all(...args),meta:{}};},
    async run(){const r=stmt().run(...args);return {results:[],meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};},
    _exec(){if(isRead(query))return {results:stmt().all(...args),meta:{}};const r=stmt().run(...args);return {results:[],meta:{changes:Number(r.changes)}};}
  };
  return self;
}
const DB={
  prepare:statement,
  async batch(list){sql.exec('BEGIN IMMEDIATE');try{const out=list.map(s=>s._exec());sql.exec('COMMIT');return out;}catch(e){try{sql.exec('ROLLBACK');}catch{}throw e;}},
  async exec(q){sql.exec(q);return {count:1};}
};

// ---------- KV ----------
const kv=new DatabaseSync(path.join(DATA_DIR,'kv.db'));
kv.exec('PRAGMA journal_mode=WAL;PRAGMA synchronous=NORMAL;PRAGMA busy_timeout=5000;CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v BLOB NOT NULL,meta TEXT,exp INTEGER)');
const kvGet=kv.prepare('SELECT v,meta,exp FROM kv WHERE k=?'),kvPut=kv.prepare('INSERT OR REPLACE INTO kv(k,v,meta,exp) VALUES(?,?,?,?)'),
  kvDel=kv.prepare('DELETE FROM kv WHERE k=?'),kvSweep=kv.prepare('DELETE FROM kv WHERE exp IS NOT NULL AND exp<?');
function kvRow(key){const r=kvGet.get(String(key));if(!r)return null;if(r.exp&&r.exp<Date.now()){kvDel.run(String(key));return null;}return r;}
const toBuf=v=>Buffer.from(v.buffer,v.byteOffset,v.byteLength);
function shape(row,type){
  const bytes=toBuf(row.v);
  if(type==='text')return bytes.toString('utf8');
  if(type==='json')return JSON.parse(bytes.toString('utf8'));
  if(type==='stream')return new Response(bytes).body;
  return bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);
}
const typeOf=t=>typeof t==='string'?t:t?.type||'text';
const KV={
  async get(key,type){const r=kvRow(key);return r?shape(r,typeOf(type)):null;},
  async getWithMetadata(key,type){const r=kvRow(key);return r?{value:shape(r,typeOf(type)),metadata:r.meta?JSON.parse(r.meta):null}:{value:null,metadata:null};},
  async put(key,value,options={}){
    let bytes;if(typeof value==='string')bytes=Buffer.from(value,'utf8');else if(value instanceof ArrayBuffer)bytes=Buffer.from(value);
    else if(ArrayBuffer.isView(value))bytes=Buffer.from(value.buffer,value.byteOffset,value.byteLength);else bytes=Buffer.from(await new Response(value).arrayBuffer());
    const exp=options.expirationTtl?Date.now()+options.expirationTtl*1000:options.expiration?options.expiration*1000:null;
    kvPut.run(String(key),bytes,options.metadata===undefined?null:JSON.stringify(options.metadata),exp);
  },
  async delete(key){kvDel.run(String(key));}
};
setInterval(()=>{try{kvSweep.run(Date.now());}catch(e){console.error('[kv-sweep]',e.message);}},10*60*1000).unref();

// ---------- ASSETS ----------
const TYPES={'.png':'image/png','.ico':'image/x-icon','.svg':'image/svg+xml','.json':'application/json','.webmanifest':'application/manifest+json'};
const ASSETS={async fetch(request){
  const rel=decodeURIComponent(new URL(request.url).pathname).replace(/^\/+/,'');
  const file=path.resolve(ASSET_DIR,rel);
  if(!file.startsWith(path.resolve(ASSET_DIR)+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile())return new Response('Not found',{status:404});
  return new Response(request.method==='HEAD'?null:fs.readFileSync(file),{headers:{'Content-Type':TYPES[path.extname(file)]||'application/octet-stream'}});
}};

// ---------- Durable Object (single in-process instance) ----------
const background=new Set();
const ctx={waitUntil(p){const t=Promise.resolve(p).catch(e=>console.error('[waitUntil]',e?.message||e)).finally(()=>background.delete(t));background.add(t);},passThroughOnException(){}};
const env={DB,KV,ASSETS,
  ADMIN_PASSWORD:process.env.ADMIN_PASSWORD||process.env.ADMIN_SECRET||'',
  SOURCE_ADDRESS_CHECK:process.env.SOURCE_ADDRESS_CHECK,TRUSTED_SOURCE_ORIGINS:process.env.TRUSTED_SOURCE_ORIGINS};
let instance=null;
env.COORDINATOR={idFromName:n=>n,get:()=>instance||(instance=new HubCoordinator(ctx,env))};

// ---------- [优化2/3] 响应压缩与进程内版本化缓存 ----------
// 弱比较版 ETag 匹配（与 worker 内 A1 口径一致：忽略 W/ 前缀、支持列表与 *）。
function etagMatches(header,etag){
  if(!header||!etag)return false;
  const norm=v=>String(v).trim().replace(/^W\//,'');
  const want=norm(etag);
  return String(header).split(',').some(t=>{const v=t.trim();return v==='*'||norm(v)===want;});
}
function gzipApplies(req,headers,status,method){
  if(method==='HEAD'||status===204||status===304)return false;
  if(headers['content-encoding'])return false;
  if(!/\bgzip\b/.test(String(req.headers['accept-encoding']||'')))return false;
  const type=String(headers['content-type']||'').split(';')[0].trim().toLowerCase();
  return type.startsWith('text/')||type==='application/javascript'||type==='text/javascript'
    ||type==='application/json'||type==='application/manifest+json'||type==='image/svg+xml';
}
// 整份正文发送（缓存命中与可缓存响应走这里）：够大且是文本类就 gzip。
function sendBuffer(res,status,headers,body,req){
  const out={...headers};
  if(body.length>=1024&&gzipApplies(req,out,status,req.method)){
    delete out['content-length'];out['content-encoding']='gzip';
    out.vary=out.vary?out.vary+', Accept-Encoding':'Accept-Encoding';
    res.writeHead(status,out);res.end(gzipSync(body));return;
  }
  out['content-length']=String(body.length);
  res.writeHead(status,out);res.end(body);
}
// 只缓存公开 GET：合集清单、模块文件、直达链接与图标。键为完整 URL，条目绑定
// 响应 ETag；命中后拿 ETag 向 worker 发条件请求校验，内容变了自然换新条目。
const CACHE_MAX_BYTES=64*1024*1024;
const memCache=new Map();let memCacheBytes=0;
function cacheablePath(p){
  if(!p||p.startsWith('/api/admin/'))return false;
  return /^\/api\/collections\/[^/]+\.(?:rex|fwd)$/.test(p)
    ||/^\/api\/modules\/[^/]+\/file\/[^/]+$/.test(p)
    ||/^\/api\/modules\/[^/]+\.js$/.test(p)
    ||/^\/api\/icons\/[a-f0-9]{64}\.(?:png|jpg|webp)$/.test(p)
    ||/^\/[a-f0-9-]{36}(?:\.js)?$/.test(p);
}
function cacheGet(key){
  const e=memCache.get(key);if(!e)return undefined;
  memCache.delete(key);memCache.set(key,e);return e;
}
function cachePut(key,entry){
  if(entry.body.length>CACHE_MAX_BYTES)return;
  const old=memCache.get(key);if(old)memCacheBytes-=old.body.length;
  memCache.set(key,entry);memCacheBytes+=entry.body.length;
  while(memCacheBytes>CACHE_MAX_BYTES&&memCache.size>1){
    const k=memCache.keys().next().value;memCacheBytes-=memCache.get(k).body.length;memCache.delete(k);
  }
}

// ---------- HTTP ----------
function originOf(req){
  if(PUBLIC_URL)return PUBLIC_URL;
  const proto=TRUST_PROXY&&req.headers['x-forwarded-proto']?String(req.headers['x-forwarded-proto']).split(',')[0].trim():'http';
  const host=TRUST_PROXY&&req.headers['x-forwarded-host']?String(req.headers['x-forwarded-host']).split(',')[0].trim():req.headers.host||'localhost';
  return proto+'://'+host;
}
function clientIp(req){
  if(TRUST_PROXY){const f=req.headers['x-forwarded-for'];if(f)return String(f).split(',').pop().trim();const r=req.headers['x-real-ip'];if(r)return String(r);}
  return req.socket.remoteAddress||'unknown';
}
let inflight=0;
const server=http.createServer(async(req,res)=>{
  if(req.url==='/healthz'||req.url==='/healthz/'){
    try{sql.prepare('SELECT 1').get();kv.prepare('SELECT 1').get();res.writeHead(200,{'content-type':'text/plain'});res.end('ok');}
    catch(e){res.writeHead(503,{'content-type':'text/plain'});res.end('db error');}
    return;
  }
  inflight++;res.on('close',()=>{inflight--;});
  try{
    const headers=new Headers();
    for(const [k,v] of Object.entries(req.headers)){if(['host','connection','transfer-encoding'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>headers.append(k,x));else if(v!==undefined)headers.set(k,v);}
    headers.delete('cf-connecting-ip');headers.set('cf-connecting-ip',clientIp(req));
    const hasBody=!['GET','HEAD'].includes(req.method);
    // [优化3] 缓存判定：公开 GET、无鉴权/Cookie/Range 才参与；其余请求原样转发。
    let reqPath='';try{reqPath=new URL(req.url,'http://internal').pathname;}catch{reqPath='';}
    const mayCache=req.method==='GET'&&!req.headers.authorization&&!req.headers.cookie&&!req.headers.range&&cacheablePath(reqPath);
    const urlStr=originOf(req)+req.url;
    const cached=mayCache?cacheGet(urlStr):undefined;
    const clientInm=req.headers['if-none-match'];
    if(cached&&clientInm&&etagMatches(clientInm,cached.etag)){
      const out={...cached.headers};delete out['content-length'];delete out['content-encoding'];
      res.writeHead(304,out);res.end();return;
    }
    // 客户端没带条件头时，用缓存 ETag 向 worker 校验；客户端带了就原样透传给它自己的校验。
    if(cached&&!clientInm)headers.set('if-none-match',cached.etag);
    const request=new Request(urlStr,{method:req.method,headers,body:hasBody?req:undefined,duplex:hasBody?'half':undefined});
    const response=await application.fetch(request,env,ctx);
    const out={};response.headers.forEach((v,k)=>{out[k]=v;});
    const cookies=response.headers.getSetCookie?.();if(cookies?.length)out['set-cookie']=cookies;
    // [优化3] 校验命中：缓存正文就是当前版本，按 200 发回（省去 worker 再读文件）。
    if(cached&&!clientInm&&response.status===304){
      try{await response.body?.cancel();}catch{}
      sendBuffer(res,200,{...cached.headers},cached.body,req);
      return;
    }
    const respEtag=response.headers.get('etag')||'';
    const storeCandidate=!!(mayCache&&response.status===200&&respEtag&&!(cookies&&cookies.length)
      &&!/no-store|private/i.test(response.headers.get('cache-control')||''));
    if(storeCandidate||(cached&&response.status===200)){
      const body=Buffer.from(await response.arrayBuffer());
      if(storeCandidate)cachePut(urlStr,{etag:respEtag,headers:{...out},body});
      sendBuffer(res,response.status,out,body,req);
      return;
    }
    // [优化2] 其余响应保持流式转发，文本类按 Accept-Encoding 做 gzip。
    const gz=gzipApplies(req,out,response.status,req.method);
    if(gz){delete out['content-length'];out['content-encoding']='gzip';out.vary=out.vary?out.vary+', Accept-Encoding':'Accept-Encoding';}
    res.writeHead(response.status,out);
    if(!response.body||req.method==='HEAD'){res.end();return;}
    const reader=response.body.getReader();
    if(gz){
      const zs=createGzip();zs.pipe(res);
      for(;;){const {done,value}=await reader.read();if(done)break;if(!zs.write(value))await new Promise(r=>zs.once('drain',r));}
      zs.end();return;
    }
    for(;;){const {done,value}=await reader.read();if(done)break;if(!res.write(value))await new Promise(r=>res.once('drain',r));}
    res.end();
  }catch(e){console.error('[http]',e);if(!res.headersSent)res.writeHead(500,{'content-type':'application/json'});res.end(JSON.stringify({error:'服务器内部错误'}));}
});
server.requestTimeout=Number(process.env.REQUEST_TIMEOUT_MS||600000);server.headersTimeout=65000;server.keepAliveTimeout=30000;

// ---------- Cron ----------
let ticking=false;
const tick=async()=>{if(ticking||/^(1|true)$/i.test(process.env.DISABLE_SCHEDULER||''))return;ticking=true;
  try{await application.scheduled({},env,ctx);}catch(e){console.error('[cron]',e.message);}finally{ticking=false;}};
const timer=setInterval(tick,60*1000);timer.unref();

server.listen(PORT,'0.0.0.0',()=>console.log('Rex Widgets Hub listening on :'+PORT+' data='+DATA_DIR));

// ---------- graceful stop ----------
let stopping=false;
async function stop(signal){
  if(stopping)return;stopping=true;console.log('[stop]',signal);clearInterval(timer);
  server.close();server.closeIdleConnections?.();
  const deadline=Date.now()+50000;
  while((background.size||inflight)&&Date.now()<deadline)await Promise.race([Promise.allSettled([...background]),new Promise(r=>setTimeout(r,500))]);
  try{sql.close();kv.close();}catch{}
  process.exit(0);
}
process.on('SIGTERM',()=>stop('SIGTERM'));process.on('SIGINT',()=>stop('SIGINT'));
