// 出站请求防护(仅 Docker 版):先解析域名、校验每个结果 IP,再用校验过的地址连接(防 DNS 重绑定)。
// worker.js 只检查主机名/字面 IP;域名解析到内网时会绕过。Cloudflare 自带出站隔离,不需要这层。
import http from 'node:http';
import https from 'node:https';
import dns from 'node:dns';
import net from 'node:net';
import zlib from 'node:zlib';

const mkList=subnets=>{const l=new net.BlockList();for(const [a,n,f] of subnets)l.addSubnet(a,n,f);return l;};
// 任何模式都拒绝:0.x、云元数据/链路本地、组播、保留段、IPv6 未指定/链路本地/组播
const ALWAYS_BLOCK=mkList([['0.0.0.0',8,'ipv4'],['169.254.0.0',16,'ipv4'],['224.0.0.0',4,'ipv4'],['240.0.0.0',4,'ipv4'],['fe80::',10,'ipv6'],['ff00::',8,'ipv6'],['::',128,'ipv6']]);
// 默认模式额外拒绝:内网、本机、CGNAT、IPv6 回环与 ULA
const PRIVATE_BLOCK=mkList([['10.0.0.0',8,'ipv4'],['127.0.0.0',8,'ipv4'],['172.16.0.0',12,'ipv4'],['192.168.0.0',16,'ipv4'],['100.64.0.0',10,'ipv4'],['::1',128,'ipv6'],['fc00::',7,'ipv6']]);

export function addressAllowed(addr,relaxed){
  const m=String(addr).toLowerCase().match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  const a=m?m[1]:String(addr);
  const fam=net.isIPv4(a)?'ipv4':net.isIPv6(a)?'ipv6':null;
  if(!fam)return false;
  if(ALWAYS_BLOCK.check(a,fam))return false;
  if(!relaxed&&PRIVATE_BLOCK.check(a,fam))return false;
  return true;
}

export function createPinnedFetch(env={},deps={}){
  const realFetch=deps.realFetch||globalThis.fetch;
  const resolve=deps.lookup||((host,cb)=>dns.lookup(host,{all:true},cb));
  const check=!/^(0|false|no|off)$/i.test(String(env.SOURCE_ADDRESS_CHECK||'true').trim());
  const trusted=String(env.TRUSTED_SOURCE_ORIGINS||'').split(/[\s,]+/).filter(Boolean).map(x=>{try{return new URL(x).origin;}catch{return '';}}).filter(Boolean);
  return function pinnedFetch(input,init={}){
    const url=new URL(typeof input==='string'?input:input.url||String(input));
    if(url.protocol!=='http:'&&url.protocol!=='https:')return realFetch(input,init);
    const relaxed=!check||trusted.includes(url.origin);
    // Node 对字面 IP 不会调用 lookup,所以在这里先直接校验
    const literal=url.hostname.replace(/^\[|\]$/g,'');
    if(net.isIP(literal)&&!addressAllowed(literal,relaxed))return Promise.reject(Object.assign(new Error('不允许的地址(受限 IP)'),{code:'EBLOCKED'}));
    const lookup=(host,opts,cb)=>{
      if(typeof opts==='function'){cb=opts;opts={};}
      const done=(err,list)=>{
        if(err)return cb(err);
        const ok=list.filter(x=>addressAllowed(x.address,relaxed)).sort((x,y)=>x.family-y.family);   // IPv4 优先:NAS 常没有 IPv6 路由
        if(!ok.length)return cb(Object.assign(new Error('不允许的地址(域名解析到受限 IP)'),{code:'EBLOCKED'}));
        if(opts&&opts.all)return cb(null,ok);
        cb(null,ok[0].address,ok[0].family);
      };
      const bare=String(host).replace(/^\[|\]$/g,'');
      if(net.isIP(bare))return done(null,[{address:bare,family:net.isIPv4(bare)?4:6}]);
      resolve(host,done);
    };
    return new Promise((resolveP,reject)=>{
      const signal=init.signal;
      if(signal?.aborted)return reject(signal.reason||new DOMException('Aborted','AbortError'));
      const mod=url.protocol==='https:'?https:http;
      const headers={};if(init.headers)new Headers(init.headers).forEach((v,k)=>{headers[k]=v;});
      if(!('user-agent' in headers))headers['user-agent']='Mozilla/5.0 (RexHub)';
      if(!('accept-encoding' in headers))headers['accept-encoding']='identity';
      const req=mod.request(url,{method:init.method||'GET',headers,lookup},res=>{
        const h=new Headers();for(const [k,v] of Object.entries(res.headers)){if(Array.isArray(v))v.forEach(x=>h.append(k,x));else if(v!==undefined)h.set(k,v);}
        const nobody=[204,205,304].includes(res.statusCode)||(res.statusCode>=100&&res.statusCode<200);
        // 即使请求了 identity,有些服务器仍会压缩;和 Node 自带 fetch 一样解压,并去掉 content-encoding/content-length
        const enc=String(res.headers['content-encoding']||'').toLowerCase().trim();
        const dec=enc==='gzip'||enc==='x-gzip'?zlib.createGunzip():enc==='deflate'?zlib.createInflate():enc==='br'?zlib.createBrotliDecompress():null;
        let src=res;
        if(dec&&!nobody){h.delete('content-encoding');h.delete('content-length');res.on('error',e=>dec.destroy(e));src=res.pipe(dec);}
        const body=nobody?null:new ReadableStream({
          start(c){src.on('data',d=>c.enqueue(new Uint8Array(d.buffer,d.byteOffset,d.byteLength)));src.on('end',()=>c.close());src.on('error',e=>c.error(e));},
          cancel(){res.destroy();if(src!==res)src.destroy();}
        });
        if(nobody)res.resume();
        const r=new Response(body,{status:res.statusCode,statusText:res.statusMessage,headers:h});
        Object.defineProperty(r,'url',{value:url.toString()});
        resolveP(r);
      });
      req.on('error',e=>reject(e.code==='EBLOCKED'?e:Object.assign(new TypeError('fetch failed'),{cause:e})));
      if(signal)signal.addEventListener('abort',()=>req.destroy(signal.reason||new DOMException('Aborted','AbortError')),{once:true});
      if(init.body!=null)req.end(typeof init.body==='string'||init.body instanceof Uint8Array?init.body:Buffer.from(init.body));else req.end();
    });
  };
}
