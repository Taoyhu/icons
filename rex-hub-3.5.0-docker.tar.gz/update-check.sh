#!/bin/sh
# Rex Hub 自动更新检查: 每天比对 GitHub 版本文件, 有新版就拉包重部署
DIR="$(cd "$(dirname "$0")" && pwd)"
VER_URL="https://raw.githubusercontent.com/Taoyhu/icons/main/rex-hub-version.txt"
LOG="$DIR/update.log"
fetch() { curl -fsSL "$1" 2>/dev/null || wget -qO- "$1" 2>/dev/null; }
REMOTE=$(fetch "$VER_URL")
NEW_VER=$(printf '%s' "$REMOTE" | sed -n '1p' | tr -d '\r')
NEW_URL=$(printf '%s' "$REMOTE" | sed -n '2p' | tr -d '\r')
CUR=$(cat "$DIR/VERSION" 2>/dev/null || echo "")
[ -n "$NEW_VER" ] && [ -n "$NEW_URL" ] || exit 0
[ "$NEW_VER" != "$CUR" ] || exit 0
echo "$(date) 发现新版本 $NEW_VER (当前 $CUR), 开始更新..." >> "$LOG"
TMP=$(mktemp -d) || exit 0
if fetch "$NEW_URL" > "$TMP/pkg.tar.gz" && tar -xzf "$TMP/pkg.tar.gz" -C "$TMP"; then
  cp -r "$TMP/deployment" "$TMP/docker" "$DIR/" 2>/dev/null
  cp "$TMP/install.sh" "$TMP/update-check.sh" "$DIR/" 2>/dev/null
  cd "$DIR" || exit 0
  if docker compose version >/dev/null 2>&1; then C="docker compose"; else C="docker-compose"; fi
  $C -f docker/compose.yaml up -d --build >> "$LOG" 2>&1
  echo "$NEW_VER" > "$DIR/VERSION"
  echo "$(date) 更新到 $NEW_VER 完成" >> "$LOG"
else
  echo "$(date) 更新 $NEW_VER 失败(下载或解包出错)" >> "$LOG"
fi
rm -rf "$TMP"
