#!/bin/sh
# Rex Hub Docker 一键部署 (iStoreOS) — 官方主包 3.5.0
set -u
cd "$(dirname "$0")" || exit 1
DIR=$(pwd)
echo "== Rex Hub 部署开始 =="
echo "目录: $DIR"
if ! command -v docker >/dev/null 2>&1; then echo "错误: 找不到 docker"; exit 1; fi
docker info >/dev/null 2>&1 || { echo "错误: docker 服务没在运行"; exit 1; }
if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose";
elif command -v docker-compose >/dev/null 2>&1; then COMPOSE="docker-compose";
else
  echo "未找到 docker compose, 正在下载独立版..."
  curl -fsSL -o /usr/bin/docker-compose "https://github.com/docker/compose/releases/download/v2.29.7/docker-compose-linux-x86_64" || wget -O /usr/bin/docker-compose "https://github.com/docker/compose/releases/download/v2.29.7/docker-compose-linux-x86_64"
  chmod +x /usr/bin/docker-compose
  COMPOSE="docker-compose"
fi
echo "compose: $COMPOSE"
if [ ! -f docker/.env ]; then
  SECRET=$(dd if=/dev/urandom bs=1 count=18 2>/dev/null | md5sum | cut -d' ' -f1)
  printf 'ADMIN_SECRET=%s\nHOST_PORT=8083\n' "$SECRET" > docker/.env
  echo "$SECRET" > ADMIN_SECRET.txt
  chmod 600 ADMIN_SECRET.txt docker/.env
  echo "已生成管理员密码"
else
  echo "docker/.env 已存在, 沿用现有管理员密码"
fi
echo "开始构建镜像(首次需要下载 Node 镜像, 约几分钟)..."
$COMPOSE -f docker/compose.yaml up -d --build
echo "等待服务起来..."
i=0; OK=0
while [ $i -lt 60 ]; do
  if curl -fs http://127.0.0.1:8083/healthz >/dev/null 2>&1 || wget -qO- http://127.0.0.1:8083/healthz >/dev/null 2>&1; then OK=1; break; fi
  i=$((i+1)); sleep 5
done
chmod +x update-check.sh 2>/dev/null || true
mkdir -p /etc/crontabs; touch /etc/crontabs/root
grep -q "update-check.sh" /etc/crontabs/root || echo "17 4 * * * $DIR/update-check.sh" >> /etc/crontabs/root
/etc/init.d/cron restart 2>/dev/null || true
echo ""
echo "==================== 部署结果 ===================="
if [ $OK -eq 1 ]; then echo "状态: 成功, 服务已在运行"; else echo "状态: 容器已启动, 健康检查暂未通过(可能还在初始化)"; fi
echo "访问地址: http://192.168.2.8:8083"
echo "管理员密码: $(cat ADMIN_SECRET.txt 2>/dev/null)"
echo "=================================================="
