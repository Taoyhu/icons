import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {uploadSchema} from './uploads.js';
import {subscriptionSchema} from './subscriptions.js';
import {runAutoDedupe,scanDuplicateModules,ignoreDuplicateGroup,clearDuplicateIgnores,keepOneDuplicate} from './duplicates.js';

function fixture(){
 const sql=new DatabaseSync(':memory:');sql.exec(`CREATE TABLE modules(id TEXT PRIMARY KEY,filename TEXT,widget_id TEXT,title TEXT,note TEXT,group_id TEXT,sort_order INTEGER,created_at INTEGER,updated_at INTEGER,file_key TEXT,source_url TEXT,version TEXT,author TEXT,file_size INTEGER,is_encrypted INTEGER DEFAULT 0,content_hash TEXT,required_version TEXT,source_managed INTEGER DEFAULT 0,manual_override INTEGER DEFAULT 0,metadata_id TEXT,code_title TEXT,manifest_title TEXT,title_locked INTEGER DEFAULT 0,generated_filename INTEGER DEFAULT 0,title_scan_v1 INTEGER DEFAULT 0);
 CREATE TABLE collections(id TEXT PRIMARY KEY,updated_at INTEGER,title TEXT,slug TEXT);
 CREATE TABLE groups(id TEXT PRIMARY KEY,name TEXT);
 CREATE TABLE collection_modules(collection_id TEXT,module_id TEXT,position INTEGER,PRIMARY KEY(collection_id,module_id));`);
 for(const s of [...uploadSchema,...subscriptionSchema])sql.exec(s);
 let fail=false;const DB={prepare(query){const s=sql.prepare(query);let a=[];return {bind(...args){a=args;return this;},async first(){return s.get(...a)||null;},async all(){return {results:s.all(...a)};},async run(){return {meta:{changes:Number(s.run(...a).changes)}};}};},async batch(list){if(fail){fail=false;throw Error('DB failure');}sql.exec('BEGIN');try{const out=[];for(const s of list)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const deleted=[];const env={DB,KV:{async delete(key){deleted.push(key);}}};
 for(const id of ['a','b','c','d'])sql.prepare('INSERT INTO modules (id,filename,widget_id,title,note,group_id,sort_order,created_at,updated_at,file_key,source_url) VALUES (?,?,?,?,?,?,?,?,?,?,NULL)').run(id,id+'.js','remote-'+id,'Title '+id,'note '+id,'',20,10,10,'upload-content:'+id);
 sql.exec("INSERT INTO collections VALUES ('mine',1,'Mine','mine');INSERT INTO groups VALUES ('group1','G1');INSERT INTO collection_modules VALUES ('mine','a',0)");
 return {env,sql,deleted,fail(){fail=true;}};
}

test('runAutoDedupe: preview deletes nothing; apply removes only the lower-version plaintext copy',async()=>{
 const f=fixture();
 // a,b: same plaintext id, v1 / v2.  c,d: same encrypted filename-ish content, no shared hash -> untouched
 f.sql.exec("UPDATE modules SET metadata_id='x.id',is_encrypted=0,content_hash=NULL");
 f.sql.exec("UPDATE modules SET version='1.0.0' WHERE id='a'");
 f.sql.exec("UPDATE modules SET version='2.0.0' WHERE id='b'");
 f.sql.exec("DELETE FROM collection_modules");
 f.sql.exec("UPDATE modules SET metadata_id='c.id' WHERE id='c'");
 f.sql.exec("UPDATE modules SET metadata_id='d.id' WHERE id='d'");
 const pre=await runAutoDedupe(f.env,{apply:false});
 assert.equal(pre.applied,false);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,4);
 if(pre.plan.length){
  assert.deepEqual(pre.plan[0].remove.map(x=>x.id),['a']);
  const r=await runAutoDedupe(f.env,{apply:true});
  assert.deepEqual(r.done.map(x=>x.id),['a']);assert.equal(r.failed.length,0);
  assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM modules WHERE id='a'").get().n,0);
  assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,3);
 }
 else assert.fail('expected a plan, got skipped='+JSON.stringify(pre.skipped));
});

const H='a'.repeat(64);
function twins(f){f.sql.exec("DELETE FROM collection_modules");f.sql.exec(`UPDATE modules SET content_hash='${H}',is_encrypted=0 WHERE id IN ('a','b')`);}
test('ignore group: hidden from scan and auto plan, restored by clear, and reappears if membership changes',async()=>{
 const f=fixture();twins(f);
 let rep=await scanDuplicateModules(f.env);assert.equal(rep.groups.length,1);
 await ignoreDuplicateGroup(f.env,{group_token:rep.groups[0].token});
 rep=await scanDuplicateModules(f.env);assert.equal(rep.groups.length,0);assert.equal(rep.modules.length,0);
 assert.equal((await runAutoDedupe(f.env,{apply:false})).plan.length,0);
 await clearDuplicateIgnores(f.env);
 assert.equal((await scanDuplicateModules(f.env)).groups.length,1);
 await ignoreDuplicateGroup(f.env,{group_token:(await scanDuplicateModules(f.env)).groups[0].token});
 f.sql.exec(`UPDATE modules SET content_hash='${H}' WHERE id='c'`);
 assert.equal((await scanDuplicateModules(f.env)).groups.length,1,'three-member group is a new group');
 await assert.rejects(()=>ignoreDuplicateGroup(f.env,{group_token:'bad'}),/重新扫描/);
});
test('keepOneDuplicate: preview deletes nothing and warns; apply deletes the others and keeps the chosen one',async()=>{
 const f=fixture();twins(f);
 f.sql.exec("UPDATE modules SET source_managed=1 WHERE id='b'");
 const g=(await scanDuplicateModules(f.env)).groups[0];
 const pre=await keepOneDuplicate(f.env,{keep_id:'a',group_token:g.token});
 assert.equal(pre.applied,false);assert.deepEqual(pre.remove.map(x=>x.id),['b']);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,4);
 const r=await keepOneDuplicate(f.env,{keep_id:'a',group_token:g.token,apply:true});
 assert.deepEqual(r.done.map(x=>x.id),['b']);assert.equal(r.failed.length,0);
 assert.deepEqual(f.sql.prepare("SELECT id FROM modules WHERE id IN ('a','b')").all().map(x=>x.id),['a']);
 await assert.rejects(()=>keepOneDuplicate(f.env,{keep_id:'zzz',group_token:g.token}),/已变化|重新扫描/);
});
test('keepOneDuplicate: stale token is refused',async()=>{
 const f=fixture();twins(f);const g=(await scanDuplicateModules(f.env)).groups[0];
 f.sql.exec("UPDATE modules SET title='changed',updated_at=999 WHERE id='b'");
 await assert.rejects(()=>keepOneDuplicate(f.env,{keep_id:'a',group_token:g.token,apply:true}),/已变化/);
});
