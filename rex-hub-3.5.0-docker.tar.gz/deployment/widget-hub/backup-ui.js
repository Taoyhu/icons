export const backupUI=String.raw`
(function(){
async function backupCall(path,options){var r=await api(path,Object.assign({timeout:120000},options||{}));if(!r||!r.ok)throw Error(r&&r.error||'请求未确认，请重试');return r;}
exportData=function(){
 showPrompt('导出完整备份','rex-hub-backup-'+new Date().toISOString().slice(0,10),async function(filename){
  if(!filename)return;try{
   toast('正在导出完整备份…');
   var response=await fetch(org()+'/api/admin/backup',{credentials:'same-origin'});
   if(!response.ok)throw Error('服务器未能生成完整备份');
   var blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');
   a.href=url;a.download=filename+'.json';a.click();setTimeout(function(){URL.revokeObjectURL(url);},30000);
   toast('已导出：原始文件、模块 ID、合集、分组、订阅源和图标');
  }catch(e){toast('导出失败，未生成完整备份：'+e.message);}
 });
};
function decodeFile(file){
 if(!file||file.error||typeof file.content!=='string')throw Error('备份存在缺失文件');
 if(file.encoding==='base64'){
  if(!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(file.content))throw Error('备份 Base64 编码无效');
  var binary=atob(file.content),bytes=new Uint8Array(binary.length);for(var i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes;
 }
 if(file.encoding&&file.encoding!=='text')throw Error('不支持的文件编码');
 return new TextEncoder().encode(file.content);
}
function chooseRestoreMode(data){
 return new Promise(function(resolve){
  var n=Object.keys(data.files||{}).length,o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal" role="dialog" aria-modal="true" aria-label="选择恢复方式"><h3>选择恢复方式</h3>'+
   '<p class="batch-progress">备份里有 '+n+' 个模块。</p>'+
   '<p class="batch-progress"><b>增量恢复</b>：只添加备份里的内容，相同 ID 的会覆盖；现有的其他模块、合集、订阅都保留。</p>'+
   '<p class="batch-progress"><b>全量恢复</b>：恢复后和备份完全一致，备份里没有的现有内容会被删除。</p>'+
   '<div class="btn-row"><button class="btn btn-primary" data-m="merge" type="button">增量恢复</button><button class="btn" data-m="full" type="button">全量恢复</button><button class="btn" data-m="" type="button">取消</button></div></div>';
  document.body.appendChild(o);
  o.onclick=function(e){var b=e.target.closest&&e.target.closest('button[data-m]');if(!b)return;o.remove();resolve(b.getAttribute('data-m')||null);};
 });
}
importBackup=function(){
 var input=document.createElement('input');input.type='file';input.accept='.json';
 input.onchange=async function(){
  if(!input.files.length)return;var overlay=null,cancelled=false,committing=false;
  try{
   var data=JSON.parse(await input.files[0].text());if(!data.files||Array.isArray(data.files))throw Error('备份缺少文件');
   var mode=await chooseRestoreMode(data);if(!mode)return;
   if(mode==='full'&&!await showConfirmAsync('再次确认：全量恢复会先清空现有的模块、合集、分组、订阅源和图标，再换成备份里的内容；备份里没有的都会被删除，且不可撤销。确认全量恢复？'))return;
   overlay=document.createElement('div');overlay.className='modal-overlay';
   overlay.innerHTML='<div class="modal" role="dialog" aria-modal="true" aria-label="恢复备份"><h3>'+(mode==='full'?'全量恢复':'增量恢复')+'</h3><p class="batch-progress" role="status"></p><button class="btn" type="button">取消</button></div>';document.body.appendChild(overlay);
   var progress=overlay.querySelector('[role=status]'),cancel=overlay.querySelector('button');
   cancel.onclick=function(){if(!committing){cancelled=true;cancel.disabled=true;progress.textContent='正在取消，现有数据不会改变…';}};
   var rawMeta=data.meta||{},meta=Object.assign({},rawMeta),files=Object.create(null),resources=[];
   for(var key of Object.keys(data.files)){resources.push({id:'module:'+key,file:data.files[key],descriptor:{filename:data.files[key].filename||''}});files[key]=resources[resources.length-1].descriptor;}
   meta.previousVersions=(rawMeta.previousVersions||[]).map(function(p){var descriptor=Object.assign({},p);delete descriptor.content;delete descriptor.kv_key;resources.push({id:'previous:'+p.module_id,file:p,descriptor:descriptor});return descriptor;});
   var icons=rawMeta.icons||{sources:[],entries:[],assets:[]};
   meta.icons={sources:icons.sources||[],entries:icons.entries||[],assets:(icons.assets||[]).map(function(a){var descriptor=Object.assign({},a);delete descriptor.content;delete descriptor.kv_key;resources.push({id:'icon:'+a.hash,file:a,descriptor:descriptor});return descriptor;})};
   for(var i=0;i<resources.length;i++){
    if(cancelled)throw Error('恢复已取消，现有数据未改变');
    progress.textContent='正在校验文件 '+(i+1)+' / '+resources.length;
    var item=resources[i],bytes=decodeFile(item.file),hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
    item.descriptor.size=bytes.byteLength;item.descriptor.hash=hash;
    if(item.id.startsWith('icon:')&&hash!==item.id.slice(5))throw Error('图标摘要不匹配');
   }
   var plan={format:data.format,mode:mode,meta:meta,files:files},job=await backupCall('/api/admin/backup/restore/start',{method:'POST',json:plan});
   var next=0,done=0,failure=null;
   async function uploader(){
    while(!failure&&next<resources.length){
     if(cancelled){failure=Error('恢复已取消，现有数据未改变');return;}
     var item=resources[next++];
     try{await backupCall('/api/admin/backup/restore/'+job.job_id+'/files/'+encodeURIComponent(item.id),{method:'PUT',body:decodeFile(item.file)});}
     catch(e){failure=e;return;}
     done++;progress.textContent='正在上传并校验 '+done+' / '+resources.length+'，现有数据尚未改变';
    }
   }
   await Promise.all([uploader(),uploader(),uploader(),uploader()]);
   if(failure)throw failure;
   if(cancelled)throw Error('恢复已取消，现有数据未改变');
   committing=true;cancel.disabled=true;progress.textContent='全部文件已校验，正在统一恢复…';
   var result=await backupCall('/api/admin/backup/restore/'+job.job_id+'/commit',{method:'POST',json:{}});
   overlay.remove();overlay=null;toast((result.mode==='full'?'全量恢复完成：':'增量恢复完成：')+result.modules+' 个模块、'+result.collections+' 个合集'+(result.mode==='full'&&result.removed?'，已移除备份中没有的 '+result.removed+' 个模块':''));await loadAll();
  }catch(e){if(overlay)overlay.remove();toast('恢复未完成：'+e.message);}
 };
 input.click();
};
})();
`;

