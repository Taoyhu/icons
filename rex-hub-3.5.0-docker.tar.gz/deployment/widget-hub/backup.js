// Stream portable backups. Stage immutable KV files, then publish all identities
// and relationships in ONE D1 transaction. No credential/session export.
import {createHash} from 'node:crypto';
import {assertFetchableUrl} from './remote.js';
import {validateIcon,ICON_LIMITS,exportIcons} from './icons.js';
import {resolveTitle,cleanTitle} from './metadata.js';
import {nameRows,namingSettings,validateFilename,safeFilename} from './filenames.js';
import {fillAutoAll} from './auto-all.js';
import {shareRows,validateShareBackup} from './sharing.js';
export const backupSchema=[
  'CREATE TABLE IF NOT EXISTS resource_gc(kv_key TEXT PRIMARY KEY,created_at INTEGER NOT NULL)',
  'CREATE TABLE IF NOT EXISTS restore_jobs(id TEXT PRIMARY KEY,manifest_key TEXT NOT NULL,generation TEXT NOT NULL,created_at INTEGER,expires_at INTEGER)',
  'CREATE TABLE IF NOT EXISTS restore_files(job_id TEXT NOT NULL,resource_id TEXT NOT NULL,kv_key TEXT NOT NULL,metadata TEXT NOT NULL,size INTEGER NOT NULL,hash TEXT NOT NULL,PRIMARY KEY(job_id,resource_id))'
];
const digest=b=>createHash('sha256').update(typeof b==='string'?b:Buffer.from(b)).digest('hex');
const id=(value,label='ID')=>{if(typeof value!=='string'||!/^[A-Za-z0-9_.-]{1,200}$/.test(value))throw Error(label+' 无效');return value;};
const slug=value=>{if(typeof value!=='string'||!value||value.length>500||/[/\\\u0000-\u001f\u007f]/.test(value))throw Error('合集路径无效');return value;};
const text=(v,max=2000)=>typeof v==='string'?v.slice(0,max):'';
const number=(v,fallback=0)=>Number.isFinite(Number(v))?Number(v):fallback;
const array=(v,label)=>{if(v===undefined)return [];if(!Array.isArray(v))throw Error(label+' 必须是数组');return v;};
const rows=async(DB,table)=>(await DB.prepare('SELECT * FROM '+table).all()).results;
const generation=async env=>(await env.DB.prepare("SELECT value FROM settings WHERE key='content_generation'").first())?.value||'0';
function savedAutoAll(c,previous=false){
 if(c.autoAll!==undefined){if(typeof c.autoAll!=='boolean')throw Error('合集自动包含配置无效');return c.autoAll;}
 if(c.auto_all!==undefined){if(![0,1].includes(c.auto_all))throw Error('合集自动包含配置无效');return !!c.auto_all;}
 return previous;
}

export async function setCollectionSlug(DB,collectionId,newSlug){
  const current=await DB.prepare('SELECT slug FROM collections WHERE id=?').bind(collectionId).first();
  if(!current||current.slug===newSlug)return [];
  const owner=await DB.prepare('SELECT id FROM collections WHERE slug=? UNION ALL SELECT collection_id AS id FROM collection_aliases WHERE slug=?').bind(newSlug,newSlug).all();
  if(owner.results.some(r=>r.id!==collectionId))throw Error('路径已被其他合集或历史地址占用');
  return [
    DB.prepare('DELETE FROM collection_aliases WHERE slug=? AND collection_id=?').bind(newSlug,collectionId),
    DB.prepare('INSERT OR REPLACE INTO collection_aliases(slug,collection_id) VALUES(?,?)').bind(current.slug,collectionId)
  ];
}
async function* encodedFile(env,key){
  const stream=await env.KV.get(key,'stream');if(!stream)throw Error('文件缺失，备份未完成：'+key);
  const reader=stream.getReader();let remainder=Buffer.alloc(0);
  try{while(true){const {done,value}=await reader.read();if(done)break;
    const bytes=Buffer.concat([remainder,Buffer.from(value)]),length=bytes.length-bytes.length%3;
    for(let start=0;start<length;start+=49152)yield bytes.subarray(start,Math.min(length,start+49152)).toString('base64');
    remainder=Buffer.from(bytes.subarray(length));
  }if(remainder.length)yield remainder.toString('base64');}
  finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}
export async function exportBackup(env){
  const DB=env.DB,modules=await rows(DB,'modules'),collections=await rows(DB,'collections'),members=await rows(DB,'collection_modules');
  const groups=await rows(DB,'groups'),aliases=await rows(DB,'collection_aliases'),sources=await rows(DB,'subscription_sources'),sourceItems=await rows(DB,'subscription_items');
  const previousVersions=(await DB.prepare('SELECT * FROM module_previous_versions WHERE expires_at>?').bind(Date.now()).all()).results,icons=await exportIcons(env);
  const memberMap=new Map();for(const m of members){if(!memberMap.has(m.collection_id))memberMap.set(m.collection_id,[]);memberMap.get(m.collection_id).push(m);}
  const options=new Map((await rows(DB,'collection_options')).map(o=>[o.collection_id,!!o.auto_all]));
  for(const c of collections){c.moduleIds=(memberMap.get(c.id)||[]).sort((a,b)=>a.position-b.position).map(m=>m.module_id);c.autoAll=options.get(c.id)||false;}
  const metadata={modules,collections,groups,aliases,shareAliases:await shareRows(env),names:await nameRows(env),filenameSettings:await namingSettings(env),sources:sources.map(({lease_token,lease_until,snapshot,...s})=>s),sourceItems,exportedAt:new Date().toISOString()};
  async function* generate(){
    yield '{"format":7,"meta":'+JSON.stringify(metadata).slice(0,-1)+',"icons":{"sources":'+JSON.stringify(icons.sources)+',"entries":'+JSON.stringify(icons.entries)+',"assets":[';
    let comma='';
    for(const {kv_key,...asset} of icons.assets){yield comma+JSON.stringify({...asset,encoding:'base64'}).slice(0,-1)+',"content":"';yield* encodedFile(env,kv_key);yield '"}';comma=',';}
    yield ']},"previousVersions":[';comma='';
    for(const version of previousVersions){const {kv_key,...meta}=version;yield comma+JSON.stringify({...meta,encoding:'base64'}).slice(0,-1)+',"content":"';yield* encodedFile(env,kv_key);yield '"}';comma=',';}
    yield ']},"files":{';comma='';
    for(const m of modules){yield comma+JSON.stringify(m.id)+':'+JSON.stringify({filename:m.filename,encoding:'base64'}).slice(0,-1)+',"content":"';yield* encodedFile(env,m.file_key||'file:'+m.id);yield '"}';comma=',';}
    yield '}}';
  }
  let resolve,reject;const completion=new Promise((a,b)=>{resolve=a;reject=b;});completion.catch(()=>{});
  const iterator=generate(),encoder=new TextEncoder(),body=new ReadableStream({
    async pull(controller){try{const {done,value}=await iterator.next();if(done){controller.close();resolve();}else controller.enqueue(encoder.encode(value));}catch(e){controller.error(e);reject(e);}},
    async cancel(){try{await iterator.return();}finally{resolve();}}
  });
  const response=new Response(body,{headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Content-Disposition':'attachment; filename="rex-hub-backup-'+new Date().toISOString().slice(0,10)+'.json"'}});
  response.hubCompletion=completion;return response;
}
function resourceList(body){
  const meta=body.meta||{},resources=[];
  for(const [key,file] of Object.entries(body.files||{})){
    id(key,'模块 ID');resources.push({id:'module:'+key,kind:'module',owner:key,filename:text(file.filename,500),size:file.size,hash:file.hash});
  }
  for(const p of array(meta.previousVersions,'上一版'))resources.push({id:'previous:'+id(p.module_id),kind:'previous',owner:p.module_id,size:p.size,hash:p.hash});
  for(const a of array(meta.icons?.assets,'图标图片'))resources.push({id:'icon:'+a.hash,kind:'icon',owner:a.hash,size:a.size,hash:a.hash,mime:a.mime,ext:a.ext});
  const seen=new Set();
  for(const r of resources){
    if(seen.has(r.id)||!Number.isSafeInteger(r.size)||r.size<1||r.size>25*1024*1024||typeof r.hash!=='string'||!/^[a-f0-9]{64}$/.test(r.hash))throw Error('备份文件身份、大小或摘要无效');
    if(r.kind==='icon'&&(r.size>ICON_LIMITS.image||!['png','jpg','webp'].includes(r.ext)))throw Error('图标文件无效');seen.add(r.id);
  }
  if(resources.length>1500)throw Error('单次恢复最多支持 1500 个文件，请分批恢复');
  return resources;
}
async function validateNames(env,body,mods,restored,full=false){
 if(!(body.format>=6))return;
 const meta=body.meta||{};
 if(!Array.isArray(meta.names)||typeof meta.filenameSettings?.auto_clean!=='boolean')throw Error('新版备份缺少文件名配置');
 const names=full?[]:await nameRows(env),current=new Map(names.map(n=>[n.module_id,n]));
 const declared=new Set(meta.names.map(n=>n?.module_id));
 const occupied=new Map(mods.filter(m=>!restored.has(m.id)).map(m=>[(current.get(m.id)?.filename||safeFilename(m.filename,m.id)).normalize('NFC').toLowerCase(),m.id]));
 for(const m of meta.modules||[])if(!declared.has(m.id))occupied.set(safeFilename(body.files[m.id]?.filename||m.filename,m.id).normalize('NFC').toLowerCase(),m.id);
 const seen=new Set();
 for(const n of meta.names){
  if(!n||!restored.has(n.module_id)||seen.has(n.module_id))throw Error('文件名记录重复或引用缺失');
  id(n.module_id);validateFilename(n.filename);let originals;
  try{originals=JSON.parse(n.originals);}catch{throw Error('原始文件名历史无效');}
  if(!Array.isArray(originals)||originals.length>1000||originals.some(a=>typeof a!=='string'||a.length>500)||![0,1].includes(n.named_url))throw Error('文件名配置无效');
  const key=n.filename.normalize('NFC').toLowerCase();
  if(occupied.has(key)&&occupied.get(key)!==n.module_id)throw Error('备份文件名与其他模块冲突：'+n.filename);
  occupied.set(key,n.module_id);seen.add(n.module_id);
 }
}
// Validation is read only, and runs again immediately before commit.
async function validatePlan(env,body){
  if(!body||!body.files||Array.isArray(body.files)||typeof body.files!=='object'||(body.format!==undefined&&![1,2,3,4,5,6,7].includes(body.format)))throw Error('无效或不支持的备份文件');
  const meta=body.meta||{},DB=env.DB,full=restoreMode(body)==='full',resources=resourceList(body);
  for(const key of ['modules','collections','groups','aliases','sources','sourceItems','previousVersions'])array(meta[key],key);
  const mods=full?[]:await rows(DB,'modules'),cols=full?[]:await rows(DB,'collections'),existingAliases=full?[]:await rows(DB,'collection_aliases');
  const availableModules=new Set(mods.map(m=>m.id)),savedModules=new Set(),availableCols=new Set(cols.map(c=>c.id));
  for(const m of meta.modules||[]){id(m.id,'模块 ID');if(savedModules.has(m.id)||!body.files[m.id])throw Error('模块重复或缺少文件：'+m.id);savedModules.add(m.id);}
  for(const r of resources.filter(r=>r.kind==='module'))availableModules.add(r.owner);
  const owners=new Map([...cols.map(c=>[c.slug,c.id]),...existingAliases.map(a=>[a.slug,a.collection_id])]),seenCols=new Set(),aliases=[];
  for(const c of meta.collections||[]){
    id(c.id,'合集 ID');slug(c.slug);if(seenCols.has(c.id))throw Error('重复合集 ID');seenCols.add(c.id);availableCols.add(c.id);
    if(owners.has(c.slug)&&owners.get(c.slug)!==c.id)throw Error('合集路径已占用：'+c.slug);owners.set(c.slug,c.id);
    if(!Array.isArray(c.moduleIds)||c.moduleIds.length>1000||c.moduleIds.some(mid=>!availableModules.has(mid)))throw Error('合集引用缺失或超过上限：'+c.slug);
    const old=cols.find(old=>old.id===c.id);if(old&&old.slug!==c.slug)aliases.push({slug:old.slug,collection_id:c.id});
  }
  for(const a of [...aliases,...(meta.aliases||[])]){slug(a.slug);id(a.collection_id);if(!availableCols.has(a.collection_id)||(owners.has(a.slug)&&owners.get(a.slug)!==a.collection_id))throw Error('合集历史地址冲突或引用缺失');owners.set(a.slug,a.collection_id);}
  const groups=new Set();for(const g of meta.groups||[]){id(g.id,'分组 ID');if(groups.has(g.id)||!text(g.name,200).trim())throw Error('分组重复或名称为空');groups.add(g.id);}
  const sourceRows=full?[]:await rows(DB,'subscription_sources'),sourceIds=new Map(sourceRows.map(s=>[s.id,s.url])),sourceUrls=new Map(sourceRows.map(s=>[s.url,s.id])),seenSources=new Set();
  for(const s of meta.sources||[]){
    if(body.format>=7&&(!['collection','module'].includes(s.kind)||![0,1].includes(s.title_locked)))throw Error('订阅类型或标题锁定字段无效');
    id(s.id,'订阅源 ID');const url=assertFetchableUrl(s.url).href;
    if(seenSources.has(s.id)||(sourceIds.has(s.id)&&sourceIds.get(s.id)!==url)||(sourceUrls.has(url)&&sourceUrls.get(url)!==s.id))throw Error('订阅源身份冲突');
    seenSources.add(s.id);sourceIds.set(s.id,url);sourceUrls.set(url,s.id);
  }
  const seenItems=new Set();for(const item of meta.sourceItems||[]){
    const key=item.source_id+'\0'+item.remote_id;
    if(!sourceIds.has(item.source_id)||typeof item.remote_id!=='string'||!item.remote_id||item.remote_id.length>2048||seenItems.has(key)||(item.module_id&&!availableModules.has(item.module_id)))throw Error('订阅条目重复或引用缺失');
    seenItems.add(key);assertFetchableUrl(item.url);
  }
  for(const p of meta.previousVersions||[]){
    if(!availableModules.has(p.module_id)||!Number.isFinite(p.expires_at)||p.expires_at>Date.now()+7*86400000)throw Error('上一版引用或过期时间无效');
    let metadata;try{metadata=JSON.parse(p.metadata);}catch{throw Error('上一版元数据无效');}
    if(!metadata||typeof metadata.filename!=='string')throw Error('上一版文件名缺失');
  }
  const icons=meta.icons||{sources:[],entries:[],assets:[]};for(const k of ['sources','entries','assets'])array(icons[k],'图标 '+k);
  if(body.format>=5&&!meta.icons)throw Error('新版备份缺少图标数据');
  const currentIcons=full?{sources:[],entries:[],assets:[]}:await exportIcons(env),iconIds=new Map(currentIcons.sources.map(s=>[s.id,s.url])),iconUrls=new Map(currentIcons.sources.map(s=>[s.url,s.id])),iconSources=new Set();
  for(const s of icons.sources){id(s.id,'图标源 ID');const url=assertFetchableUrl(s.url).href;
    if(iconSources.has(s.id)||(iconIds.has(s.id)&&iconIds.get(s.id)!==url)||(iconUrls.has(url)&&iconUrls.get(url)!==s.id)||!text(s.name,200).trim())throw Error('图标源身份冲突');
    iconSources.add(s.id);iconIds.set(s.id,url);iconUrls.set(url,s.id);
  }
  if(iconIds.size>ICON_LIMITS.sources||icons.entries.length>ICON_LIMITS.sources*ICON_LIMITS.entries)throw Error('恢复后图标源或条目超过上限');
  const assets=new Map(currentIcons.assets.map(a=>[a.hash,a])),seenAssets=new Set();
  for(const a of icons.assets){if(seenAssets.has(a.hash))throw Error('重复图标文件');seenAssets.add(a.hash);assets.set(a.hash,a);}
  if([...assets.values()].reduce((sum,a)=>sum+a.size,0)>ICON_LIMITS.assets)throw Error('恢复后图标缓存超过 128 MiB');
  const entries=new Set(),counts=new Map();for(const e of icons.entries){const url=assertFetchableUrl(e.url).href;
    if(!iconSources.has(e.source_id)||e.id!==digest(e.source_id+'\0'+url)||entries.has(e.id)||!text(e.name,200).trim())throw Error('图标条目身份无效');
    entries.add(e.id);counts.set(e.source_id,(counts.get(e.source_id)||0)+1);if(counts.get(e.source_id)>ICON_LIMITS.entries)throw Error('单源图标过多');
  }
  for(const c of meta.collections||[]){if(c.icon_url?.startsWith('/api/icons/')){const m=c.icon_url.match(/^\/api\/icons\/([a-f0-9]{64})\.(png|jpg|webp)$/);if(!m||assets.get(m[1])?.ext!==m[2])throw Error('合集引用的图标文件缺失');}}
  for(const s of meta.sources||[]){
    let summary=s.summary;
    if(typeof summary==='string'){try{summary=JSON.parse(summary);}catch{continue;}}
    if(!summary?.custom_icon_url)continue;
    const m=typeof summary.custom_icon_url==='string'&&summary.custom_icon_url.match(/^\/api\/icons\/([a-f0-9]{64})\.(png|jpg|webp)$/);
    if(!m||assets.get(m[1])?.ext!==m[2])throw Error('订阅引用的图标文件缺失');
  }
  await validateNames(env,body,mods,new Set(resources.filter(r=>r.kind==='module').map(r=>r.owner)),full);
  await validateShareBackup(env,body,mods,full);
  const activeOptions=new Map((full?[]:await rows(DB,'collection_options')).map(o=>[o.collection_id,!!o.auto_all]));
  for(const c of meta.collections||[])activeOptions.set(c.id,savedAutoAll(c,activeOptions.get(c.id)||false));
  if([...activeOptions.values()].some(Boolean)&&availableModules.size>1000)throw Error('自动包含全部模块的合集超过 1000 项，无法恢复');
  return {resources,aliases};
}
// 'merge' (增量): add backup content, same-ID items overwritten, nothing else touched.
// 'full' (全量): after commit the site equals the backup; everything not in it is removed.
export function restoreMode(body){
  const m=body&&body.mode;if(m===undefined||m==='merge')return 'merge';
  if(m==='full')return 'full';throw Error('恢复方式无效');
}
export async function beginRestore(env,body){
  restoreMode(body);
  const serialized=JSON.stringify(body);
  if(serialized.length>1500000)throw Error('备份清单过大，请分批恢复');
  const {resources}=await validatePlan(env,body),now=Date.now(),jobId=crypto.randomUUID(),key='restore-manifest:'+jobId;
  await env.KV.put(key,serialized);
  try{await env.DB.prepare('INSERT INTO restore_jobs(id,manifest_key,generation,created_at,expires_at) VALUES(?,?,?,?,?)').bind(jobId,key,await generation(env),now,now+3600000).run();}
  catch(e){await env.KV.delete(key).catch(()=>{});throw e;}
  return {ok:true,job_id:jobId,mode:restoreMode(body),resources:resources.length};
}
// A restore uploads hundreds of files against one manifest; parse it and build its resource table once per job.
const jobCache=new Map();
async function loadJob(env,jobId){
  id(jobId);const row=await env.DB.prepare('SELECT * FROM restore_jobs WHERE id=?').bind(jobId).first();
  if(!row||row.expires_at<Date.now()||row.generation!==await generation(env))throw Error('恢复任务已过期或被清空/恢复操作取消，请重新上传');
  let cached=jobCache.get(jobId);
  if(!cached||cached.key!==row.manifest_key){
    const body=await env.KV.get(row.manifest_key,'json');if(!body)throw Error('恢复清单缺失');
    cached={key:row.manifest_key,body,resources:new Map(resourceList(body).map(r=>[r.id,r]))};
    jobCache.set(jobId,cached);while(jobCache.size>4)jobCache.delete(jobCache.keys().next().value);
  }
  return {row,body:cached.body,resources:cached.resources};
}
export async function stageRestoreFile(env,jobId,resourceId,bytes,helpers){
  const {resources}=await loadJob(env,jobId),resource=resources.get(resourceId);if(!resource)throw Error('备份清单中没有此文件');
  if(bytes.byteLength!==resource.size||digest(bytes)!==resource.hash)throw Error('备份文件摘要不匹配，未替换现有数据');
  const existing=await env.DB.prepare('SELECT hash FROM restore_files WHERE job_id=? AND resource_id=?').bind(jobId,resourceId).first();
  if(existing){if(existing.hash!==resource.hash)throw Error('恢复文件冲突');return {ok:true,existing:true};}
  let metadata={};
  if(resource.kind==='icon'){const icon=validateIcon(bytes,resource.mime);if(icon.hash!==resource.hash||icon.ext!==resource.ext)throw Error('图标文件校验失败');}
  else if(resource.kind==='module'){const encrypted=helpers.isEncrypted(new Uint8Array(bytes));metadata={encrypted,parsed:encrypted?{}:helpers.parseMeta(resource.filename||'restored.js',new Uint8Array(bytes).subarray(0,32768))};}
  const key='restore-content:'+crypto.randomUUID();await env.KV.put(key,bytes,{metadata:{u:Date.now(),s:bytes.byteLength}});
  try{await env.DB.prepare('INSERT INTO restore_files(job_id,resource_id,kv_key,metadata,size,hash) VALUES(?,?,?,?,?,?)').bind(jobId,resourceId,key,JSON.stringify(metadata),resource.size,resource.hash).run();}
  catch(e){await env.KV.delete(key).catch(()=>{});throw e;}return {ok:true};
}
function upsertRows(DB,table,columns,values,conflict='id'){
  const out=[],keys=conflict.split(','),updates=columns.filter(k=>!keys.includes(k));
  for(let start=0;start<values.length;start+=500){const data=JSON.stringify(values.slice(start,start+500));if(data.length>1500000)throw Error('单批备份清单过大');
    out.push(DB.prepare('INSERT INTO '+table+'('+columns.join(',')+') SELECT '+columns.map(k=>"json_extract(value,'$."+k+"')").join(',')+
      ' FROM json_each(?) WHERE 1 ON CONFLICT('+conflict+') DO UPDATE SET '+updates.map(k=>k+'=excluded.'+k).join(',')).bind(data));
  }return out;
}
const moduleColumns=['id','filename','widget_id','title','version','author','file_size','is_encrypted','source_url','note','group_id','sort_order','created_at','updated_at','content_hash','required_version','source_managed','manual_override','file_key','metadata_id','code_title','manifest_title','title_locked','generated_filename','title_scan_v1'];
export async function commitRestore(env,jobId){
  const {row,body}=await loadJob(env,jobId),{resources,aliases}=await validatePlan(env,body),DB=env.DB,meta=body.meta||{},now=Date.now(),full=restoreMode(body)==='full';
  const staged=(await DB.prepare('SELECT * FROM restore_files WHERE job_id=?').bind(jobId).all()).results,map=new Map(staged.map(r=>[r.resource_id,r]));
  if(resources.some(r=>!map.has(r.id)||map.get(r.id).hash!==r.hash||map.get(r.id).size!==r.size))throw Error('备份文件尚未全部上传，未替换现有数据');
  const existingIds=new Set(full?(await rows(DB,'modules')).map(m=>m.id):[]),removedCount=full?(await DB.prepare('SELECT COUNT(*) AS n FROM modules').first()).n:0,existing=new Map((full?[]:await rows(DB,'modules')).map(m=>[m.id,m])),saved=new Map((meta.modules||[]).map(m=>[m.id,m]));
  const modules=resources.filter(r=>r.kind==='module').map(r=>{
    const file=map.get(r.id),description=JSON.parse(file.metadata),old=existing.get(r.owner)||{},m=saved.get(r.owner)||{},parsed=description.parsed;
    const filename=text(r.filename||m.filename||old.filename||'restored.js',500),code=description.encrypted?'':cleanTitle(parsed.title||m.code_title||''),manifest=cleanTitle(m.manifest_title||'');
    const locked=m.title_locked??old.title_locked??(body.format<4||!body.format);
    return {id:r.owner,filename,widget_id:text(m.widget_id||parsed.id||old.widget_id||r.owner,500),
      title:locked?(text(m.title||old.title,500)||resolveTitle({filename},code,manifest)):resolveTitle({filename},code,manifest),
      version:text(m.version??parsed.version??old.version,100),author:text(m.author??parsed.author??old.author,500),
      file_size:r.size,is_encrypted:description.encrypted?1:0,source_url:m.source_url?assertFetchableUrl(m.source_url).href:null,note:text(m.note??old.note,4000),
      group_id:text(m.group_id??old.group_id,200),sort_order:number(m.sort_order,old.sort_order||0),created_at:number(m.created_at,old.created_at||now),updated_at:now,
      content_hash:r.hash,required_version:text(m.required_version||'0.0.1',100),source_managed:m.source_managed?1:0,
      manual_override:(m.manual_override??old.manual_override??(body.format<4||!body.format))?1:0,file_key:file.kv_key,
      metadata_id:text(m.metadata_id||parsed.id,500),code_title:code,manifest_title:manifest,title_locked:locked?1:0,generated_filename:m.generated_filename?1:0,title_scan_v1:1};
  });
  const statements=[
    DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('content_generation',?)").bind(crypto.randomUUID()),
    DB.prepare('DELETE FROM upload_results'),DB.prepare('DELETE FROM upload_jobs'),
    DB.prepare("UPDATE subscription_sources SET lease_until=0,lease_token='',snapshot=NULL,cursor=0,status=CASE WHEN enabled=1 THEN 'idle' ELSE 'paused' END"),
    DB.prepare("UPDATE icon_sources SET lease_until=0,lease_token=''")
  ];
  if(full)statements.push(
    DB.prepare("INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT CASE WHEN file_key IS NULL OR file_key='' THEN 'file:'||id ELSE file_key END,? FROM modules").bind(now),
    DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT kv_key,? FROM module_previous_versions').bind(now),
    DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT kv_key,? FROM icon_assets').bind(now),
    DB.prepare('UPDATE module_share_aliases SET tombstoned=1,is_current=0'),
    DB.prepare('DELETE FROM source_previews'),
    ...['collection_modules','collection_aliases','collections','collection_options','modules','groups','subscription_items','subscription_sources','module_previous_versions','icon_entries','icon_sources','icon_assets','module_names'].map(t=>DB.prepare('DELETE FROM '+t))
  );
  statements.push(...upsertRows(DB,'modules',moduleColumns,modules));
  const obsoleteKeys=modules.flatMap(m=>{const old=existing.get(m.id);return old?[old.file_key||'file:'+old.id]:[];});
  if(obsoleteKeys.length)statements.push(DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT value,? FROM json_each(?)').bind(now,JSON.stringify(obsoleteKeys)));
  const restoredIds=modules.map(m=>m.id);
  if(restoredIds.length)statements.push(DB.prepare('DELETE FROM module_previous_versions WHERE module_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(restoredIds)));
  statements.push(...upsertRows(DB,'groups',['id','name','position','created_at'],(meta.groups||[]).map(g=>({id:g.id,name:text(g.name,200),position:number(g.position),created_at:number(g.created_at,now)}))));
  const collections=(meta.collections||[]).map(c=>({id:c.id,slug:c.slug,title:text(c.title,200)||'未命名合集',description:text(c.description),icon_url:text(c.icon_url,2048),created_at:number(c.created_at,now),updated_at:now}));
  statements.push(...upsertRows(DB,'collections',['id','slug','title','description','icon_url','created_at','updated_at'],collections));
  const options=new Map((full?[]:await rows(DB,'collection_options')).map(o=>[o.collection_id,!!o.auto_all]));
  statements.push(...upsertRows(DB,'collection_options',['collection_id','auto_all'],(meta.collections||[]).map(c=>({collection_id:c.id,auto_all:savedAutoAll(c,options.get(c.id)||false)?1:0})),'collection_id'));
  if(collections.length)statements.push(DB.prepare('DELETE FROM collection_modules WHERE collection_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(collections.map(c=>c.id))));
  const members=(meta.collections||[]).flatMap(c=>[...new Set(c.moduleIds)].map((mid,i)=>({collection_id:c.id,module_id:mid,position:i})));
  statements.push(...upsertRows(DB,'collection_modules',['collection_id','module_id','position'],members,'collection_id,module_id'));
  statements.push(...upsertRows(DB,'collection_aliases',['slug','collection_id'],[...aliases,...(meta.aliases||[])],'slug'));
  const sources=(meta.sources||[]).map(s=>({id:s.id,url:assertFetchableUrl(s.url).href,title:text(s.title,500)||'订阅',group_id:text(s.group_id,200),enabled:s.enabled?1:0,status:s.enabled?'idle':'paused',next_sync_at:now+21600000,last_started_at:number(s.last_started_at),last_finished_at:number(s.last_finished_at),last_error:text(s.last_error,500),summary:typeof s.summary==='string'?s.summary:JSON.stringify(s.summary||{}),created_at:number(s.created_at,now),kind:body.format>=7?s.kind:'collection',title_locked:body.format>=7?s.title_locked:0,revision:crypto.randomUUID(),etag:'',last_modified:''}));
  statements.push(...upsertRows(DB,'subscription_sources',['id','url','title','group_id','enabled','status','next_sync_at','last_started_at','last_finished_at','last_error','summary','created_at','kind','title_locked','revision','etag','last_modified'],sources));
  if(sources.length)statements.push(DB.prepare('DELETE FROM subscription_items WHERE source_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(sources.map(s=>s.id))));
  const items=(meta.sourceItems||[]).map(i=>({source_id:i.source_id,remote_id:i.remote_id,module_id:i.module_id||null,url:assertFetchableUrl(i.url).href,title:text(i.title,500),version:text(i.version,100),author:text(i.author,500),description:text(i.description,4000),required_version:text(i.required_version||'0.0.1',100),active:i.active===0?0:1,last_error:text(i.last_error,500)}));
  statements.push(...upsertRows(DB,'subscription_items',['source_id','remote_id','module_id','url','title','version','author','description','required_version','active','last_error'],items,'source_id,remote_id'));
  const previous=(meta.previousVersions||[]).filter(p=>p.expires_at>now).map(p=>({module_id:p.module_id,kv_key:map.get('previous:'+p.module_id).kv_key,metadata:p.metadata,created_at:number(p.created_at,now),expires_at:p.expires_at}));
  statements.push(...upsertRows(DB,'module_previous_versions',['module_id','kv_key','metadata','created_at','expires_at'],previous,'module_id'));
  const icons=meta.icons||{sources:[],entries:[],assets:[]};
  const assets=icons.assets.map(a=>({hash:a.hash,mime:a.mime,ext:a.ext,size:a.size,kv_key:map.get('icon:'+a.hash).kv_key,created_at:now,last_used_at:now}));
  statements.push(...upsertRows(DB,'icon_assets',['hash','mime','ext','size','kv_key','created_at','last_used_at'],assets,'hash'));
  const iconSources=icons.sources.map(s=>({id:s.id,url:assertFetchableUrl(s.url).href,name:text(s.name,200),enabled:s.enabled?1:0,etag:text(s.etag,1000),last_modified:text(s.last_modified,1000),last_attempt_at:number(s.last_attempt_at),last_success_at:number(s.last_success_at),next_sync_at:now+86400000,last_error:text(s.last_error,500),failures:0,revision:crypto.randomUUID(),created_at:number(s.created_at,now)}));
  statements.push(...upsertRows(DB,'icon_sources',['id','url','name','enabled','etag','last_modified','last_attempt_at','last_success_at','next_sync_at','last_error','failures','revision','created_at'],iconSources));
  if(iconSources.length)statements.push(DB.prepare('DELETE FROM icon_entries WHERE source_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(iconSources.map(s=>s.id))));
  statements.push(...upsertRows(DB,'icon_entries',['id','source_id','url','name','position','active','asset_hash','cached_at'],icons.entries.map(e=>({id:e.id,source_id:e.source_id,url:assertFetchableUrl(e.url).href,name:text(e.name,200),position:number(e.position),active:e.active===0?0:1,asset_hash:text(e.asset_hash,64),cached_at:number(e.cached_at)}))));
  if(body.format>=6){
    statements.push(DB.prepare('DELETE FROM module_names WHERE module_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(restoredIds)));
    statements.push(...upsertRows(DB,'module_names',['module_id','filename','originals','named_url','revision'],meta.names.map(n=>({...n,revision:crypto.randomUUID()})),'module_id'));
    statements.push(DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('filename_auto_clean',?)").bind(String(meta.filenameSettings.auto_clean)));
  }
  if(body.format>=7){
    const currentIds=[...new Set(meta.shareAliases.filter(a=>a.is_current).map(a=>a.module_id))];
    if(currentIds.length)statements.push(DB.prepare('UPDATE module_share_aliases SET is_current=0 WHERE module_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(currentIds)));
    statements.push(...upsertRows(DB,'module_share_aliases',['alias','alias_key','module_id','is_current','tombstoned','created_at'],meta.shareAliases,'alias_key'));
  }
  statements.push(fillAutoAll(DB));
  statements.push(DB.prepare('DELETE FROM restore_files WHERE job_id=?').bind(jobId),DB.prepare('DELETE FROM restore_jobs WHERE id=?').bind(jobId));
  await DB.batch(statements);jobCache.delete(jobId);env.CONTENT_EPOCH=(env.CONTENT_EPOCH||0)+1;await env.KV.delete(row.manifest_key).catch(()=>{});
  return {ok:true,mode:full?'full':'merge',modules:modules.length,collections:collections.length,icons:assets.length,removed:full?Math.max(0,removedCount-modules.filter(m=>existingIds.has(m.id)).length):0};
}
export async function cleanupRestoreJobs(env){
  const garbage=(await env.DB.prepare('SELECT kv_key FROM resource_gc WHERE created_at<? AND NOT EXISTS(SELECT 1 FROM modules m WHERE m.file_key=resource_gc.kv_key OR (m.file_key=\'\' AND \'file:\'||m.id=resource_gc.kv_key)) AND NOT EXISTS(SELECT 1 FROM module_previous_versions p WHERE p.kv_key=resource_gc.kv_key) AND NOT EXISTS(SELECT 1 FROM icon_assets a WHERE a.kv_key=resource_gc.kv_key) AND NOT EXISTS(SELECT 1 FROM restore_files f WHERE f.kv_key=resource_gc.kv_key) LIMIT 3').bind(Date.now()-3600000).all()).results;
  for(const f of garbage){await env.KV.delete(f.kv_key);await env.DB.prepare('DELETE FROM resource_gc WHERE kv_key=?').bind(f.kv_key).run();}
  const expired=(await env.DB.prepare('SELECT f.kv_key FROM restore_files f JOIN restore_jobs j ON j.id=f.job_id WHERE j.expires_at<? LIMIT 5').bind(Date.now()).all()).results;
  for(const f of expired){await env.KV.delete(f.kv_key);await env.DB.prepare('DELETE FROM restore_files WHERE kv_key=?').bind(f.kv_key).run();}
  const jobs=(await env.DB.prepare('SELECT * FROM restore_jobs j WHERE expires_at<? AND NOT EXISTS(SELECT 1 FROM restore_files f WHERE f.job_id=j.id) LIMIT 2').bind(Date.now()).all()).results;
  for(const j of jobs){await env.KV.delete(j.manifest_key);await env.DB.prepare('DELETE FROM restore_jobs WHERE id=?').bind(j.id).run();}
}
