// Workers fetch policy: public HTTP(S), one budget for redirects and body.
export function assertFetchableUrl(raw){
  let u;try{u=new URL(raw);}catch{throw Error('URL 格式不合法');}
  if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('只支持无账号密码的 http/https 地址');
  const h=u.hostname.toLowerCase(),ip=h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if(!h||h.includes(':')||h==='localhost'||/\.(localhost|local|internal)$/.test(h))throw Error('不允许的地址');
  if(ip){const [,a,b]=ip.map(Number);if(a===0||a===10||a===127||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||
    (a===192&&b===168)||(a===100&&b>=64&&b<=127)||(a===198&&(b===18||b===19))||a>=224)throw Error('不允许的地址');}
  u.hash='';return u;
}
export async function fetchRemote(raw,maxBytes,{signal,transport=globalThis.fetch,assertUrl=assertFetchableUrl,headers={},allowNotModified=false}={}){
  let url=assertUrl(raw),response;const timeout=AbortSignal.timeout(60000),combined=signal?AbortSignal.any([timeout,signal]):timeout;
  try{
    for(let hop=0;hop<=5;hop++){
      response=await transport(url.href,{redirect:'manual',signal:combined,headers:{'Cache-Control':'no-cache',...(hop===0?headers:{})}});
      if(allowNotModified&&response.status===304){await response.body?.cancel();return {bytes:new Uint8Array(),status:304,etag:response.headers.get('etag')||'',lastModified:response.headers.get('last-modified')||''};}
      if(response.status<300||response.status>=400)break;
      const location=response.headers.get('location');if(!location)break;await response.body?.cancel();
      if(hop===5)throw Error('重定向次数过多');url=assertUrl(new URL(location,url).href);
    }
    if(!response.ok){await response.body?.cancel();throw Error('Failed to fetch: '+response.status);}
    if(Number(response.headers.get('content-length'))>maxBytes){await response.body?.cancel();throw Error('文件过大，上限 '+Math.round(maxBytes/1048576)+' MB');}
    const chunks=[],reader=response.body?.getReader();let size=0;
    try{while(reader){combined.throwIfAborted();const {done,value}=await reader.read();if(done)break;size+=value.byteLength;
      if(size>maxBytes)throw Error('文件过大，上限 '+Math.round(maxBytes/1048576)+' MB');chunks.push(value);}}
    catch(e){await reader?.cancel().catch(()=>{});throw e;}finally{reader?.releaseLock();}
    const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
    return {bytes,url:url.href,contentType:response.headers.get('content-type')||'',status:response.status,etag:response.headers.get('etag')||'',lastModified:response.headers.get('last-modified')||''};
  }catch(e){if(timeout.aborted||e?.name==='TimeoutError')throw Error('读取外部链接超时（60 秒），源站响应较慢，请稍后重试或下载文件后上传');throw e;}
}
export function assertModuleFile(bytes,contentType=''){
  if(!bytes.byteLength)throw Error('模块文件为空');
  const text=new TextDecoder().decode(bytes.subarray(0,32768)).replace(/^\uFEFF/,'').trimStart();
  if(/^REXENC(?:\r?\n|$)/.test(text)){if(bytes.byteLength<10)throw Error('加密模块缺少内容');return;}
  if(/text\/html|application\/(?:json|problem\+json)/i.test(contentType)||/^(?:<!doctype\s+html|<html\b|<head\b|<body\b)/i.test(text))throw Error('模块地址返回了网页或 JSON，已保留旧版本');
  if(text.startsWith('{')||text.startsWith('[')){try{JSON.parse(new TextDecoder().decode(bytes));}catch{return;}throw Error('模块地址返回了 JSON，已保留旧版本');}
}

