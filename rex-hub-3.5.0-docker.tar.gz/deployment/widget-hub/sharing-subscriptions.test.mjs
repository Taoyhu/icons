import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fixture} from './test-fixtures/platform.mjs';
import {HubCoordinator} from './worker.js';
const enc=value=>Buffer.concat([Buffer.from('REXENC\n'+value),Buffer.from([255,0,128])]);
const code=(id='lx',title='LX-music',v='1')=>`var WidgetMetadata={id:'${id}',title:'${title}',version:'${v}'};function play(){}`;

test('subscription avatar is admin-only, survives batches and source edits, and can restore the latest upstream icon',async t=>{
 const f=await app(),png=await readFile(new URL('./public/app-icons/rex-mulberry-v1-32.png',import.meta.url));
 const coll='https://source.example/list.rex',next='https://source.example/new.rex',url='https://source.example/module.js';
 let upstream='initial.png';
 t.mock.method(globalThis,'fetch',async value=>{
   if(String(value).endsWith('.rex'))return Response.json({title:'订阅',icon:upstream,widgets:[{id:'a',url,version:'1.0.0'}]});
   if(String(value).endsWith('.png'))return String(value).endsWith('invalid.png')?new Response('<html>error</html>'):new Response(png,{headers:{'Content-Type':'image/png'}});
   return new Response(code('a','示例','2.0.0'));
 });
 const list=()=>f.ok('/api/admin/subscriptions');
 const add=async u=>(await f.ok('/api/admin/subscriptions',{method:'POST',json:{url:u}})).subscription;
 const row=async id=>(await list()).find(x=>x.id===id);
 const snapshot=id=>f.sql.prepare('SELECT next_sync_at,status,enabled,cursor,last_finished_at FROM subscription_sources WHERE id=?').get(id);
 const editIcon=(s,path='')=>f.call('/api/admin/subscriptions/'+s.id+'/icon',{method:'PATCH',json:{revision:s.revision,expected_icon_url:s.custom_icon_url,icon_mode:path?'custom':'auto',...(path?{icon_url:path}:{})}});
 const cycle=async id=>{const endpoint='/api/admin/subscriptions/'+id+'/sync';
   for(let i=0;i<5;i++)if((await f.ok(endpoint,{method:'POST',json:{}})).done)return;
   assert.fail('sync did not finish');};
 const {id}=await add(coll),first=await row(id),before=snapshot(id);
 assert.equal(first.icon_url,'https://source.example/initial.png');
 assert.equal((await f.call('/api/admin/subscriptions/'+id+'/icon',{method:'PATCH',auth:false,json:{}})).status,401);
 assert.equal((await editIcon(first,'https://source.example/chosen.png')).status,200);
 let s=await row(id);
 const custom=s.custom_icon_url;
 assert.match(custom,/^\/api\/icons\/[a-f0-9]{64}\.png$/);assert.equal(s.icon_url,custom);
 assert.deepEqual(snapshot(id),before);
 assert.equal((await editIcon(first)).status,409);
 assert.equal((await editIcon(s,'http://source.example/reject.png')).status,400);
 assert.equal((await editIcon(s,'https://source.example/invalid.png')).status,400);
 assert.equal((await editIcon(s,'https://127.0.0.1/reject.png')).status,400);
 assert.equal((await row(id)).icon_url,custom);
 await cycle(id); // First cycle consumes its cached snapshot.
 upstream='updated.png';await cycle(id);s=await row(id);
 assert.equal(s.icon_url,custom);assert.equal(s.upstream_icon_url,'https://source.example/updated.png');
 const [item]=await f.ok('/api/admin/subscriptions/'+id+'/items');
 assert.equal(item.version,'1.0.0');assert.equal(item.local_version,'2.0.0');assert.equal(item.local_encrypted,0);
 upstream='new-source.png';
 const p=await f.ok('/api/admin/subscriptions/preview',{method:'POST',json:{url:next}});
 await f.ok('/api/admin/subscriptions/'+id,{method:'PATCH',json:{url:next,preview_id:p.preview_id,revision:s.revision}});
 s=await row(id);
 assert.equal(s.custom_icon_url,custom);assert.equal(s.upstream_icon_url,'https://source.example/new-source.png');
 assert.equal((await editIcon(s)).status,200);s=await row(id);
 assert.equal(s.custom_icon_url,'');assert.equal(s.icon_url,'https://source.example/new-source.png');

 const single=await add(url);s=await row(single.id);
 assert.equal(s.upstream_icon_url,'');
 assert.equal((await editIcon(s,'https://source.example/chosen.png')).status,200);
 await cycle(single.id);s=await row(single.id);
 assert.equal(s.custom_icon_url,custom);
 assert.equal((await editIcon(s)).status,200);
 assert.equal((await row(single.id)).icon_url,'');
});
async function app(){
 const f=await fixture();f.sql.prepare('INSERT INTO sessions VALUES(?,?,?)').run('test',Date.now(),Date.now()+3600000);
 const worker=new HubCoordinator({waitUntil(){}},f.env);
 f.call=(path,{method='GET',json,body,auth=true,headers={}}={})=>worker.fetch(new Request('https://hub.example'+path,{method,headers:{...(auth?{cookie:'fwh_admin=test'}:{}),...(json?{'content-type':'application/json'}:{}),...headers},body:json?JSON.stringify(json):body}));
 f.ok=async(path,opts)=>{const r=await f.call(path,opts),b=await r.json();assert.ok(r.ok,JSON.stringify(b));return b;};
 f.add=(url,more={})=>f.ok('/api/admin/modules/import',{method:'POST',json:{url,...more}});
 f.share=async(id,alias)=>{const p=await f.ok('/api/admin/modules/'+id+'/share/preview',{method:'POST',json:alias?{alias}:{}});return f.ok('/api/admin/modules/'+id+'/share',{method:'PUT',json:{alias:p.alias,revision:p.revision}});};
 f.mod=id=>f.sql.prepare('SELECT * FROM modules WHERE id=?').get(id);
 return f;
}
async function restore(f,saved){
 const plan=structuredClone(saved),resources=[];
 for(const [id,file] of Object.entries(plan.files)){const bytes=Buffer.from(file.content,'base64');file.hash=createHash('sha256').update(bytes).digest('hex');file.size=bytes.length;delete file.content;resources.push({id,bytes});}
 const job=await f.ok('/api/admin/backup/restore/start',{method:'POST',json:plan});
 for(const r of resources)await f.ok('/api/admin/backup/restore/'+job.job_id+'/files/'+encodeURIComponent('module:'+r.id),{method:'PUT',body:r.bytes});
 return f.ok('/api/admin/backup/restore/'+job.job_id+'/commit',{method:'POST'});
}
test('readable alias returns exact encrypted bytes with GET/HEAD/CORS/304; rename keeps old links and module identity',async t=>{
 const bytes=enc('content'),f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(bytes));
 const r=await f.add('https://source.example/original.js'),m=r.added[0],first=await f.share(m.id,'音乐 & LX.js');
 for(const path of [first.path,m.public_path,'/api/modules/'+m.id+'.js','/api/modules/'+m.id+'/raw','/'+m.id+'.js']){
  const response=await f.call(path,{auth:false});assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),bytes);
 }
 const head=await f.call(first.path,{method:'HEAD',auth:false});assert.equal((await head.arrayBuffer()).byteLength,0);assert.equal(head.headers.get('access-control-allow-origin'),'*');assert.match(head.headers.get('content-disposition'),/filename\*=UTF-8/);
 const notModified=await f.call(first.path,{auth:false,headers:{'If-None-Match':head.headers.get('etag')}});assert.equal(notModified.status,304);
 const second=await f.share(m.id,'LX-music.js');assert.equal((await f.call(first.path,{auth:false})).status,200);assert.equal((await f.call(second.path,{auth:false})).status,200);
 assert.equal(f.mod(m.id).filename,'original.js');assert.equal(f.mod(m.id).widget_id,m.id);assert.notEqual(f.mod(m.id).widget_id,'single');
});
test('case-insensitive alias conflicts allocate suffix, stale confirmation rejects, tombstones cannot be reused',async t=>{
 const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(code()));
 const a=(await f.add('https://source.example/a.js')).added[0],b=(await f.add('https://source.example/b.js')).added[0];
 await f.share(a.id,'LX-music.js');const p=await f.ok('/api/admin/modules/'+b.id+'/share/preview',{method:'POST',json:{alias:'lx-MUSIC.js'}});assert.equal(p.conflict,true);assert.notEqual(p.alias,'lx-MUSIC.js');
 const stale=await f.ok('/api/admin/modules/'+a.id+'/share/preview',{method:'POST',json:{}});await f.share(a.id,'New-name.js');
 assert.equal((await f.call('/api/admin/modules/'+a.id+'/share',{method:'PUT',json:{alias:'Old-stale.js',revision:stale.revision}})).status,409);
 await f.ok('/api/admin/modules?id='+a.id,{method:'DELETE'});assert.equal((await f.call('/api/modules/LX-music.js',{auth:false})).status,404);
 const after=await f.ok('/api/admin/modules/'+b.id+'/share/preview',{method:'POST',json:{alias:'LX-music.js'}});assert.equal(after.conflict,true);
 for(const bad of ['../evil.js','x/y.js','x%2fy.js','x\\y.js'])assert.equal((await f.call('/api/admin/modules/'+b.id+'/share/preview',{method:'POST',json:{alias:bad}})).status,409);
 const reserved=await f.ok('/api/admin/modules/'+b.id+'/share/preview',{method:'POST',json:{alias:b.id+'.js'}});assert.equal(reserved.conflict,true);
});
test('preview identifies content not suffix and first commit reuses download; duplicate URL preserves pause and query order',async t=>{
 let hits=0;const f=await app();t.mock.method(globalThis,'fetch',async()=>{hits++;return new Response(code());});
 const url='https://source.example/raw?b=2&a=1#fragment',p=await f.ok('/api/admin/subscriptions/preview',{method:'POST',json:{url}});
 assert.equal(p.kind,'module');assert.equal(p.title,'LX-music');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,0);
 const r=await f.add(url,{preview_id:p.preview_id});assert.equal(hits,1);assert.equal(r.subscription.kind,'module');assert.equal(r.added[0].source_managed,1);
 await f.ok('/api/admin/subscriptions/'+r.subscription.id,{method:'PATCH',json:{enabled:0}});
 const duplicate=await f.add(url);assert.equal(hits,1);assert.equal(duplicate.subscription.id,r.subscription.id);assert.equal(f.sql.prepare('SELECT enabled,url FROM subscription_sources').get().enabled,0);assert.equal(f.sql.prepare('SELECT url FROM subscription_sources').get().url,'https://source.example/raw?b=2&a=1');
});
test('encrypted single subscription detects same-version byte changes, preserves identities, aliases and collection links',async t=>{
 let bytes=enc('version-one');const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(bytes));
 const r=await f.add('https://source.example/123av-stream.js'),m=r.added[0],s=r.subscription;
 assert.equal(m.title,'123av-stream');assert.equal(m.version,'');assert.notEqual(m.widget_id,'single');
 await f.share(m.id,'123av-stream.js');f.sql.exec("INSERT INTO collections VALUES('mine','mine','Mine','','',1,1)");f.sql.prepare('INSERT INTO collection_modules VALUES(?,?,0)').run('mine',m.id);f.sql.prepare('UPDATE modules SET note=?,group_id=?,sort_order=17 WHERE id=?').run('note','group',m.id);
 const old=f.mod(m.id),unchanged=await f.ok('/api/admin/subscriptions/'+s.id+'/sync',{method:'POST'});assert.equal(unchanged.summary.unchanged,1);assert.equal(f.mod(m.id).updated_at,old.updated_at);
 bytes=enc('version-two');const updated=await f.ok('/api/admin/subscriptions/'+s.id+'/sync',{method:'POST'});assert.equal(updated.summary.updated,1);
 const now=f.mod(m.id);for(const key of ['id','widget_id','filename','note','group_id','sort_order'])assert.equal(now[key],old[key]);assert.notEqual(now.content_hash,old.content_hash);
 const collection=await f.ok('/api/collections/mine.rex');assert.equal(collection.widgets[0].url,'https://hub.example/api/modules/123av-stream.js');assert.deepEqual(Buffer.from(await (await f.call('/api/modules/123av-stream.js',{auth:false})).arrayBuffer()),bytes);
});
test('failed fetch/type change, pause, manual override and cancellation never replace working files',async t=>{
 let bytes=enc('original'),type='application/javascript',status=200;const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(bytes,{status,headers:{'content-type':type}}));
 const r=await f.add('https://source.example/a.js'),m=r.added[0],id=r.subscription.id,old=f.mod(m.id);
 for(const body of ['<html>login</html>',JSON.stringify({widgets:[]})]){bytes=Buffer.from(body);assert.equal((await f.call('/api/admin/subscriptions/'+id+'/sync',{method:'POST'})).status,400);assert.equal(f.mod(m.id).file_key,old.file_key);}
 bytes=enc('new-content');await f.ok('/api/admin/modules/'+m.id+'/maintenance',{method:'PATCH',json:{manual:true}});
 const manual=await f.ok('/api/admin/subscriptions/'+id+'/sync',{method:'POST'});assert.equal(manual.summary.manual,1);assert.equal(f.mod(m.id).file_key,old.file_key);
 await f.ok('/api/admin/subscriptions/'+id,{method:'PATCH',json:{enabled:0}});assert.equal((await f.call('/api/admin/subscriptions/'+id+'/sync',{method:'POST'})).status,400);
 await f.ok('/api/admin/subscriptions/'+id,{method:'DELETE'});assert.ok(f.mod(m.id));assert.equal(f.mod(m.id).source_managed,1);assert.equal(f.mod(m.id).manual_override,1);
});
test('conditional 304 works only with a local file; missing local bytes trigger full recovery',async t=>{
 const f=await app(),body=code(),seen=[];t.mock.method(globalThis,'fetch',async(url,opts)=>{seen.push(opts.headers||{});return opts.headers?.['If-None-Match']?new Response(null,{status:304,headers:{etag:'"v1"'}}):new Response(body,{headers:{etag:'"v1"'}});});
 const r=await f.add('https://source.example/a.js'),id=r.subscription.id,m=r.added[0];
 await f.ok('/api/admin/subscriptions/'+id+'/sync',{method:'POST'});
 const next=await f.ok('/api/admin/subscriptions/'+id+'/sync',{method:'POST'});assert.equal(next.summary.unchanged,1);assert.equal(seen.at(-1)['If-None-Match'],'"v1"');
 f.files.delete(f.mod(m.id).file_key);await f.ok('/api/admin/subscriptions/'+id+'/sync',{method:'POST'});assert.ok(!seen.at(-1)['If-None-Match']);assert.equal(await (await f.call('/api/modules/'+m.id+'.js')).text(),body);
});
test('editing source preserves local module id, requires revision/identity confirmation and validates kind',async t=>{
 const f=await app();let body=code('original');t.mock.method(globalThis,'fetch',async()=>new Response(body));
 const r=await f.add('https://source.example/old.js'),m=r.added[0],s=(await f.ok('/api/admin/subscriptions'))[0];body=code('different','New title','2');
 const url='https://source.example/new.js',p=await f.ok('/api/admin/subscriptions/preview',{method:'POST',json:{url}}),change={url,title:'My source',revision:s.revision,preview_id:p.preview_id};
 assert.equal((await f.call('/api/admin/subscriptions/'+s.id,{method:'PATCH',json:change})).status,409);
 await f.ok('/api/admin/subscriptions/'+s.id,{method:'PATCH',json:{...change,confirm_identity:true}});assert.equal((await f.call('/api/admin/subscriptions/'+s.id,{method:'PATCH',json:change})).status,409);
 await f.ok('/api/admin/subscriptions/'+s.id+'/sync',{method:'POST'});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,1);assert.equal(f.mod(m.id).source_url,url);assert.equal(f.mod(m.id).title,'New title');assert.equal((await f.ok('/api/admin/subscriptions'))[0].title,'My source');
});
test('single and collection sources with equal URLs share one module; cancelling one preserves the other',async t=>{
 const f=await app();t.mock.method(globalThis,'fetch',async url=>new Response(String(url).includes('list')?JSON.stringify({title:'List',widgets:[{id:'remote',url:'https://source.example/a.js',title:'A'}]}):code()));
 const r=await f.add('https://source.example/a.js'),s=await f.add('https://source.example/list.rex');
 for(let i=0;i<2;i++)await f.ok('/api/admin/subscriptions/'+s.subscription.id+'/sync',{method:'POST'});
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM modules').get().n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM subscription_items WHERE module_id=?').get(r.added[0].id).n,2);
 await f.ok('/api/admin/subscriptions/'+r.subscription.id,{method:'DELETE'});assert.ok((await f.ok('/api/admin/subscriptions/'+s.subscription.id+'/sync',{method:'POST'})).done===false);
});
test('legacy source migration is explicit, bounded, repeatable and keeps manual modules paused',async t=>{
 const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(code()));const r=await f.add('https://source.example/old.js'),id=r.added[0].id;
 f.sql.exec('DELETE FROM subscription_items;DELETE FROM subscription_sources;UPDATE modules SET source_managed=0,manual_override=1');
 const p=await f.ok('/api/admin/subscriptions/legacy');assert.equal(p.rows[0].enabled,false);
 await f.ok('/api/admin/subscriptions/legacy',{method:'POST',json:{rows:p.rows}});assert.equal(f.mod(id).source_managed,1);assert.equal(f.mod(id).manual_override,1);assert.equal((await f.ok('/api/admin/subscriptions'))[0].enabled,0);assert.equal((await f.ok('/api/admin/subscriptions/legacy')).rows.length,0);
});
test('format 7 roundtrip includes current/historical aliases, source types and locks; conflicts fail before publication',async t=>{
 const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(code()));const r=await f.add('https://source.example/a.js'),m=r.added[0];await f.share(m.id,'Old.js');await f.share(m.id,'LX-music.js');
 const s=(await f.ok('/api/admin/subscriptions'))[0];await f.ok('/api/admin/subscriptions/'+s.id,{method:'PATCH',json:{title:'Pinned',revision:s.revision}});
 const saved=await f.ok('/api/admin/backup');assert.equal(saved.format,7);assert.equal(saved.meta.shareAliases.length,2);const dest=await app();await restore(dest,saved);
 assert.equal((await dest.ok('/api/admin/subscriptions'))[0].kind,'module');assert.equal((await dest.ok('/api/admin/subscriptions'))[0].title_locked,1);
 assert.equal(await (await dest.call('/api/modules/Old.js',{auth:false})).text(),code());assert.equal(await (await dest.call('/api/modules/LX-music.js',{auth:false})).text(),code());
 const broken=structuredClone(saved);broken.meta.shareAliases[0].module_id='different';await assert.rejects(()=>restore(dest,broken),/引用缺失|冲突/);
});

test('concurrent alias claims have one owner; failed publication is atomic and can be retried',async t=>{
 const f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(code()));const a=(await f.add('https://source.example/a.js')).added[0],b=(await f.add('https://source.example/b.js')).added[0];
 const pa=await f.ok('/api/admin/modules/'+a.id+'/share/preview',{method:'POST',json:{alias:'Shared.js'}}),pb=await f.ok('/api/admin/modules/'+b.id+'/share/preview',{method:'POST',json:{alias:'Shared.js'}});
 const results=await Promise.all([a,b].map((m,i)=>f.call('/api/admin/modules/'+m.id+'/share',{method:'PUT',json:{alias:'Shared.js',revision:[pa,pb][i].revision}})));assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
 const p=await f.ok('/api/admin/modules/'+a.id+'/share/preview',{method:'POST',json:{alias:'Retry.js'}});f.fail();assert.equal((await f.call('/api/admin/modules/'+a.id+'/share',{method:'PUT',json:{alias:p.alias,revision:p.revision}})).status,409);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM module_share_aliases WHERE alias='Retry.js'").get().n,0);await f.ok('/api/admin/modules/'+a.id+'/share',{method:'PUT',json:{alias:p.alias,revision:p.revision}});
});
test('source update DB failure preserves prior file pointer and retry succeeds; valid response filename is previewed',async t=>{
 const f=await app();let content=enc('original');t.mock.method(globalThis,'fetch',async()=>new Response(content,{headers:{'content-disposition':"inline; filename*=UTF-8''Music.js"}}));
 const p=await f.ok('/api/admin/subscriptions/preview',{method:'POST',json:{url:'https://source.example/raw'}});assert.equal(p.filename,'Music.js');
 const r=await f.add(p.url,{preview_id:p.preview_id}),m=r.added[0],old=f.mod(m.id);assert.equal(m.filename,'Music.js');content=enc('updated');
 const batch=f.env.DB.batch.bind(f.env.DB);let failed=false;f.env.DB.batch=async statements=>{if(!failed&&statements.some(s=>s.query.includes('UPDATE modules SET title='))){failed=true;throw Error('Injected publish failure');}return batch(statements);};
 assert.equal((await f.call('/api/admin/subscriptions/'+r.subscription.id+'/sync',{method:'POST'})).status,400);assert.equal(f.mod(m.id).file_key,old.file_key);assert.deepEqual(Buffer.from(await (await f.call('/api/modules/'+m.id+'.js')).arrayBuffer()),enc('original'));await f.ok('/api/admin/subscriptions/'+r.subscription.id+'/sync',{method:'POST'});assert.notEqual(f.mod(m.id).file_key,old.file_key);
});

test('module revalidation (304) skips the filename/share lookups; a 200 still carries Content-Disposition',async t=>{
 const bytes=enc('content'),f=await app();t.mock.method(globalThis,'fetch',async()=>new Response(bytes));
 const m=(await f.add('https://source.example/original.js')).added[0],path='/api/modules/'+m.id+'.js';
 f.resetCount();const full=await f.call(path,{auth:false});assert.equal(full.status,200);assert.match(full.headers.get('content-disposition'),/filename/);
 const fullQueries=f.counts().queries;
 f.resetCount();const same=await f.call(path,{auth:false,headers:{'If-None-Match':full.headers.get('etag')}});assert.equal(same.status,304);
 assert.ok(f.counts().queries<fullQueries,'304 should query less than a full response');
 for(const p of ['/'+m.id+'.js']){f.resetCount();const r=await f.call(p,{auth:false});const q=f.counts().queries;
  f.resetCount();const n=await f.call(p,{auth:false,headers:{'If-None-Match':r.headers.get('etag')}});assert.equal(n.status,304);assert.ok(f.counts().queries<q);}
});
