import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {fixture} from './test-fixtures/platform.mjs';
import {parseMeta,isEncrypted,getHTML} from './worker.js';
import {exportBackup,beginRestore,stageRestoreFile,commitRestore,setCollectionSlug,cleanupRestoreJobs} from './backup.js';
import {parseIconManifest,validateIcon,addIconSource,listIconSources,queryIcons,cacheIcon,prepareCollectionIcon,iconResponse,deleteIconSource,refreshIconSource,cleanupIcons} from './icons.js';
import {changeSubscriptionIcon,listSubscriptions} from './subscriptions.js';
import {WriteQueue} from './coordinator.js';
import {assertModuleFile} from './remote.js';
const helpers={parseMeta,isEncrypted},digest=b=>createHash('sha256').update(b).digest('hex');
const png=await readFile(new URL('./public/app-icons/rex-mulberry-v1-32.png',import.meta.url));
function planFrom(data){
 const dataCopy=structuredClone(data),resources=[];
 function decode(file){return file.encoding==='base64'?Buffer.from(file.content,'base64'):Buffer.from(file.content);}
 function append(resourceId,file){const bytes=decode(file);file.size=bytes.length;file.hash=digest(bytes);delete file.content;resources.push({id:resourceId,bytes});}
 for(const [id,file] of Object.entries(dataCopy.files))append('module:'+id,file);
 for(const p of dataCopy.meta.previousVersions||[])append('previous:'+p.module_id,p);
 for(const a of dataCopy.meta.icons?.assets||[])append('icon:'+a.hash,a);
 return {body:dataCopy,resources};
}
async function seed(f){
 const bytes=Buffer.from([82,69,88,69,78,67,10,255,0,128,65]);await f.env.KV.put('original',bytes);
 f.sql.prepare("INSERT INTO modules(id,filename,widget_id,title,version,note,group_id,sort_order,created_at,updated_at,file_key,file_size,is_encrypted,manifest_title,title_locked,source_managed) VALUES('mod','enc.js','external-id','自定义标题','1','备注','g',17,10,20,'original',?,1,'清单标题',1,1)").run(bytes.length);
 f.sql.exec("INSERT INTO groups VALUES('g','常用',3,10);INSERT INTO collections VALUES('col','mine','我的合集','描述','',10,20);INSERT INTO collection_modules VALUES('col','mod',0);INSERT INTO collection_aliases VALUES('oldmine','col');INSERT INTO subscription_sources(id,url,title,created_at) VALUES('s','https://example.com/list.rex','订阅',10);INSERT INTO subscription_items(source_id,remote_id,module_id,url,title) VALUES('s','remote','mod','https://example.com/module.js','清单标题')");
 await f.env.KV.put('previous',Buffer.from('REXENC\nprevious encrypted'));
 f.sql.prepare('INSERT INTO module_previous_versions VALUES(?,?,?,?,?)').run('mod','previous',JSON.stringify({filename:'old.js',title:'上一版'}),Date.now(),Date.now()+86400000);
 return bytes;
}
test('streamed backup restores arbitrary encrypted bytes and every identity into an empty database',async()=>{
 const original=await fixture(),bytes=await seed(original);
 const source=await addIconSource({...original.env,REMOTE_FETCH:async()=>new Response(JSON.stringify({name:'图标集',icons:[{name:'Blue',url:'https://example.com/a.png'}]}))},{url:'https://example.com/icons.json'});
 original.env.REMOTE_FETCH=async()=>new Response(png,{headers:{'Content-Type':'image/png'}});
 const entry=(await queryIcons(original.env,new URLSearchParams())).items[0],asset=await cacheIcon(original.env,entry.id);
 original.sql.prepare('UPDATE collections SET icon_url=?').run(asset.url);
 const response=await exportBackup(original.env),data=await response.json();await response.hubCompletion;
 assert.equal(data.format,7);assert.deepEqual(Buffer.from(data.files.mod.content,'base64'),bytes);assert.ok(!JSON.stringify(data).includes('admin_password'));
 const target=await fixture(),{body,resources}=planFrom(data),job=await beginRestore(target.env,body);
 for(const r of resources)await stageRestoreFile(target.env,job.job_id,r.id,Uint8Array.from(r.bytes).buffer,helpers);
 target.resetCount();assert.equal((await commitRestore(target.env,job.job_id)).modules,1);assert.ok(target.counts().queries<=50);
 const mod=target.sql.prepare('SELECT * FROM modules').get();assert.equal(mod.id,'mod');assert.equal(mod.widget_id,'external-id');assert.equal(mod.title,'自定义标题');assert.equal(mod.note,'备注');assert.equal(mod.sort_order,17);assert.equal(mod.group_id,'g');
 assert.deepEqual(target.files.get(mod.file_key),bytes);
 assert.equal(target.sql.prepare('SELECT module_id FROM collection_modules').get().module_id,'mod');assert.equal(target.sql.prepare('SELECT slug FROM collection_aliases').get().slug,'oldmine');
 assert.equal(target.sql.prepare('SELECT module_id FROM subscription_items').get().module_id,'mod');assert.equal(target.sql.prepare('SELECT name FROM groups').get().name,'常用');
 const previous=target.sql.prepare('SELECT * FROM module_previous_versions').get();assert.deepEqual(target.files.get(previous.kv_key),Buffer.from('REXENC\nprevious encrypted'));
 assert.deepEqual(Buffer.from(await (await iconResponse(target.env,asset.url,new Request('https://hub.example'+asset.url))).arrayBuffer()),png);
});
test('failed or incomplete restore never publishes metadata or deletes the live bytes; retry succeeds',async()=>{
 const f=await fixture(),bytes=await seed(f),backup=await (await exportBackup(f.env)).json(),{body,resources}=planFrom(backup),job=await beginRestore(f.env,body);
 await assert.rejects(()=>commitRestore(f.env,job.job_id),/尚未全部/);assert.deepEqual(f.files.get('original'),bytes);
 await assert.rejects(()=>stageRestoreFile(f.env,job.job_id,resources[0].id,Buffer.from('tampered'),helpers),/摘要不匹配/);
 for(const r of resources)await stageRestoreFile(f.env,job.job_id,r.id,r.bytes,helpers);
 f.fail();await assert.rejects(()=>commitRestore(f.env,job.job_id),/Injected D1 failure/);
 assert.equal(f.sql.prepare('SELECT file_key FROM modules').get().file_key,'original');assert.deepEqual(f.files.get('original'),bytes);assert.ok(!f.deleted.includes('original'));
 await commitRestore(f.env,job.job_id);assert.notEqual(f.sql.prepare('SELECT file_key FROM modules').get().file_key,'original');
});
test('a subscription pins its own icon across cache cleanup and format 7 backup/restore',async()=>{
 const f=await fixture();await seed(f);
 const source=()=>f.sql.prepare("SELECT * FROM subscription_sources WHERE id='s'").get();
 f.env.REMOTE_FETCH=async()=>new Response(png,{headers:{'Content-Type':'image/png'}});
 await changeSubscriptionIcon(f.env,source(),{revision:source().revision,expected_icon_url:'',icon_mode:'custom',icon_url:'https://example.com/icon.png'});
 const [{custom_icon_url:icon}]=await listSubscriptions(f.env);
 assert.ok(icon);
 f.sql.exec('UPDATE icon_assets SET last_used_at=0');
 await cleanupIcons(f.env);assert.equal((await iconResponse(f.env,icon,new Request('https://hub.example'+icon))).status,200);
 const saved=await (await exportBackup(f.env)).json(),target=await fixture(),{body,resources}=planFrom(saved);
 assert.equal(saved.format,7);
 const missing=structuredClone(body);missing.meta.icons.assets=[];
 await assert.rejects(()=>beginRestore(target.env,missing),/订阅引用的图标文件缺失/);
 const job=await beginRestore(target.env,body);
 for(const r of resources)await stageRestoreFile(target.env,job.job_id,r.id,r.bytes,helpers);
 await commitRestore(target.env,job.job_id);
 assert.equal((await listSubscriptions(target.env))[0].icon_url,icon);
 assert.deepEqual(Buffer.from(await (await iconResponse(target.env,icon,new Request('https://hub.example'+icon))).arrayBuffer()),png);
 await changeSubscriptionIcon(f.env,source(),{revision:source().revision,expected_icon_url:icon,icon_mode:'auto'});
 await cleanupIcons(f.env);assert.equal((await iconResponse(f.env,icon,new Request('https://hub.example'+icon))).status,404);
});
test('restore detects conflicting addresses, missing files and invalidation by reset; expired staging cleanup preserves live files',async()=>{
 const f=await fixture();await seed(f);const data=await (await exportBackup(f.env)).json(),{body,resources}=planFrom(data);
 const incomplete=structuredClone(body);delete incomplete.files.mod;await assert.rejects(()=>beginRestore(f.env,incomplete),/缺少文件/);
 const job=await beginRestore(f.env,body);await stageRestoreFile(f.env,job.job_id,resources[0].id,resources[0].bytes,helpers);
 f.sql.exec("INSERT OR REPLACE INTO settings VALUES('content_generation','new-generation')");await assert.rejects(()=>commitRestore(f.env,job.job_id),/取消/);
 f.sql.prepare('UPDATE restore_jobs SET expires_at=0').run();await cleanupRestoreJobs(f.env);assert.ok(f.files.has('original'));assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM restore_jobs').get().n,0);
 const conflict=structuredClone(body);conflict.meta.collections[0].id='different';await assert.rejects(()=>beginRestore(f.env,conflict),/路径已占用/);
});
test('legacy text backups preserve original IDs and chosen titles',async()=>{
 const f=await fixture(),bytes=Buffer.from('var WidgetMetadata={id:"old",title:"Code"};'),body={meta:{modules:[{id:'old-id',title:'我选的标题'}],collections:[{id:'old-col',slug:'legacy',title:'旧合集',moduleIds:['old-id']}]},files:{'old-id':{filename:'old.js',size:bytes.length,hash:digest(bytes)}}};
 const job=await beginRestore(f.env,body);await stageRestoreFile(f.env,job.job_id,'module:old-id',bytes,helpers);await commitRestore(f.env,job.job_id);
 assert.equal(f.sql.prepare('SELECT title FROM modules').get().title,'我选的标题');assert.equal(f.sql.prepare('SELECT module_id FROM collection_modules').get().module_id,'old-id');
});
test('collection path changes retain aliases transactionally and reject another collection’s historical path',async()=>{
 const f=await fixture();await seed(f);const aliases=await setCollectionSlug(f.env.DB,'col','newmine');
 await f.env.DB.batch([...aliases,f.env.DB.prepare('UPDATE collections SET slug=? WHERE id=?').bind('newmine','col')]);
 assert.equal(f.sql.prepare('SELECT collection_id FROM collection_aliases WHERE slug=?').get('mine').collection_id,'col');
 f.sql.exec("INSERT INTO collections VALUES('other','other','other','','',0,0)");await assert.rejects(()=>setCollectionSlug(f.env.DB,'other','mine'),/占用/);
});
test('icon sources support 2000 entries in bounded D1 transactions, search and 304 retain the cache',async()=>{
 const f=await fixture();let mode='manifest';f.env.REMOTE_FETCH=async(url)=>url.endsWith('icons.json')?(mode==='304'?new Response(null,{status:304,headers:{etag:'v1'}}):new Response(JSON.stringify({name:'图标集',icons:Array.from({length:2000},(_,i)=>({name:i===7?'blue':'Icon '+i,url:'https://example.com/'+i+'.png'}))}),{headers:{etag:'v1'}})):new Response(png,{headers:{'Content-Type':'image/png'}});
 f.resetCount();const source=await addIconSource(f.env,{url:'https://example.com/icons.json'});assert.equal(source.count,2000);assert.ok(f.counts().queries<50);assert.ok(f.counts().batchMax<=25);
 const found=await queryIcons(f.env,new URLSearchParams('q=蓝色'));assert.equal(found.total,1);const asset=await cacheIcon(f.env,found.items[0].id);
 mode='304';await refreshIconSource(f.env,source.id);assert.equal((await queryIcons(f.env,new URLSearchParams('q=blue'))).items[0].preview_url,asset.url);
 await deleteIconSource(f.env,source.id);assert.equal((await listIconSources(f.env)).length,0);assert.equal((await iconResponse(f.env,asset.url,new Request('https://hub.example'+asset.url))).status,200);
});
test('explicit single-source icon preview supports disabled sources and caps pagination without changing the picker',async()=>{
 const f=await fixture();
 f.env.REMOTE_FETCH=async()=>new Response(JSON.stringify({name:'图标集',icons:Array.from({length:67},(_,i)=>({name:'Icon '+i,url:'https://example.com/'+i+'.png'}))}));
 const enabled=await addIconSource(f.env,{url:'https://example.com/enabled.json'});
 const disabled=await addIconSource(f.env,{url:'https://example.com/disabled.json'});
 f.sql.prepare('UPDATE icon_sources SET enabled=0 WHERE id=?').run(disabled.id);
 const query=(o={})=>queryIcons(f.env,new URLSearchParams(o));
 const picker=await query({source:enabled.id,size:'60'});
 assert.equal(picker.items.length,12);assert.equal(picker.pages,6);
 assert.equal((await query({source:disabled.id})).total,0);
 const unscoped=await query({preview:'1',size:'60'});
 assert.equal(unscoped.total,67);assert.equal(unscoped.items.length,12);assert.ok(unscoped.items.every(row=>row.source_id===enabled.id));
 const first=await query({preview:'1',source:disabled.id,size:'999'}),second=await query({preview:'1',source:disabled.id,size:'60',page:'2'});
 assert.equal(first.total,67);assert.equal(first.pages,2);assert.equal(first.items.length,60);assert.equal(second.items.length,7);
 assert.equal(new Set([...first.items,...second.items].map(row=>row.id)).size,67);
 assert.ok([...first.items,...second.items].every(row=>row.source_id===disabled.id));
 assert.equal((await query({preview:'1',source:disabled.id,q:'Icon 66',size:'60'})).total,1);
 assert.equal((await query({preview:'1',source:disabled.id,size:'-1'})).items.length,12);
});
test('invalid icon sources and files fail without destroying the last good catalog or saved collection image',async()=>{
 const f=await fixture();let invalid=false;f.env.REMOTE_FETCH=async()=>new Response(invalid?'<html>error</html>':JSON.stringify({name:'good',icons:[{name:'A',url:'https://example.com/a.png'}]}));
 const source=await addIconSource(f.env,{url:'https://example.com/icons.json'});invalid=true;assert.equal((await refreshIconSource(f.env,source.id)).synced,false);assert.equal((await queryIcons(f.env,new URLSearchParams())).total,1);
 assert.throws(()=>validateIcon(Buffer.from('<svg/>'),'image/svg+xml'));assert.throws(()=>validateIcon(png,'text/html'));
 await assert.rejects(()=>prepareCollectionIcon(f.env,{icon_url:'https://example.com/not-image'},null),/仅支持/);
 assert.equal(await prepareCollectionIcon(f.env,{icon_url:'https://example.com/old.png'},{icon_url:'https://example.com/old.png'}),null);
});
test('one durable queue orders downloads, uploads and restore; failed operations release the queue',async()=>{
 const queue=new WriteQueue(),events=[];let release;const download=new Promise(r=>{release=r;});
 const old=queue.run(async()=>{events.push('download-start');await download;events.push('download-publish');return new Response('old');});
 const upload=queue.run(async()=>{events.push('upload-publish');return new Response('new');});
 await Promise.resolve();assert.deepEqual(events,['download-start']);release();await Promise.all([old,upload]);assert.deepEqual(events,['download-start','download-publish','upload-publish']);
 await assert.rejects(()=>queue.run(async()=>{throw Error('failed');}),/failed/);assert.equal((await queue.run(()=>new Response('ok'))).status,200);
});
test('backup stream holds the writer queue until the final byte or cancellation',async()=>{
 const f=await fixture();await seed(f);const queue=new WriteQueue(),backup=await queue.run(()=>exportBackup(f.env));let wrote=false;
 const write=queue.run(()=>{wrote=true;return new Response('ok');});await Promise.resolve();assert.equal(wrote,false);
 await backup.json();await write;assert.equal(wrote,true);assert.equal(queue.pending,0);
});
test('nested publication locks are reentrant and independent callers remain serialized',async()=>{
 const queue=new WriteQueue(),events=[];
 await Promise.all([queue.run(async()=>{events.push('outer');await queue.run(async()=>{events.push('inner');});events.push('done');}),queue.run(async()=>{events.push('next');})]);
 assert.deepEqual(events,['outer','inner','done','next']);assert.equal(queue.pending,0);
});
test('module validation rejects empty, HTML and JSON, accepts encrypted/obfuscated JS; all frontend scripts parse',()=>{
 for(const data of ['', '<!doctype html><html>', '<body>error', '{"error":true}'])assert.throws(()=>assertModuleFile(Buffer.from(data)));
 assertModuleFile(Buffer.from('REXENC\nencrypted bytes'));assertModuleFile(Buffer.from('(()=>{console.log(1)})()'));
 for(const script of getHTML().matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
 assert.match(getHTML(),/manifest.webmanifest/);assert.match(getHTML(),/选择合集图标/);assert.match(getHTML(),/#groupTabs\{flex-wrap:wrap/);
});

test('restore has two modes: merge (增量) keeps extra data, full (全量) makes the site equal the backup',async()=>{
 const source=await fixture();await seed(source);
 const response=await exportBackup(source.env),data=await response.json();await response.hubCompletion;
 async function extras(f,slug){
  await f.env.KV.put('xf',Buffer.from('extra module'));
  f.sql.prepare("INSERT INTO modules(id,filename,widget_id,title,version,note,group_id,sort_order,created_at,updated_at,file_key,file_size,is_encrypted,manifest_title,title_locked,source_managed) VALUES('extra','x.js','x','额外','1','',  'gx',1,10,20,'xf',12,0,'',1,0)").run();
  f.sql.exec("INSERT INTO groups VALUES('gx','额外分组',1,10);INSERT INTO collections VALUES('cx','"+slug+"','额外合集','','',10,20);INSERT INTO collection_modules VALUES('cx','extra',0)");
 }
 async function run(f,mode){
  const {body,resources}=planFrom(data);if(mode)body.mode=mode;
  const job=await beginRestore(f.env,body);
  for(const r of resources)await stageRestoreFile(f.env,job.job_id,r.id,Uint8Array.from(r.bytes).buffer,helpers);
  return commitRestore(f.env,job.job_id);
 }
 const ids=(f,t)=>f.sql.prepare('SELECT id FROM '+t+' ORDER BY id').all().map(r=>r.id);
 // merge: default and explicit both keep what the backup does not mention
 for(const mode of [undefined,'merge']){
  const f=await fixture();await extras(f,'other');
  const r=await run(f,mode);assert.equal(r.mode,'merge');assert.equal(r.removed,0);
  assert.deepEqual(ids(f,'modules'),['extra','mod']);assert.deepEqual(ids(f,'collections'),['col','cx']);assert.deepEqual(ids(f,'groups'),['g','gx']);
 }
 // full: everything not in the backup is removed, old files are queued for deletion
 const f=await fixture();await extras(f,'other');
 const r=await run(f,'full');assert.equal(r.mode,'full');assert.equal(r.removed,1);
 assert.deepEqual(ids(f,'modules'),['mod']);assert.deepEqual(ids(f,'collections'),['col']);assert.deepEqual(ids(f,'groups'),['g']);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM collection_modules').get().n,1);
 assert.ok(f.sql.prepare("SELECT 1 FROM resource_gc WHERE kv_key='xf'").get());
 // a live collection already using the backup's path blocks merge, but not full
 const g=await fixture();await extras(g,'mine');
 await assert.rejects(()=>run(g,'merge'),/已占用/);
 assert.equal((await run(g,'full')).mode,'full');assert.deepEqual(ids(g,'collections'),['col']);
 const bad=await fixture();await assert.rejects(()=>run(bad,'bogus'),/恢复方式无效/);
});
