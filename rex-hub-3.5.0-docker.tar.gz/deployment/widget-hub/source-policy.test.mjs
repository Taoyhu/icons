import {test} from 'node:test';
import assert from 'node:assert/strict';
import {assertFetchableUrl,configureSourcePolicy} from './worker.js';

test('default policy rejects local and private sources',()=>{
  configureSourcePolicy({});
  for(const u of ['http://localhost/a.js','http://127.0.0.1/a.js','http://192.168.1.5/a.js','http://10.0.0.2/a.js','http://169.254.169.254/x','http://nas.local/a.js','http://[::1]/a.js'])
    assert.throws(()=>assertFetchableUrl(u),/不允许/,u);
  assert.equal(assertFetchableUrl('https://example.com/a.js').hostname,'example.com');
});
test('SOURCE_ADDRESS_CHECK=false allows LAN sources but never metadata or numeric-obfuscated hosts',()=>{
  configureSourcePolicy({check:'false'});
  assert.equal(assertFetchableUrl('http://192.168.1.5:8080/a.js').hostname,'192.168.1.5');
  assert.equal(assertFetchableUrl('http://nas.local/a.js').hostname,'nas.local');
  for(const u of ['http://169.254.169.254/latest','http://0.0.0.0/a','http://224.0.0.1/a','http://0xa9fea9fe/latest'])
    assert.throws(()=>assertFetchableUrl(u),/不允许/,u);   // 0xa9fea9fe normalizes to 169.254.169.254
  // The URL parser turns 2130706433 into 127.0.0.1: loopback counts as LAN here, but stays blocked by default.
  assert.equal(assertFetchableUrl('http://2130706433/a').hostname,'127.0.0.1');
  configureSourcePolicy({});
  assert.throws(()=>assertFetchableUrl('http://2130706433/a'),/不允许/);
  configureSourcePolicy({check:'false'});
  assert.throws(()=>assertFetchableUrl('ftp://192.168.1.5/a'),/http/);
  configureSourcePolicy({});
});
test('TRUSTED_SOURCE_ORIGINS opens only the listed origins',()=>{
  configureSourcePolicy({trusted:'http://192.168.1.5:8080, https://hub.lan'});
  assert.equal(assertFetchableUrl('http://192.168.1.5:8080/x.js').port,'8080');
  assert.throws(()=>assertFetchableUrl('http://192.168.1.5:9090/x.js'),/不允许/);   // other port
  assert.throws(()=>assertFetchableUrl('http://192.168.1.6:8080/x.js'),/不允许/);   // other host
  configureSourcePolicy({});
});
