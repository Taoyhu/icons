import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './test-fixtures/platform.mjs';
import {normalizeRules,firstMatch,keywordsOf,saveAutoRules,loadAutoRules,applyAutoRules,runAutoRules,autoRulesTick} from './auto-rules.js';

test('rule validation rejects empty keywords and ranges, and normalizes the rest',()=>{
 assert.throws(()=>normalizeRules({rules:[{kw:' , ',fields:['title']}]}),/没有关键词/);
 assert.throws(()=>normalizeRules({rules:[{kw:'a',fields:['bogus']}]}),/匹配范围/);
 assert.throws(()=>normalizeRules({rules:new Array(101).fill({kw:'a',fields:['title']})}),/最多/);
 assert.throws(()=>normalizeRules(null),/格式/);
 const r=normalizeRules({rules:[{kw:'短剧，漫剧',fields:['title','title','x'],group:'g',cols:['c','c',5]}],auto:false});
 assert.deepEqual(r,{rules:[{kw:'短剧，漫剧',fields:['title'],group:'g',cols:['c']}],auto:false});
});

test('keywords split on commas of any width, case-insensitive; the first matching rule wins',()=>{
 assert.deepEqual(keywordsOf('Hanime, 里番，R18、jav\n'),['hanime','里番','r18','jav']);
 const rules=[{kw:'hanime, 成人',fields:['title','filename'],group:'adult'},{kw:'短剧',fields:['title'],group:'drama'}];
 assert.equal(firstMatch(rules,{title:'HANIME 精选',filename:''}).group,'adult');
 assert.equal(firstMatch(rules,{title:'成人短剧'}).group,'adult');
 assert.equal(firstMatch(rules,{title:'好看短剧',author:'成人'}).group,'drama');
 assert.equal(firstMatch(rules,{title:'好看',author:'短剧'}),null);
 assert.equal(firstMatch([{kw:'abc',fields:['sub'],group:'g'}],{sub:'ABC源'}).group,'g');
});

async function world(){
 const f=await fixture();
 f.sql.exec("INSERT INTO groups VALUES('g1','短剧',1,1);INSERT INTO groups VALUES('g2','其他',2,1);INSERT INTO collections VALUES('c1','one','合集一','','',1,1);INSERT INTO collections VALUES('c2','two','合集二','','',1,1);INSERT INTO collection_modules VALUES('c1','old',5);");
 const add=(id,title,group,created,filename='x.js')=>f.sql.prepare("INSERT INTO modules(id,filename,widget_id,title,version,note,group_id,sort_order,created_at,updated_at,file_key,file_size,is_encrypted,manifest_title,title_locked,source_managed) VALUES(?,?,?,?,'1','',?,1,?,?,'k',1,0,'',0,0)").run(id,filename,id,title,group,created,created);
 add('old','旧模块','',1);add('keep','短剧已分组','g2',1);
 return {f,add};
}

test('first save marks existing modules as seen; the scheduler then classifies only new, settled modules',async()=>{
 const {f,add}=await world();
 await saveAutoRules(f.env,{rules:[{kw:'短剧',fields:['title'],group:'g1',cols:['c1','c2']}],auto:true});
 assert.equal((await loadAutoRules(f.env)).configured,true);
 add('new1','好看短剧',  '',Date.now()-60000);
 add('young','刚进来的短剧','',Date.now());
 add('nomatch','别的','',Date.now()-60000);
 const r=await autoRulesTick(f.env);
 assert.deepEqual([r.checked,r.grouped,r.added],[2,1,2]);
 const g=id=>f.sql.prepare('SELECT group_id FROM modules WHERE id=?').get(id).group_id;
 assert.equal(g('new1'),'g1');assert.equal(g('old'),'');assert.equal(g('young'),'');assert.equal(g('nomatch'),'');
 assert.deepEqual(f.sql.prepare("SELECT collection_id c,position p FROM collection_modules WHERE module_id='new1' ORDER BY c").all().map(x=>[x.c,x.p]),[['c1',6],['c2',0]]);
 // the young module is left for a later tick, then handled; processed modules are not reprocessed
 f.sql.prepare("UPDATE modules SET created_at=? WHERE id='young'").run(Date.now()-60000);
 assert.equal((await autoRulesTick(f.env)).grouped,1);assert.equal(g('young'),'g1');
 assert.equal((await autoRulesTick(f.env)).skipped,true);
});

test('hand-grouped modules keep their group, collections are only added, auto=false and auto_all collections are respected',async()=>{
 const {f,add}=await world();
 f.sql.exec("CREATE TABLE IF NOT EXISTS collection_options(collection_id TEXT PRIMARY KEY,auto_all INTEGER DEFAULT 0);INSERT OR REPLACE INTO collection_options VALUES('c2',1)");
 const rules=[{kw:'短剧',fields:['title'],group:'g1',cols:['c1','c2']}];
 const r=await applyAutoRules(f.env,['keep','old'],rules);
 assert.deepEqual([r.grouped,r.added],[0,1]);
 assert.equal(f.sql.prepare("SELECT group_id FROM modules WHERE id='keep'").get().group_id,'g2');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM collection_modules WHERE collection_id='c2'").get().n,0);
 // auto=false: new modules are marked seen but not touched
 await saveAutoRules(f.env,{rules,auto:false});add('later','后来的短剧','',Date.now()-60000);
 await autoRulesTick(f.env);assert.equal(f.sql.prepare("SELECT group_id FROM modules WHERE id='later'").get().group_id,'');
 await saveAutoRules(f.env,{rules,auto:true});await autoRulesTick(f.env);
 assert.equal(f.sql.prepare("SELECT group_id FROM modules WHERE id='later'").get().group_id,'');
});

test('subscription source name can be matched; sweep only touches ungrouped modules',async()=>{
 const {f,add}=await world();
 f.sql.exec("INSERT INTO subscription_sources(id,url,title,created_at) VALUES('s1','https://a.example/x','表哥短剧源',1);INSERT INTO subscription_items(source_id,remote_id,module_id,url) VALUES('s1','r','old','https://a.example/x.js')");
 await saveAutoRules(f.env,{rules:[{kw:'表哥',fields:['sub'],group:'g1',cols:[]}],auto:true});
 const r=await runAutoRules(f.env,'ungrouped');
 assert.deepEqual([r.checked,r.grouped],[1,1]);
 assert.equal(f.sql.prepare("SELECT group_id FROM modules WHERE id='old'").get().group_id,'g1');
 await assert.rejects(()=>runAutoRules(f.env,'all'),/范围无效/);
});
