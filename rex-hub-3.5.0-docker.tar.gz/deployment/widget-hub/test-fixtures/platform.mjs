import {DatabaseSync} from 'node:sqlite';
import {bootstrap} from '../worker.js';
export async function fixture(){
 const sql=new DatabaseSync(':memory:');let failBatch=false,queries=0,batchMax=0;
 const DB={prepare(query){let args=[];return {query,bind(...a){if(a.length>100)throw Error('D1 binding limit');args=a;return this;},async first(){queries++;return sql.prepare(query).get(...args)||null;},async all(){queries++;return {results:sql.prepare(query).all(...args)};},async run(){queries++;const r=sql.prepare(query).run(...args);return {meta:{changes:Number(r.changes)}};}};},async batch(statements){batchMax=Math.max(batchMax,statements.length);if(failBatch){failBatch=false;throw Error('Injected D1 failure');}sql.exec('BEGIN');try{const out=[];for(const stmt of statements)out.push(await stmt.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const files=new Map(),deleted=[];
 const KV={async put(key,value){files.set(key,typeof value==='string'?Buffer.from(value):Buffer.from(value));},async get(key,type){const value=files.get(key);if(!value)return null;switch(type){case 'arrayBuffer':return Uint8Array.from(value).buffer;case 'json':return JSON.parse(value.toString());case 'stream':return new ReadableStream({start(c){for(let i=0;i<value.length;i+=5)c.enqueue(Uint8Array.from(value.subarray(i,i+5)));c.close();}});default:return value.toString();}},async delete(key){deleted.push(key);files.delete(key);}};
 const env={DB,KV,ATOMIC:work=>work()};await bootstrap(env);
 KV.getWithMetadata=async(key,type)=>({value:await KV.get(key,type),metadata:{u:1}});
 return {sql,env,files,deleted,fail(){failBatch=true;},resetCount(){queries=0;batchMax=0;},counts(){return {queries,batchMax};}};
}
