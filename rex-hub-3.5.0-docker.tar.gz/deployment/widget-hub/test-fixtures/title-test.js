// Local-only metadata/display test; not a playable module.
var WidgetMetadata = {
  id: 'title-display-test',
  title: '测试模块 (4K) [原画] <完整>',
  version: '1.0.0',
  author: 'Local test'
};
