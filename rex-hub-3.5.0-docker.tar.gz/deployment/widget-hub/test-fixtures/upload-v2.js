var WidgetMetadata = { id: 'upload-integration', title: 'Upload test', version: '2', author: 'Local test' };
function load() { return 2; }
