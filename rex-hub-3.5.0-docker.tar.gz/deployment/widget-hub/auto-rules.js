// Auto-classification rules (自动分类规则).
// Rules live in settings.auto_rules_v1; the set of modules already processed lives in
// settings.auto_rules_seen_v1. New modules (subscription sync, upload, import) are handled by the
// minute scheduler, so nothing depends on the admin page being open.
export const RULES_KEY = 'auto_rules_v1';
export const SEEN_KEY = 'auto_rules_seen_v1';
export const RULE_FIELDS = ['title', 'filename', 'author', 'sub'];
const MAX_RULES = 100, MAX_KEYWORDS = 500, MAX_COLLECTIONS = 50, MAX_SEEN = 20000, SETTLE_MS = 20000, TICK_LIMIT = 200;

const text = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const setting = async (env, key) => (await env.DB.prepare('SELECT value FROM settings WHERE key=?').bind(key).first())?.value;
const putSetting = (env, key, value) => env.DB.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)').bind(key, value);
export const keywordsOf = value => [...new Set(String(value || '').split(/[,，、;；\n]/).map(x => x.trim().toLowerCase()).filter(Boolean))];

export function normalizeRules(body) {
  if (!body || !Array.isArray(body.rules)) throw Error('规则格式不正确');
  if (body.rules.length > MAX_RULES) throw Error('规则最多 ' + MAX_RULES + ' 条');
  const rules = body.rules.map((rule, index) => {
    const kw = text(rule && rule.kw, MAX_KEYWORDS);
    if (!keywordsOf(kw).length) throw Error('规则 ' + (index + 1) + ' 没有关键词');
    const fields = [...new Set((Array.isArray(rule.fields) ? rule.fields : []).filter(f => RULE_FIELDS.includes(f)))];
    if (!fields.length) throw Error('规则 ' + (index + 1) + ' 至少选一个匹配范围');
    const cols = [...new Set((Array.isArray(rule.cols) ? rule.cols : []).filter(c => typeof c === 'string' && c && c.length <= 100))].slice(0, MAX_COLLECTIONS);
    return { kw, fields, group: text(rule.group, 100), cols };
  });
  return { rules, auto: body.auto !== false };
}

export async function loadAutoRules(env) {
  let data = null;
  try { data = JSON.parse(await setting(env, RULES_KEY) || 'null'); } catch { data = null; }
  if (!data || !Array.isArray(data.rules)) return { rules: [], auto: true, configured: false };
  return { rules: data.rules, auto: data.auto !== false, configured: true, updated_at: data.updated_at || 0 };
}

export async function saveAutoRules(env, body) {
  const clean = normalizeRules(body), now = Date.now();
  const statements = [putSetting(env, RULES_KEY, JSON.stringify({ ...clean, updated_at: now }))];
  // First save: everything that already exists counts as processed, so old modules are never swept silently.
  if (await setting(env, SEEN_KEY) === undefined) {
    const ids = ((await env.DB.prepare('SELECT id FROM modules LIMIT ?').bind(MAX_SEEN).all()).results || []).map(r => r.id);
    statements.push(putSetting(env, SEEN_KEY, JSON.stringify(ids)));
  }
  await env.DB.batch(statements);
  return { ok: true, ...clean, configured: true, updated_at: now };
}

// Pure matching: first rule that hits wins. `fields` maps field name -> text to search.
export function firstMatch(rules, fields) {
  const haystack = Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, String(v || '').toLowerCase()]));
  for (const rule of rules) {
    const words = keywordsOf(rule.kw);
    if (words.length && (rule.fields || []).some(f => words.some(w => (haystack[f] || '').includes(w)))) return rule;
  }
  return null;
}

async function rowsFor(env, sql, ids) {
  return (await env.DB.prepare(sql).bind(JSON.stringify(ids)).all()).results || [];
}

// Applies rules to the given module ids. Only ungrouped modules get a group; collections are only added.
export async function applyAutoRules(env, ids, rules) {
  const result = { checked: ids.length, grouped: 0, added: 0 };
  if (!ids.length || !rules.length) return result;
  const DB = env.DB, now = Date.now();
  const [groups, collections, autoAll] = await Promise.all([
    DB.prepare('SELECT id FROM groups').all(), DB.prepare('SELECT id FROM collections').all(),
    DB.prepare('SELECT collection_id FROM collection_options WHERE auto_all=1').all().catch(() => ({ results: [] }))
  ]);
  const groupIds = new Set((groups.results || []).map(r => r.id)), collectionIds = new Set((collections.results || []).map(r => r.id)),
    skipCollections = new Set((autoAll.results || []).map(r => r.collection_id));
  const positions = new Map(((await DB.prepare('SELECT collection_id, MAX(position) AS p FROM collection_modules GROUP BY collection_id').all()).results || []).map(r => [r.collection_id, Number(r.p) || 0]));
  const touched = new Set(), statements = [];
  for (let i = 0; i < ids.length; i += 100) {
    const chunk = ids.slice(i, i + 100);
    const modules = await rowsFor(env, 'SELECT id,title,manifest_title,filename,author,group_id FROM modules WHERE id IN (SELECT value FROM json_each(?))', chunk);
    const sources = new Map();
    for (const row of await rowsFor(env, 'SELECT si.module_id AS module_id, ss.title AS title FROM subscription_items si JOIN subscription_sources ss ON ss.id=si.source_id WHERE si.module_id IN (SELECT value FROM json_each(?))', chunk))
      sources.set(row.module_id, (sources.get(row.module_id) || '') + '\n' + (row.title || ''));
    const member = new Set((await rowsFor(env, 'SELECT collection_id,module_id FROM collection_modules WHERE module_id IN (SELECT value FROM json_each(?))', chunk)).map(r => r.collection_id + '\n' + r.module_id));
    for (const m of modules) {
      const rule = firstMatch(rules, { title: (m.title || '') + '\n' + (m.manifest_title || ''), filename: m.filename, author: m.author, sub: sources.get(m.id) });
      if (!rule) continue;
      if (rule.group && groupIds.has(rule.group) && !m.group_id) {
        statements.push(DB.prepare("UPDATE modules SET group_id=? WHERE id=? AND (group_id IS NULL OR group_id='')").bind(rule.group, m.id));
        result.grouped++;
      }
      for (const c of rule.cols || []) {
        if (!collectionIds.has(c) || skipCollections.has(c) || member.has(c + '\n' + m.id)) continue;
        const position = (positions.get(c) ?? -1) + 1;
        positions.set(c, position);
        statements.push(DB.prepare('INSERT OR IGNORE INTO collection_modules(collection_id,module_id,position) VALUES(?,?,?)').bind(c, m.id, position));
        touched.add(c); result.added++;
      }
    }
  }
  for (const c of touched) statements.push(DB.prepare('UPDATE collections SET updated_at=? WHERE id=?').bind(now, c));
  for (let i = 0; i < statements.length; i += 50) await DB.batch(statements.slice(i, i + 50));
  return result;
}

export async function runAutoRules(env, scope) {
  const { rules } = await loadAutoRules(env);
  if (!rules.length) throw Error('还没有设置规则');
  if (scope !== 'ungrouped') throw Error('整理范围无效');
  const ids = ((await env.DB.prepare("SELECT id FROM modules WHERE group_id IS NULL OR group_id='' ORDER BY created_at LIMIT 2000").all()).results || []).map(r => r.id);
  return { ok: true, ...await applyAutoRules(env, ids, rules) };
}

// Minute scheduler: process modules that appeared since the last tick. A module younger than
// SETTLE_MS is left for the next tick so its subscription link and metadata are in place.
export async function autoRulesTick(env) {
  const config = await loadAutoRules(env);
  if (!config.configured) return { skipped: true };
  const raw = await setting(env, SEEN_KEY);
  if (raw === undefined) return { skipped: true };
  let seen; try { seen = new Set(JSON.parse(raw || '[]')); } catch { seen = new Set(); }
  const all = (await env.DB.prepare('SELECT id,created_at FROM modules LIMIT ?').bind(MAX_SEEN).all()).results || [];
  const cutoff = Date.now() - SETTLE_MS;
  const fresh = all.filter(m => !seen.has(m.id) && (Number(m.created_at) || 0) <= cutoff).slice(0, TICK_LIMIT);
  const next = new Set(all.filter(m => seen.has(m.id)).map(m => m.id));
  if (!fresh.length && next.size === seen.size) return { skipped: true };
  const result = config.auto && config.rules.length ? await applyAutoRules(env, fresh.map(m => m.id), config.rules) : { checked: fresh.length, grouped: 0, added: 0 };
  for (const m of fresh) next.add(m.id);
  await putSetting(env, SEEN_KEY, JSON.stringify([...next])).run();
  return result;
}
