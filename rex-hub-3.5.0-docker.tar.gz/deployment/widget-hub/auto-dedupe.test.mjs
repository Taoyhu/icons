import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planAutoDedupe} from './duplicates.js';

function mod(id,o={}){return {id,title:o.title||'T'+id,version:o.version??'1.0.0',author:'',filename:id+'.js',effective_filename:id+'.js',
 encrypted:!!o.encrypted,size:10,updated_at:o.updated_at||1,group:'',has_source:!!o.has_source,has_share_alias:!!o.has_share_alias,paths:[],
 collections:o.collections||[],subscriptions:o.subscriptions||[],may_reimport:!!o.may_reimport,revision:'r'+id};}
const col=(slug,automatic=false)=>({title:slug,slug,automatic});
function report(modules,groups){return {modules,groups:groups.map((g,i)=>({key:'k'+i,token:'t'+i,module_ids:g.ids,reasons:g.reasons}))};}
const hash=[{type:'hash',value:'h'}],idCode=(ids)=>[{type:'id',value:'x',basis:Object.fromEntries(ids.map(i=>[i,'code']))}];

test('identical content: keeps the more referenced copy and removes the other',()=>{
 const r=planAutoDedupe(report([mod('a'),mod('b',{collections:[col('mine')]})],[{ids:['a','b'],reasons:hash}]));
 assert.equal(r.plan.length,1);assert.equal(r.plan[0].keep.id,'b');assert.deepEqual(r.plan[0].remove.map(x=>x.id),['a']);
});
test('plaintext same ID: keeps highest version (numeric, not string order)',()=>{
 const r=planAutoDedupe(report([mod('a',{version:'1.0.9'}),mod('b',{version:'1.0.10'}),mod('c',{version:'0.9.0'})],[{ids:['a','b','c'],reasons:idCode(['a','b','c'])}]));
 assert.equal(r.plan[0].keep.id,'b');assert.deepEqual(r.plan[0].remove.map(x=>x.id).sort(),['a','c']);
});
test('same version: keeps the newer file',()=>{
 const r=planAutoDedupe(report([mod('a',{updated_at:5}),mod('b',{updated_at:9})],[{ids:['a','b'],reasons:idCode(['a','b'])}]));
 assert.equal(r.plan[0].keep.id,'b');
});
test('unreadable version is never guessed',()=>{
 const r=planAutoDedupe(report([mod('a',{version:''}),mod('b')],[{ids:['a','b'],reasons:idCode(['a','b'])}]));
 assert.equal(r.plan.length,0);assert.match(r.skipped[0].reason,/版本读不出/);
});
test('filename-only and manifest-only matches are not touched',()=>{
 const r=planAutoDedupe(report([mod('a'),mod('b')],[{ids:['a','b'],reasons:[{type:'filename',value:'f'}]},{ids:['a','b'],reasons:[{type:'id',value:'x',basis:{a:'manifest',b:'manifest'}}]}]));
 assert.equal(r.plan.length,0);assert.equal(r.skipped.length,2);
});
test('encrypted modules are skipped in ID groups but identical encrypted bytes are deduped',()=>{
 const enc=[mod('a',{encrypted:true}),mod('b',{encrypted:true})];
 assert.equal(planAutoDedupe(report(enc,[{ids:['a','b'],reasons:idCode(['a','b'])}])).plan.length,0);
 assert.equal(planAutoDedupe(report(enc,[{ids:['a','b'],reasons:hash}])).plan.length,1);
});
test('group is skipped when deleting would lose subscription, share link or collection membership',()=>{
 const base=()=>[mod('a',{updated_at:9}),mod('b')];
 for(const [label,extra,re] of [
  ['subscription',{has_source:true,subscriptions:[{title:'s',enabled:true,active:true}],may_reimport:true},/订阅/],
  ['share',{has_share_alias:true},/分享链接/],
  ['collection',{collections:[col('only-b')]},/合集/]]){
  const [a,b]=base();Object.assign(b,extra);
  const r=planAutoDedupe(report([a,b],[{ids:['a','b'],reasons:idCode(['a','b'])}]));
  // a is newer same-version so it is kept; b is to be removed and carries a reference
  assert.equal(r.plan.length,0,label);assert.match(r.skipped[0].reason,re,label);
 }
});
test('automatic collections never block; manual collections held by the keeper too do not block',()=>{
 const r=planAutoDedupe(report([mod('a',{updated_at:9,collections:[col('m')]}),mod('b',{collections:[col('m'),col('auto',true)]})],[{ids:['a','b'],reasons:idCode(['a','b'])}]));
 assert.equal(r.plan.length,1);
});
test('overlapping groups where one module is both kept and removed are left for a human',()=>{
 const r=planAutoDedupe(report([mod('a',{version:'2.0.0'}),mod('b',{version:'1.0.0'}),mod('c',{version:'3.0.0'})],
  [{ids:['a','b'],reasons:idCode(['a','b'])},{ids:['a','c'],reasons:idCode(['a','c'])}]));
 assert.equal(r.plan.length,0);assert.equal(r.skipped.length,2);
});
test('nothing to do on an empty report',()=>{
 const r=planAutoDedupe({modules:[],groups:[]});assert.deepEqual([r.plan,r.skipped,r.total_remove],[[],[],0]);
});
