// Remote manifests are data only; never evaluate downloaded JavaScript.
import { withModuleLock } from './uploads.js';
import {resolveTitle,cleanTitle,METADATA_SCAN_BYTES} from './metadata.js';
import {prepareName,nameStatement,urlFilename,validateFilename} from './filenames.js';
import {autoAllInsert,assertAutoAllCapacity} from './auto-all.js';
import {assertModuleFile,assertFetchableUrl as assertPublicUrl} from './remote.js';
import {prepareCollectionIcon,assertStoredIcon} from './icons.js';
export async function upgradeSubscriptions(env){
 const columns=new Set((await env.DB.prepare('PRAGMA table_info(subscription_sources)').all()).results.map(c=>c.name));
 for(const d of ["kind TEXT NOT NULL DEFAULT 'collection'","title_locked INTEGER DEFAULT 0","revision TEXT NOT NULL DEFAULT ''","etag TEXT DEFAULT ''","last_modified TEXT DEFAULT ''"])
  if(!columns.has(d.split(' ')[0]))await env.DB.prepare('ALTER TABLE subscription_sources ADD COLUMN '+d).run();
 // [优化1] 逐项同步条件请求：给 subscription_items 补上游校验值两列（向后兼容加列）。
 const itemColumns=new Set((await env.DB.prepare('PRAGMA table_info(subscription_items)').all()).results.map(c=>c.name));
 for(const d of ["etag TEXT DEFAULT ''","last_modified TEXT DEFAULT ''"])
  if(!itemColumns.has(d.split(' ')[0]))await env.DB.prepare('ALTER TABLE subscription_items ADD COLUMN '+d).run();
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS source_previews(id TEXT PRIMARY KEY,url TEXT NOT NULL,kv_key TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,metadata TEXT NOT NULL,expires_at INTEGER NOT NULL,generation TEXT NOT NULL)`).run();
}
export const subscriptionSchema = [
  `CREATE TABLE IF NOT EXISTS source_previews(id TEXT PRIMARY KEY,url TEXT NOT NULL,kv_key TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,metadata TEXT NOT NULL,expires_at INTEGER NOT NULL,generation TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS subscription_sources (
    id TEXT PRIMARY KEY, url TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
    group_id TEXT DEFAULT '', enabled INTEGER DEFAULT 1,
    status TEXT DEFAULT 'idle', next_sync_at INTEGER DEFAULT 0,
    last_started_at INTEGER DEFAULT 0, last_finished_at INTEGER DEFAULT 0,
    last_error TEXT DEFAULT '', summary TEXT DEFAULT '{}', snapshot TEXT,
    cursor INTEGER DEFAULT 0, sort_base INTEGER DEFAULT 0,
    lease_until INTEGER DEFAULT 0, lease_token TEXT DEFAULT '', created_at INTEGER,
    kind TEXT NOT NULL DEFAULT 'collection',title_locked INTEGER DEFAULT 0,revision TEXT NOT NULL DEFAULT '',
    etag TEXT DEFAULT '',last_modified TEXT DEFAULT ''
  )`,
  `CREATE TABLE IF NOT EXISTS subscription_items (
    source_id TEXT NOT NULL, remote_id TEXT NOT NULL, module_id TEXT,
    url TEXT NOT NULL, title TEXT, version TEXT, author TEXT,
    description TEXT, required_version TEXT, active INTEGER DEFAULT 1,
    last_error TEXT DEFAULT '', etag TEXT DEFAULT '', last_modified TEXT DEFAULT '',
    PRIMARY KEY(source_id, remote_id)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_subscription_module ON subscription_items(module_id)`,
  `CREATE INDEX IF NOT EXISTS idx_module_source ON modules(source_url)`
];

const INTERVAL = 6 * 60 * 60 * 1000;
const BATCH = 6;
const MAX_ITEMS = 500;
const text = (value, max = 500) => typeof value === 'string' ? value.slice(0, max) : '';
const errorText = error => String(error?.message || error).slice(0, 500);
function subscriptionIcon(value, baseUrl) {
  if (typeof value !== 'string' || value.length > 2048 || !value.trim()) return '';
  try {
    const url = assertPublicUrl(new URL(value.trim(), baseUrl).href);
    return url.protocol === 'https:' && url.href.length <= 2048 ? url.href : '';
  } catch { return ''; }
}
const customIcon = value => typeof value==='string' && /^\/api\/icons\/[a-f0-9]{64}\.(png|jpg|webp)$/.test(value) ? value : '';
const storedSummary = "CASE WHEN json_valid(summary) THEN CASE WHEN json_type(summary)='object' THEN summary ELSE '{}' END ELSE '{}' END";
// Sync replaces its counters and upstream metadata, never the administrator's override.
const syncSummary = "json_patch(?,json_object('custom_icon_url',json_extract("+storedSummary+",'$.custom_icon_url')))";
function readSummary(value) {
  try { const result=JSON.parse(value||'{}');return result&&typeof result==='object'&&!Array.isArray(result)?result:{}; } catch { return {}; }
}
function sourceIcons(kind,summary) {
  const custom_icon_url=customIcon(summary.custom_icon_url);
  const upstream_icon_url=kind==='collection'?subscriptionIcon(summary.icon_url):'';
  return {custom_icon_url,upstream_icon_url,icon_url:custom_icon_url||upstream_icon_url};
}

export async function changeSubscriptionIcon(env,source,body) {
  const previous=sourceIcons(source.kind,readSummary(source.summary));
  if(body.revision!==source.revision||body.expected_icon_url!==previous.custom_icon_url)throw Error('订阅或图标已变化，请重新打开');
  const mode=body.icon_mode;
  let url='';
  if(mode==='custom'){
    const input=typeof body.icon_url==='string'?body.icon_url.trim():'';
    if(!customIcon(input)&&!subscriptionIcon(input))throw Error('请选择图标库中的图标，或输入有效的 HTTPS 图片地址');
    url=(await prepareCollectionIcon(env,{icon_url:input},null))?.url||'';
    if(!customIcon(url))throw Error('图标缓存失败');
    await assertStoredIcon(env,url);
  }else if(mode!=='auto'||body.icon_url!==undefined)throw Error('图标设置无效');
  const result=await env.DB.prepare("UPDATE subscription_sources SET summary=CASE WHEN ?='' THEN json_remove("+storedSummary+",'$.custom_icon_url') ELSE json_set("+storedSummary+",'$.custom_icon_url',?) END WHERE id=? AND revision=? AND COALESCE(json_extract("+storedSummary+",'$.custom_icon_url'),'')=?")
    .bind(url,url,source.id,source.revision,previous.custom_icon_url).run();
  if(!result.meta.changes)throw Error('订阅或图标已变化，请重新打开');
  return {ok:true};
}
function sourceFilename(url,header=''){
 const name=urlFilename(url,'module.js');if(/\.js$/i.test(name))return name;
 try{const utf=header.match(/filename\*=UTF-8''([^;]+)/i),ascii=header.match(/filename="([^"]+)"|filename=([^;]+)/i);
  const value=utf?decodeURIComponent(utf[1]):(ascii?.[1]||ascii?.[2]||'').trim();if(value)return validateFilename(value);
 }catch{}
 return name+'.js';
}

export function parseManifest(buffer, baseUrl, assertUrl) {
  const raw = new TextDecoder().decode(buffer).replace(/^\uFEFF/, '').trim();
  if (!raw.startsWith('{') && !raw.startsWith('[')) return null;
  let manifest;
  try { manifest = JSON.parse(raw); } catch { throw new Error('合集 JSON 格式不正确'); }
  if (!manifest || !Array.isArray(manifest.widgets)) throw new Error('不是有效的合集：缺少 widgets 列表');
  if (manifest.widgets.length > MAX_ITEMS) throw new Error('一个订阅源最多支持 500 个模块');
  const seen = new Set(), urls = new Set();
  const widgets = manifest.widgets.map(item => {
    if (!item || typeof item.url !== 'string') throw new Error('合集存在缺少下载地址的模块');
    const url = assertUrl(new URL(item.url, baseUrl).href);
    if (url.username || url.password) throw new Error('模块地址不能包含用户名或密码');
    url.hash = '';
    const remote_id = text(item.id, 200) || url.href;
    if (seen.has(remote_id) || urls.has(url.href)) throw new Error('合集存在重复的模块 ID 或地址');
    seen.add(remote_id); urls.add(url.href);
    return { remote_id, url: url.href, title: text(item.title), version: text(item.version, 100),
      author: text(item.author), description: text(item.description, 4000),
      required_version: text(item.requiredVersion, 100) || '0.0.1' };
  });
  return { title: text(manifest.title) || '未命名订阅', widgets,
    icon_url: subscriptionIcon(manifest.icon, baseUrl) || subscriptionIcon(manifest.logo, baseUrl) };
}

export async function addSubscription(env, rawUrl, groupId, helpers, prefetched, options={}) {
  const u = helpers.assertFetchableUrl(rawUrl);
  if (u.username || u.password) throw new Error('订阅地址不能包含用户名或密码');
  u.hash = '';
  const existing = await env.DB.prepare('SELECT id,kind FROM subscription_sources WHERE url = ?').bind(u.href).first();
  if (existing) return { ...existing, existing: true,added:[] };
  // Validate before persisting a subscription, including every module URL.
  const info={},buffer = prefetched || await helpers.fetchCapped(u.href, 10 * 1024 * 1024,info);
  const manifest = parseManifest(buffer, u.href, helpers.assertFetchableUrl);
  if(manifest&&buffer.byteLength>1024*1024)throw Error('合集超过 1 MB');
  if(!manifest){assertModuleFile(new Uint8Array(buffer),info.contentType);validateModule(buffer,helpers);}
  const kind=manifest?'collection':'module';let filename=options.filename||sourceFilename(u.href,info.contentDisposition);
  if(!/\.js$/i.test(filename))filename+='.js';
  const meta=manifest?{}:helpers.parseMeta(filename,new Uint8Array(buffer.slice(0,METADATA_SCAN_BYTES)));
  const title=manifest?.title||cleanTitle(meta.title)||filename.replace(/\.js$/i,'');
  const id = crypto.randomUUID();
  // Keep the icon with existing source metadata; the snapshot remains a widgets array.
  const summary = manifest?.icon_url ? {icon_url:manifest.icon_url} : {};
  await env.DB.prepare(`INSERT INTO subscription_sources
    (id,url,title,group_id,created_at,kind,revision,snapshot,summary) VALUES (?,?,?,?,?,?,?,?,?)`)
    .bind(id, u.href, title, groupId || '', Date.now(),kind,crypto.randomUUID(),manifest?JSON.stringify(manifest.widgets):null,JSON.stringify(summary)).run();
  if(kind==='module'){
   try{
    const item=singleItem(u.href);
    await env.DB.prepare(`INSERT INTO subscription_items(source_id,remote_id,url,active) VALUES(?,'single',?,1)`).bind(id,u.href).run();
    const source=await env.DB.prepare('SELECT * FROM subscription_sources WHERE id=?').bind(id).first();
    source.sort_base=await helpers.nextSortOrder(env.DB);
    const result=await syncItem(env,source,item,0,{...helpers,initialName:options,fetchCapped:async()=>buffer});
    const summary={added:0,updated:0,unchanged:0,manual:0,failed:0,removed:0};summary[result]++;
    await finishSingle(env,source,summary);
    const m=await env.DB.prepare('SELECT m.* FROM modules m JOIN subscription_items i ON i.module_id=m.id WHERE i.source_id=?').bind(id).first();
    return {id,kind,existing:false,added:m?[m]:[],done:true};
   }catch(e){await env.DB.batch([env.DB.prepare('DELETE FROM subscription_items WHERE source_id=?').bind(id),env.DB.prepare('DELETE FROM subscription_sources WHERE id=?').bind(id)]);throw e;}
  }
  return { id,kind, existing: false };
}

export async function listSubscriptions(env) {
  const { results } = await env.DB.prepare(`SELECT s.id,s.url,s.title,s.group_id,s.enabled,s.status,s.kind,s.title_locked,s.revision,
    s.next_sync_at,s.last_started_at,s.last_finished_at,s.last_error,s.summary,s.cursor,
    CASE WHEN s.snapshot IS NOT NULL THEN json_array_length(s.snapshot)
      ELSE (SELECT COUNT(*) FROM subscription_items i WHERE i.source_id=s.id AND i.active=1) END AS total,
    (SELECT COUNT(*) FROM subscription_items i JOIN modules m ON m.id=i.module_id
      WHERE i.source_id=s.id AND i.active=1) AS imported,
    (SELECT COUNT(*) FROM subscription_items i WHERE i.source_id=s.id AND i.active=0) AS removed
    FROM subscription_sources s ORDER BY s.created_at DESC`).all();
  return (results || []).map(s => {
    const summary = readSummary(s.summary);
    return { ...s, summary, ...sourceIcons(s.kind,summary) };
  });
}

async function stageManifest(env, source, helpers) {
  const cached=source.status==='idle'&&source.snapshot;
  const manifest=cached?{title:source.title,widgets:JSON.parse(source.snapshot),icon_url:subscriptionIcon(readSummary(source.summary).icon_url)}:parseManifest(await helpers.fetchCapped(source.url,1024*1024),source.url,helpers.assertFetchableUrl);
  if (!manifest) throw new Error('上游没有返回有效的合集');
  const removed = await env.DB.prepare(`SELECT remote_id FROM subscription_items
    WHERE source_id=? AND active=1`).bind(source.id).all();
  const ids = new Set(manifest.widgets.map(w => w.remote_id));
  const summary = { added: 0, updated: 0, unchanged: 0, failed: 0,
    removed: (removed.results || []).filter(w => !ids.has(w.remote_id)).length };
  if(manifest.icon_url)summary.icon_url=manifest.icon_url;
  const sortBase = await helpers.nextSortOrder(env.DB) - Math.max(0,manifest.widgets.length-1);
  // One bounded SQL update instead of one query per manifest item. New items are
  // materialized with their download batch, keeping large sources within free-tier limits.
  const statements = [env.DB.prepare(`UPDATE subscription_items SET active=CASE
    WHEN remote_id IN (SELECT value FROM json_each(?)) THEN 1 ELSE 0 END WHERE source_id=?`)
    .bind(JSON.stringify(manifest.widgets.map(w=>w.remote_id)),source.id)];
  // D1 batch is transactional: a malformed/incomplete manifest cannot mark everything removed.
  statements.push(env.DB.prepare(`UPDATE subscription_sources SET title=?,snapshot=?,cursor=0,
    sort_base=?,summary=${syncSummary},status='syncing',last_started_at=?,last_error='' WHERE id=?`)
    .bind(source.title_locked?source.title:manifest.title,JSON.stringify(manifest.widgets),sortBase,JSON.stringify(summary),Date.now(),source.id));
  await env.DB.batch(statements);
  return { ...source, title: manifest.title, snapshot: JSON.stringify(manifest.widgets), cursor: 0,
    sort_base: sortBase, summary: JSON.stringify(summary), status: 'syncing' };
}

function validateModule(buffer, helpers) {
  assertModuleFile(new Uint8Array(buffer));
  if (!buffer.byteLength) throw new Error('模块文件为空');
  const head = new TextDecoder().decode(buffer.slice(0, 32768)).replace(/^\uFEFF/, '').trim();
  if (helpers.isEncrypted(new Uint8Array(buffer))) return;
  if (/^(?:<!doctype\s+html|<html|<head|<body|\{|\[)/i.test(head)) {
    throw new Error('下载结果不是模块（返回了网页或 JSON），保留旧版本');
  }
  if (!/WidgetMetadata|\bexport\s|\bfunction\b|\b(?:const|let|var)\s/.test(head)) {
    throw new Error('无法识别为模块文件，保留旧版本');
  }
}

async function syncItem(env, source, item, index, helpers) {
  const mapping = await env.DB.prepare('SELECT module_id,etag,last_modified FROM subscription_items WHERE source_id=? AND remote_id=?')
    .bind(source.id,item.remote_id).first();
  let mod = mapping?.module_id ? await env.DB.prepare('SELECT * FROM modules WHERE id=?').bind(mapping.module_id).first() : null;
  if (!mod) mod = await env.DB.prepare('SELECT * FROM modules WHERE source_url=? ORDER BY created_at LIMIT 1').bind(item.url).first();
  let buffer=null,hash='';
  // [优化1] 本轮下载响应带回的上游校验值（与 buffer 来自同一响应才可绑定）；
  // null 表示本轮没有可绑定的校验值，结尾会清空旧值，防止内容回滚时误判 304。
  let freshValidators=null;
  if(!mod?.manual_override){
    // [优化1] 订阅同步主路径（forceFile 未设置）且本地已有该模块时改用
    // fetchRemote 抓取：存有校验值先发条件请求，上游 304 整份跳过；200 则把
    // 响应校验值与字节绑定存下，供下一轮条件请求。syncSingle 与新增订阅走的
    // 预取 buffer 路径（forceFile 已设置或 mod 不存在）保持原 fetchCapped 行为。
    const viaRemote=!!(mod&&helpers.fetchRemote&&helpers.forceFile===undefined);
    if(viaRemote&&(mapping?.etag||mapping?.last_modified)){
      let remote=null;
      try{
        const condHeaders={};
        if(mapping.etag)condHeaders['If-None-Match']=mapping.etag;
        if(mapping.last_modified)condHeaders['If-Modified-Since']=mapping.last_modified;
        remote=await helpers.fetchRemote(item.url,10*1024*1024,{headers:condHeaders,allowNotModified:true});
      }catch{remote=null;} // 条件请求本身失败就回退全量抓取，不让同步因此失败
      if(remote&&remote.status===304){
        await env.DB.prepare(`UPDATE subscription_items SET module_id=?,last_error=''
          WHERE source_id=? AND remote_id=?`).bind(mod.id,source.id,item.remote_id).run();
        return 'unchanged';
      }
      if(remote){buffer=remote.bytes;freshValidators={etag:remote.etag||'',lastModified:remote.lastModified||''};}
    }
    if(!buffer&&viaRemote){
      try{
        const full=await helpers.fetchRemote(item.url,10*1024*1024,{});
        buffer=full.bytes;freshValidators={etag:full.etag||'',lastModified:full.lastModified||''};
      }catch{buffer=null;freshValidators=null;} // 再回退 fetchCapped，错误口径与原来一致
    }
    if(!buffer){
      buffer=await helpers.fetchCapped(item.url,10*1024*1024);
    }
    validateModule(buffer,helpers);
    hash=helpers.toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer)));
  }
  // Equal URLs imported concurrently from two sources share one local identity.
  const urlHash = helpers.toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(item.url))));
  const id = mod?.id || [urlHash.slice(0,8),urlHash.slice(8,12),urlHash.slice(12,16),urlHash.slice(16,20),urlHash.slice(20,32)].join('-');
  // Downloads remain concurrent; catalog publication must serialize names shared
  // by different module IDs after cleaning (e.g. REX-video.js and video.js).
  return withModuleLock(env,'module:'+id,()=>withModuleLock(env,'filename-catalog',async()=>{
  mod=await env.DB.prepare('SELECT * FROM modules WHERE id=?').bind(id).first();
  if(mod?.manual_override){
    // [优化1] 手工接管后本地文件可能已被替换，旧校验值不再可信，一并清空。
    await env.DB.batch([env.DB.prepare(`UPDATE subscription_items SET module_id=?,last_error='',etag='',last_modified=''
      WHERE source_id=? AND remote_id=?`).bind(id,source.id,item.remote_id),
      env.DB.prepare('UPDATE modules SET source_managed=1 WHERE id=?').bind(id)]);
    return 'manual';
  }
  if(!buffer){
    buffer=await helpers.fetchCapped(item.url,10*1024*1024);
    validateModule(buffer,helpers);
    hash=helpers.toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer)));
  }
  const now = Date.now();
  const filename = mod?.filename || (source.kind==='module'?(helpers.initialName?.filename||urlFilename(item.url,'module.js')):id + '.js');
  const meta = helpers.isEncrypted(new Uint8Array(buffer))?{}:helpers.parseMeta(filename, new Uint8Array(buffer.slice(0, METADATA_SCAN_BYTES)));
  const codeTitle=cleanTitle(meta.title),manifestTitle=cleanTitle(item.title);
  const title = resolveTitle(mod||{filename},codeTitle,manifestTitle);
  // A literal from a readable module is more reliable than the collection declaration, which is often stale.
  // The manifest only fills in for files whose metadata is unreadable (REXENC). A previous value is kept
  // only when the file itself did not change, so an updated file never keeps the old version.
  const unchanged=!!mod&&mod.content_hash===hash;
  const version = text(meta.version,100).trim() || text(item.version,100).trim() || (unchanged?mod?.version:'') || '';
  const author = meta.author || item.author || (unchanged?mod?.author:'') || '';
  const changed = !mod || mod.content_hash !== hash || mod.title !== title || mod.version !== version ||
    mod.author !== author || mod.source_url !== item.url || mod.required_version !== item.required_version ||
    mod.code_title!==codeTitle || mod.manifest_title!==manifestTitle;
  let fileKey=mod?.file_key||'';
  if(!mod)await assertAutoAllCapacity(env.DB,1);
  const naming=await prepareName(env,id,filename,{existing:!!mod,preferred:mod?undefined:urlFilename(item.url,filename),requested:mod?undefined:helpers.initialName?.effective_filename||undefined});
  if (helpers.forceFile || !mod || mod.content_hash !== hash) {
    // Download and validate completely before replacing a working file.
    fileKey=(await helpers.putFile(env, id, buffer, now))||'';
  }
  const statements = [nameStatement(env,naming)];
  if (mod) {
    // Do not touch note, group_id, sort_order, widget_id or any collection links.
    statements.push(env.DB.prepare(`UPDATE modules SET title=?,version=?,author=?,file_size=?,
      is_encrypted=?,source_url=?,content_hash=?,required_version=?,updated_at=?,source_managed=1,
      file_key=?,metadata_id=?,code_title=?,manifest_title=?,title_scan_v1=1 WHERE id=?`)
      .bind(title,version,author,buffer.byteLength,helpers.isEncrypted(new Uint8Array(buffer)),item.url,
        hash,item.required_version,changed ? now : mod.updated_at,fileKey,meta.id||mod.metadata_id||'',codeTitle,manifestTitle,id));
  } else {
    statements.push(env.DB.prepare(`INSERT INTO modules (id,filename,widget_id,title,version,author,
      file_size,is_encrypted,source_url,note,group_id,sort_order,created_at,updated_at,content_hash,required_version,source_managed,
      code_title,manifest_title,title_scan_v1,generated_filename,metadata_id,file_key)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,1,1,?,?)`)
      .bind(id,filename,meta.id || (source.kind==='module'?id:item.remote_id),title,version,author,buffer.byteLength,
        helpers.isEncrypted(new Uint8Array(buffer)),item.url,item.description,source.group_id,
        source.sort_base + index,now,now,hash,item.required_version,codeTitle,manifestTitle,meta.id||'',fileKey));
  }
  if(!mod)statements.push(autoAllInsert(env.DB,id));
  // [优化1] 校验值只与同一次下载的字节绑定：fetchRemote 200 带回的才存，
  // 经 fetchCapped 等路径抓到的（freshValidators 为 null）把旧值清掉。
  statements.push(env.DB.prepare(`UPDATE subscription_items SET module_id=?,last_error='',etag=?,last_modified=?
    WHERE source_id=? AND remote_id=?`).bind(id,freshValidators?.etag||'',freshValidators?.lastModified||'',source.id,item.remote_id));
  try{await env.DB.batch(statements);}catch(e){if(fileKey&&fileKey!==mod?.file_key)await env.KV.delete(fileKey).catch(()=>{});throw e;}
  if(mod&&fileKey&&fileKey!==mod.file_key)await env.DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) VALUES(?,?)').bind(mod.file_key||'file:'+id,now).run();
  if(mod?.file_key?.startsWith('upload-content:') && mod.content_hash!==hash)
    await env.KV.delete(mod.file_key).catch(()=>{});
  return !mod ? 'added' : changed ? 'updated' : 'unchanged';
  }));
}

// Re-download only the modules whose last attempt failed; everything else stays untouched.
async function retryFailedItems(env, source, token, after, helpers) {
  if (source.status === 'syncing') throw new Error('正在分批同步，请先继续同步');
  const rows = (await env.DB.prepare(`SELECT remote_id,url,title,version,author,description,required_version
    FROM subscription_items WHERE source_id=? AND active=1 AND last_error!='' AND remote_id>?
    ORDER BY remote_id LIMIT 6`).bind(source.id, String(after || '')).all()).results || [];
  const summary = readSummary(source.summary);
  delete summary.custom_icon_url;
  for (let i = 0; i < rows.length; i += 2) {
    await Promise.all(rows.slice(i, i + 2).map(async (item, k) => {
      try {
        const r = await syncItem(env, source, item, i + k, helpers);
        summary[r] = (summary[r] || 0) + 1;
      } catch (error) {
        await env.DB.prepare('UPDATE subscription_items SET last_error=? WHERE source_id=? AND remote_id=?')
          .bind(errorText(error), source.id, item.remote_id).run();
      }
    }));
  }
  const remaining = (await env.DB.prepare(`SELECT COUNT(*) AS n FROM subscription_items
    WHERE source_id=? AND active=1 AND last_error!=''`).bind(source.id).first())?.n || 0;
  summary.failed = remaining;
  await env.DB.prepare(`UPDATE subscription_sources SET summary=${syncSummary},status=?,last_error=? WHERE id=? AND lease_token=?`)
    .bind(JSON.stringify(summary), remaining ? 'partial' : 'ok',
      remaining ? remaining + ' 个模块下载失败，已保留旧版本；可查看详情并重试' : '', source.id, token).run();
  return { ok: true, retry: true, tried: rows.length, remaining, summary,
    next: rows.length === 6 ? rows[5].remote_id : '' };
}

export async function syncSubscription(env, id, action, helpers, after = '') {
  const token = crypto.randomUUID(), now = Date.now();
  const lock = await env.DB.prepare(`UPDATE subscription_sources SET lease_until=?,lease_token=?
    WHERE id=? AND lease_until < ?`).bind(now + 150000,token,id,now).run();
  if (!lock.meta.changes) throw new Error('订阅源不存在或正在同步，请稍后刷新');
  let source;
  try {
    source = await env.DB.prepare('SELECT * FROM subscription_sources WHERE id=?').bind(id).first();
    if (!source.enabled) throw new Error('订阅源已暂停，请先恢复');
    if(source.kind==='module')return await syncSingle(env,source,helpers);
    if(action==='retry')return await retryFailedItems(env,source,token,after,helpers);
    // A repeated start resumes a pending cycle, never resets its cursor.
    if (source.status !== 'syncing' || !source.snapshot) {
      source = await stageManifest(env, source, helpers);
      return { ok: true, done: false, processed: 0, total: JSON.parse(source.snapshot).length };
    }
    const items = JSON.parse(source.snapshot), summary = readSummary(source.summary);
    delete summary.custom_icon_url;
    summary.manual=summary.manual||0;
    const cursor = source.cursor;
    const batch = items.slice(cursor,cursor+BATCH);
    if (batch.length) await env.DB.batch(batch.map(w=>env.DB.prepare(`INSERT INTO subscription_items
      (source_id,remote_id,url,title,version,author,description,required_version,active)
      VALUES (?,?,?,?,?,?,?,?,1) ON CONFLICT(source_id,remote_id) DO UPDATE SET
      url=excluded.url,title=excluded.title,version=excluded.version,author=excluded.author,
      description=excluded.description,required_version=excluded.required_version,active=1`)
      .bind(id,w.remote_id,w.url,w.title,w.version,w.author,w.description,w.required_version)));
    // Two concurrent downloads bound memory and finish within the source lease.
    for (let offset=cursor; offset<Math.min(items.length,cursor+BATCH); offset+=2) {
      await Promise.all(items.slice(offset,Math.min(offset+2,cursor+BATCH)).map(async (item,k) => {
        try { summary[await syncItem(env,source,item,offset+k,helpers)]++; }
        catch (error) {
          summary.failed++;
          await env.DB.prepare('UPDATE subscription_items SET last_error=? WHERE source_id=? AND remote_id=?')
            .bind(errorText(error),id,item.remote_id).run();
        }
      }));
    }
    const next = Math.min(items.length,cursor+BATCH), done = next >= items.length;
    const status = done ? (summary.failed ? 'partial' : 'ok') : 'syncing';
    await env.DB.prepare(`UPDATE subscription_sources SET cursor=?,summary=${syncSummary},status=?,snapshot=?,
      last_finished_at=?,next_sync_at=?,last_error=? WHERE id=? AND lease_token=?`)
      .bind(next,JSON.stringify(summary),status,done ? null : source.snapshot,
        done ? Date.now() : source.last_finished_at,done ? Date.now()+INTERVAL : 0,
        summary.failed ? summary.failed+' 个模块下载失败，已保留旧版本；可查看详情并重试' : '',id,token).run();
    return { ok: true, done, processed: next, total: items.length, summary };
  } catch (error) {
    await env.DB.prepare(`UPDATE subscription_sources SET last_error=?,status=?,next_sync_at=? WHERE id=? AND lease_token=?`)
      .bind(errorText(error),source?.status === 'syncing' ? 'syncing' : 'error',Date.now()+INTERVAL,id,token).run();
    throw error;
  } finally {
    await env.DB.prepare(`UPDATE subscription_sources SET lease_until=0,lease_token='' WHERE id=? AND lease_token=?`)
      .bind(id,token).run();
  }
}

export async function subscriptionTick(env, helpers) {
  await env.DB.prepare('DELETE FROM source_previews WHERE id IN (SELECT id FROM source_previews WHERE expires_at<? LIMIT 20)').bind(Date.now()).run();
  // Minute dispatcher resumes durable batches; each source starts a cycle every six hours.
  // Oldest serviced source first prevents a large subscription starving the others.
  const row = await env.DB.prepare(`SELECT id FROM subscription_sources WHERE enabled=1
    AND lease_until < ? AND (status='syncing' OR next_sync_at<=?)
    ORDER BY CASE WHEN status='syncing' THEN last_started_at ELSE next_sync_at END ASC LIMIT 1`)
    .bind(Date.now(),Date.now()).first();
  if (!row) return false;
  try { console.log('[subscription-sync]',row.id,await syncSubscription(env,row.id,'continue',helpers)); }
  catch (error) { console.log('[subscription-sync]',row.id,errorText(error)); }
  return true;
}

export async function subscriptionItems(env, id) {
  const { results } = await env.DB.prepare(`SELECT i.*,m.title AS local_title,m.version AS local_version,
    m.is_encrypted AS local_encrypted,m.updated_at FROM subscription_items i LEFT JOIN modules m ON m.id=i.module_id
    WHERE i.source_id=? ORDER BY i.active DESC,i.title`).bind(id).all();
  return results || [];
}

const singleItem=url=>({remote_id:'single',url,title:'',version:'',author:'',description:'',required_version:'0.0.1'});
async function finishSingle(env,source,summary,remote={}){
 await env.DB.prepare(`UPDATE subscription_sources SET summary=${syncSummary},status='ok',last_started_at=?,last_finished_at=?,next_sync_at=?,last_error='',snapshot=NULL,cursor=1,etag=?,last_modified=? WHERE id=?`)
 .bind(JSON.stringify(summary),Date.now(),Date.now(),Date.now()+INTERVAL,remote.etag||'',remote.lastModified||'',source.id).run();
}
async function syncSingle(env,source,helpers){
 const mod=await env.DB.prepare(`SELECT m.* FROM modules m JOIN subscription_items i ON i.module_id=m.id WHERE i.source_id=? AND i.remote_id='single'`).bind(source.id).first();
 const summary={added:0,updated:0,unchanged:0,manual:0,failed:0,removed:0};
 if(mod?.manual_override){summary.manual=1;await finishSingle(env,source,summary);return {ok:true,done:true,processed:1,total:1,summary};}
 let remote={},buffer,forceFile=false;
 if(helpers.fetchRemote){
  const local=mod?await env.KV.get(mod.file_key||'file:'+mod.id,'stream'):null;
  if(local)await local.cancel();
  forceFile=!local;
  const headers={};if(local&&source.etag)headers['If-None-Match']=source.etag;if(local&&source.last_modified)headers['If-Modified-Since']=source.last_modified;
  remote=await helpers.fetchRemote(source.url,10*1024*1024,{headers,allowNotModified:!!local});
  if(remote.status===304){summary.unchanged=1;await finishSingle(env,source,summary,{etag:remote.etag||source.etag,lastModified:remote.lastModified||source.last_modified});return {ok:true,done:true,processed:1,total:1,summary};}
  buffer=remote.bytes.buffer;assertModuleFile(remote.bytes,remote.contentType);
 }else buffer=await helpers.fetchCapped(source.url,10*1024*1024);
 validateModule(buffer,helpers);
 const current=await env.DB.prepare('SELECT * FROM subscription_sources WHERE id=?').bind(source.id).first();
 if(!current?.enabled||current.url!==source.url||current.revision!==source.revision)throw Error('来源已变化，取消旧同步');
 await env.DB.prepare(`INSERT INTO subscription_items(source_id,remote_id,url,active) VALUES(?,'single',?,1) ON CONFLICT(source_id,remote_id) DO UPDATE SET url=excluded.url,active=1`).bind(source.id,source.url).run();
 source.sort_base=await helpers.nextSortOrder(env.DB);
 summary[await syncItem(env,source,singleItem(source.url),0,{...helpers,forceFile,fetchCapped:async()=>buffer})]++;
 await finishSingle(env,source,summary,remote);return {ok:true,done:true,processed:1,total:1,summary};
}

export async function findDuplicates(env,meta,filename,url){
 // Same internal id (plaintext) or same file name (also covers REXENC files whose id is unreadable),
 // excluding the module that this exact URL already feeds.
 const id=meta?.id||'',name=String(filename||'');
 const rows=(await env.DB.prepare(`SELECT id,title,filename,version,metadata_id,widget_id,is_encrypted,source_url,source_managed FROM modules
  WHERE (?1<>'' AND (metadata_id=?1 OR (is_encrypted=0 AND widget_id=?1 AND widget_id<>id))) OR (?2<>'' AND filename=?2)`).bind(id,name).all()).results||[];
 return rows.filter(m=>m.source_url!==url).map(m=>({id:m.id,title:m.title,filename:m.filename,version:m.version||'',
  subscribed:!!(m.source_managed||m.source_url),matched_by:id&&(m.metadata_id===id||(!m.is_encrypted&&m.widget_id===id))?'模块 ID':'文件名'}));
}
export async function previewSource(env,rawUrl,helpers){
 const u=helpers.assertFetchableUrl(rawUrl);u.hash='';const info={};
 const buffer=await helpers.fetchCapped(u.href,10*1024*1024,info),manifest=parseManifest(buffer,u.href,helpers.assertFetchableUrl);
 if(manifest&&buffer.byteLength>1024*1024)throw Error('合集超过 1 MB');
 if(!manifest){assertModuleFile(new Uint8Array(buffer),info.contentType);validateModule(buffer,helpers);}
 const filename=sourceFilename(u.href,info.contentDisposition),meta=manifest?{}:helpers.parseMeta(filename,new Uint8Array(buffer.slice(0,METADATA_SCAN_BYTES)));
 const existing=await env.DB.prepare('SELECT id,title,manual_override,metadata_id FROM modules WHERE source_url=? LIMIT 1').bind(u.href).first();
 const source=await env.DB.prepare('SELECT id,kind FROM subscription_sources WHERE url=?').bind(u.href).first();
 const duplicates=manifest||existing?[]:await findDuplicates(env,meta,filename,u.href);
 const id=crypto.randomUUID(),key='source-preview:'+id,kind=manifest?'collection':'module',title=manifest?.title||cleanTitle(meta.title)||filename.replace(/\.js$/i,'');
 const generation=(await env.DB.prepare("SELECT value FROM settings WHERE key='content_generation'").first())?.value||'0';
 await env.KV.put(key,buffer,{expirationTtl:600});
 const icon_url=manifest?.icon_url||'';
 await env.DB.prepare('INSERT INTO source_previews VALUES(?,?,?,?,?,?,?,?)').bind(id,u.href,key,kind,title,JSON.stringify({...meta,source_filename:filename,icon_url}),Date.now()+600000,generation).run();
 return {ok:true,preview_id:id,url:u.href,kind,title,filename,metadata_id:meta.id||'',existing_module:existing,existing_source:source,duplicates,total:manifest?.widgets.length||1,icon_url};
}
export async function readSourcePreview(env,body){
 const p=await env.DB.prepare('SELECT * FROM source_previews WHERE id=?').bind(body.preview_id||'').first();
 const generation=(await env.DB.prepare("SELECT value FROM settings WHERE key='content_generation'").first())?.value||'0';
 if(!p||p.expires_at<Date.now()||p.generation!==generation)throw Error('链接预览已过期，请重新识别');
 if(body.url){const u=new URL(body.url);u.hash='';if(u.href!==p.url)throw Error('地址已修改，请重新识别');}
 const buffer=await env.KV.get(p.kv_key,'arrayBuffer');if(!buffer)throw Error('预览文件已过期，请重新识别');
 return {...p,buffer,meta:JSON.parse(p.metadata)};
}
export async function editSource(env,source,body,helpers){
 if(body.revision!==source.revision)throw Error('来源已变化，请重新打开');
 const url=body.url?helpers.assertFetchableUrl(body.url):new URL(source.url);url.hash='';
 let nextSummary=null;
 if(url.href!==source.url){
  const p=await readSourcePreview(env,body);if(p.kind!==source.kind)throw Error('不能改变已保存的来源类型');
  if(await env.DB.prepare('SELECT id FROM subscription_sources WHERE url=? AND id!=?').bind(url.href,source.id).first())throw Error('此地址已被其他订阅使用');
  if(source.kind==='collection'){
   const summary={...readSummary(source.summary)},icon=subscriptionIcon(p.meta.icon_url);
   if(icon)summary.icon_url=icon;else delete summary.icon_url;
   nextSummary=JSON.stringify(summary);
  }
  if(source.kind==='module'){
   const m=await env.DB.prepare(`SELECT m.* FROM modules m JOIN subscription_items i ON i.module_id=m.id WHERE i.source_id=? AND i.remote_id='single'`).bind(source.id).first();
   if(m?.metadata_id&&p.meta.id&&m.metadata_id!==p.meta.id&&!body.confirm_identity)throw Error('新链接内部 ID 与原模块不同，请明确确认替换来源');
  }
 }
 const title=body.title===undefined?source.title:cleanTitle(body.title);if(!title)throw Error('来源名称不能为空');
 await env.DB.batch([
  env.DB.prepare(`UPDATE subscription_sources SET url=?,title=?,title_locked=?,revision=?,next_sync_at=0,status='idle',snapshot=NULL,cursor=0,etag='',last_modified='',summary=COALESCE(?,summary) WHERE id=?`).bind(url.href,title,body.title===undefined?source.title_locked:1,crypto.randomUUID(),nextSummary,source.id),
  ...(source.kind==='module'?[env.DB.prepare("UPDATE subscription_items SET url=? WHERE source_id=? AND remote_id='single'").bind(url.href,source.id)]:[])
 ]);return {ok:true};
}
export async function legacySources(env,body){
 const rows=(await env.DB.prepare(`SELECT m.id,m.title,m.source_url,m.manual_override,m.updated_at,m.file_key FROM modules m WHERE COALESCE(m.source_url,'')!='' AND m.source_managed=0 AND NOT EXISTS(SELECT 1 FROM subscription_items i WHERE i.module_id=m.id) ORDER BY m.created_at`).all()).results;
 if(!body)return {ok:true,rows:rows.map(m=>({...m,revision:JSON.stringify(m),enabled:!m.manual_override}))};
 if(!Array.isArray(body.rows)||!body.rows.length||body.rows.length>10)throw Error('每批请选择 1～10 个来源');
 const statements=[];
 for(const r of body.rows){
  const m=rows.find(m=>m.id===r.id);if(!m||JSON.stringify(m)!==r.revision)throw Error('模块已变化，请重新预览');
  const u=new URL(m.source_url);u.hash='';const old=await env.DB.prepare('SELECT * FROM subscription_sources WHERE url=?').bind(u.href).first();
  if(old&&old.kind!=='module')throw Error('地址已属于合集订阅');
  if(old&&await env.DB.prepare('SELECT module_id FROM subscription_items WHERE source_id=? AND module_id!=?').bind(old.id,m.id).first())throw Error('地址已绑定其他模块，请在订阅中处理');
  const id=old?.id||crypto.randomUUID();
  if(!old)statements.push(env.DB.prepare(`INSERT INTO subscription_sources(id,url,title,enabled,created_at,kind,revision) VALUES(?,?,?,?,?,'module',?)`).bind(id,u.href,m.title,m.manual_override?0:1,Date.now(),crypto.randomUUID()));
  statements.push(env.DB.prepare(`INSERT INTO subscription_items(source_id,remote_id,url,module_id,active) VALUES(?,'single',?,?,1) ON CONFLICT(source_id,remote_id) DO UPDATE SET module_id=excluded.module_id`).bind(id,u.href,m.id),env.DB.prepare('UPDATE modules SET source_managed=1 WHERE id=?').bind(m.id));
 }
 await env.DB.batch(statements);return {ok:true,processed:body.rows.length};
}
