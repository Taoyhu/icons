// One Durable Object owns every writer, including cron. The queue spans whole
// mutations (download through publication); public reads stay responsive.
import {AsyncLocalStorage} from 'node:async_hooks';
export class WriteQueue{
  constructor(){this.tail=Promise.resolve();this.pending=0;this.context=new AsyncLocalStorage();}
  async run(work){
    if(this.context.getStore()===this)return work();
    if(this.pending>=24)throw Error('后台正在处理其他操作，请稍后重试');
    this.pending++;const previous=this.tail;let release;this.tail=new Promise(r=>{release=r;});
    await previous;
    let deferred=false;
    try{
      const response=await this.context.run(this,work);
      if(response?.hubCompletion){deferred=true;response.hubCompletion.then(()=>{this.pending--;release();},()=>{this.pending--;release();});}
      return response;
    }finally{if(!deferred){this.pending--;release();}}
  }
}
