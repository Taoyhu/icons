export const autoRulesStyles=String.raw`
.ar-modal{max-width:460px}
.ar-modal h3{margin:0 0 6px}
.ar-desc{font-size:12.5px;line-height:1.55;color:var(--text2);margin:0 0 12px}
.ar-auto{display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:14px;background:var(--field);margin-bottom:12px;font-size:13.5px;font-weight:600;line-height:1.45}
.ar-auto input{margin-top:3px;width:18px;height:18px;flex:none}
.ar-rule{border:1px solid var(--div);border-radius:16px;padding:12px;margin-bottom:12px;background:var(--bg)}
.ar-head{display:flex;align-items:center;gap:6px;margin-bottom:10px}
.ar-head strong{flex:1;font-size:14px}
.ar-head .btn{padding:5px 10px;font-size:12.5px}
.ar-rule input.ar-kw,.ar-rule select{width:100%;box-sizing:border-box;padding:11px 12px;border-radius:12px;border:1px solid var(--div);background:var(--field);color:var(--text);font:inherit;font-size:14.5px}
.ar-label{font-size:12px;font-weight:600;color:var(--text2);margin:10px 0 6px}
.ar-chips{display:flex;flex-wrap:wrap;gap:6px}
.ar-chip{border:1px solid transparent;background:var(--field);color:var(--text2);border-radius:999px;padding:6px 12px;font:inherit;font-size:12.5px;font-weight:600;cursor:pointer}
.ar-chip[aria-pressed=true]{background:color-mix(in srgb,var(--accent) 14%,transparent);border-color:var(--accent);color:var(--accent)}
.ar-empty{font-size:12.5px;color:var(--text2);padding:6px 0}
.ar-error{color:var(--hub-bad);font-size:12.5px;line-height:1.45;margin:6px 0;min-height:0}
.ar-error:empty{display:none}
.ar-foot{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.ar-foot .btn{flex:1 1 auto}
.ar-del{color:var(--hub-bad)}
`;

export const autoRulesUI=String.raw`
(function(){
 var FIELD_NAMES=[['title','标题'],['filename','文件名'],['author','作者'],['sub','订阅源']];
 var icon='<svg class="hub-tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h10M4 12h7M4 18h5"/><path d="m15 15 2.5 2.5L21 13"/></svg>';
 var chev='<span class="chev" aria-hidden="true"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m6 3 5 5-5 5"/></svg></span>';
 var anchor=document.getElementById('filenameSettings')||document.querySelector('#page-settings .stat-box');
 if(!anchor)return;
 var section=document.createElement('section');section.id='autoRuleSettings';
 section.innerHTML='<div class="set-sec">自动分类</div><div class="set-group hub-tool-group"><button type="button" class="set-row hub-tool-row" id="openAutoRules">'+icon+
  '<span class="hub-tool-meta"><strong>自动分类规则</strong><small id="autoRulesSummary">按关键词把新模块放进分组、加入合集</small></span>'+chev+'</button></div>'+
  '<p class="hub-tool-hint">订阅同步或上传的新模块，会在后台按规则自动整理，不用打开本页。</p>';
 anchor.after(section);
 var summary=section.querySelector('#autoRulesSummary');
 async function load(){
  var r=await api('/api/admin/auto-rules');
  if(!r||!Array.isArray(r.rules))throw Error((r&&r.error)||'读取规则失败');
  return r;
 }
 async function refreshSummary(){
  try{var r=await load();summary.textContent=r.configured&&r.rules.length?(r.auto?'已开启':'已关闭')+' · '+r.rules.length+' 条规则':'还没有规则';}catch(e){}
 }
 var base=renderSettings;renderSettings=function(){var out=base.apply(this,arguments);void refreshSummary();return out;};
 section.querySelector('#openAutoRules').onclick=async function(){
  var button=this;button.disabled=true;
  try{open(await load());}catch(e){toast(e.message);}finally{button.disabled=false;}
 };
 function open(config){
  var groups=state.groups||[],collections=state.collections||[];
  var draft={auto:config.auto!==false,rules:JSON.parse(JSON.stringify(config.rules||[]))};
  if(!draft.rules.length)draft.rules.push(blank());
  function blank(){return {kw:'',fields:['title','filename'],group:'',cols:[]};}
  var overlay=document.createElement('div');overlay.className='modal-overlay';
  overlay.innerHTML='<div class="modal ar-modal" role="dialog" aria-modal="true" aria-label="自动分类规则"></div>';
  document.body.appendChild(overlay);
  var box=overlay.firstChild,busy=false;
  function close(){overlay.remove();}
  overlay.addEventListener('mousedown',function(e){overlay._down=e.target===overlay;});
  overlay.addEventListener('click',function(e){if(e.target===overlay&&overlay._down&&!busy)close();});
  function collect(){
   box.querySelectorAll('.ar-rule').forEach(function(card,i){var r=draft.rules[i];if(r)r.kw=card.querySelector('.ar-kw').value;});
   draft.auto=box.querySelector('.ar-auto input').checked;
  }
  function toggle(list,value){var i=list.indexOf(value);if(i<0)list.push(value);else list.splice(i,1);}
  function draw(){
   var h='<h3>自动分类规则</h3><p class="ar-desc">关键词用逗号分开，不分大小写，命中任意一个就算。规则从上往下匹配，命中第一条就按这条处理。只会把「未分类」的模块放进分组，已手动分好的不动；合集只加不减。</p>'+
    '<label class="ar-auto"><input type="checkbox"'+(draft.auto?' checked':'')+'><span>新模块自动整理（订阅同步或上传的新模块，后台自动处理）</span></label>';
   draft.rules.forEach(function(r,i){
    h+='<div class="ar-rule" data-i="'+i+'"><div class="ar-head"><strong>规则 '+(i+1)+'</strong><button type="button" class="btn" data-act="up"'+(i?'':' disabled')+' aria-label="上移">↑</button><button type="button" class="btn" data-act="down"'+(i<draft.rules.length-1?'':' disabled')+' aria-label="下移">↓</button><button type="button" class="btn ar-del" data-act="del">删除</button></div>'+
     '<input class="ar-kw" type="text" autocomplete="off" placeholder="关键词，如：短剧, 漫剧" value="'+esc(r.kw)+'">'+
     '<div class="ar-label">匹配</div><div class="ar-chips">'+FIELD_NAMES.map(function(f){return '<button type="button" class="ar-chip" data-field="'+f[0]+'" aria-pressed="'+(r.fields.indexOf(f[0])>=0)+'">'+f[1]+'</button>';}).join('')+'</div>'+
     '<div class="ar-label">放进分组</div><select data-act="group"><option value="">不分组</option>'+groups.map(function(g){return '<option value="'+esc(g.id)+'"'+(r.group===g.id?' selected':'')+'>'+esc(g.name)+'</option>';}).join('')+'</select>'+
     '<div class="ar-label">加入合集</div>'+(collections.length?'<div class="ar-chips">'+collections.map(function(c){return '<button type="button" class="ar-chip" data-col="'+esc(c.id)+'" aria-pressed="'+(r.cols.indexOf(c.id)>=0)+'">'+esc(c.title)+'</button>';}).join('')+'</div>':'<div class="ar-empty">还没有合集</div>')+'</div>';
   });
   h+='<p class="ar-error" role="status"></p><div class="ar-foot"><button type="button" class="btn" data-act="add">＋ 添加规则</button><button type="button" class="btn" data-act="sweep">整理现有未分类</button></div>'+
    '<div class="btn-row"><button type="button" class="btn" data-act="cancel">取消</button><button type="button" class="btn btn-primary" data-act="save">保存</button></div>';
   box.innerHTML=h;
  }
  function error(message){box.querySelector('.ar-error').textContent=message||'';}
  box.addEventListener('click',async function(e){
   var target=e.target.closest('button');if(!target||busy)return;
   var card=target.closest('.ar-rule'),i=card?Number(card.getAttribute('data-i')):-1,act=target.getAttribute('data-act');
   if(target.hasAttribute('data-field')||target.hasAttribute('data-col')){
    collect();var r=draft.rules[i];
    if(target.hasAttribute('data-field'))toggle(r.fields,target.getAttribute('data-field'));else toggle(r.cols,target.getAttribute('data-col'));
    target.setAttribute('aria-pressed',String(target.getAttribute('aria-pressed')!=='true'));return;
   }
   if(act==='cancel'){close();return;}
   if(act==='add'){collect();draft.rules.push(blank());draw();box.scrollTop=box.scrollHeight;return;}
   if(act==='del'){collect();draft.rules.splice(i,1);if(!draft.rules.length)draft.rules.push(blank());draw();return;}
   if(act==='up'||act==='down'){collect();var j=act==='up'?i-1:i+1;if(j<0||j>=draft.rules.length)return;var t=draft.rules[i];draft.rules[i]=draft.rules[j];draft.rules[j]=t;draw();return;}
   if(act==='save'||act==='sweep'){
    collect();error('');
    var rules=draft.rules.filter(function(r){return r.kw.trim()||r.group||r.cols.length;});
    for(var k=0;k<rules.length;k++){
     if(!rules[k].kw.trim()){error('规则 '+(k+1)+' 没有关键词');return;}
     if(!rules[k].fields.length){error('规则 '+(k+1)+' 至少选一个匹配范围');return;}
    }
    busy=true;target.disabled=true;
    try{
     var saved=await api('/api/admin/auto-rules',{method:'PUT',json:{auto:draft.auto,rules:rules.map(function(r){return {kw:r.kw.trim(),fields:r.fields,group:r.group,cols:r.cols};})}});
     if(!saved||!saved.ok)throw Error((saved&&saved.error)||'保存失败');
     if(act==='sweep'){
      if(!rules.length)throw Error('先添加规则再整理');
      var done=await api('/api/admin/auto-rules/run',{method:'POST',json:{scope:'ungrouped'}});
      if(!done||!done.ok)throw Error((done&&done.error)||'整理失败');
      toast('已检查 '+done.checked+' 个未分类模块：分组 '+done.grouped+' 个，加入合集 '+done.added+' 次');
      await loadAll();busy=false;target.disabled=false;return;
     }
     toast('规则已保存');close();void refreshSummary();
    }catch(err){busy=false;target.disabled=false;error(err.message||String(err));}
   }
  });
  box.addEventListener('change',function(e){
   var select=e.target.closest('select[data-act=group]');if(!select)return;
   var card=select.closest('.ar-rule');collect();draft.rules[Number(card.getAttribute('data-i'))].group=select.value;
  });
  draw();
 }
})();
`;
