// Opt-in only. Keep existing collection schemas, identities and ordering intact.
export const autoAllSchema=[`CREATE TABLE IF NOT EXISTS collection_options (
 collection_id TEXT PRIMARY KEY,auto_all INTEGER NOT NULL DEFAULT 0 CHECK(auto_all IN (0,1)))`];
export async function assertAutoAllCapacity(DB,added=0){
 const enabled=await DB.prepare('SELECT 1 AS enabled FROM collection_options WHERE auto_all=1 LIMIT 1').first();
 if(enabled&&(await DB.prepare('SELECT COUNT(*) AS n FROM modules').first()).n+added>1000)
  throw Error('自动包含全部模块的合集最多支持 1000 项，请先关闭该合集的自动包含开关');
}
export function autoAllInsert(DB,moduleId){
 return DB.prepare(`INSERT INTO collection_modules(collection_id,module_id,position)
 SELECT o.collection_id,m.id,COALESCE((SELECT MAX(position)+1 FROM collection_modules WHERE collection_id=o.collection_id),0)
 FROM collection_options o JOIN modules m ON m.id=? WHERE o.auto_all=1
 AND NOT EXISTS(SELECT 1 FROM collection_modules cm WHERE cm.collection_id=o.collection_id AND cm.module_id=m.id)`).bind(moduleId);
}
export function fillAutoAll(DB,collectionId=null){
 return DB.prepare(`INSERT INTO collection_modules(collection_id,module_id,position)
 SELECT o.collection_id,m.id,COALESCE((SELECT MAX(position) FROM collection_modules WHERE collection_id=o.collection_id),-1)
 +ROW_NUMBER() OVER(PARTITION BY o.collection_id ORDER BY m.sort_order,m.created_at,m.id)
 FROM collection_options o CROSS JOIN modules m WHERE o.auto_all=1 AND (? IS NULL OR o.collection_id=?)
 AND NOT EXISTS(SELECT 1 FROM collection_modules cm WHERE cm.collection_id=o.collection_id AND cm.module_id=m.id)`)
 .bind(collectionId,collectionId);
}
export async function collectionOption(DB,id,enabled){
 if(typeof enabled!=='boolean')throw Error('自动包含配置无效');
 if(enabled&&(await DB.prepare('SELECT COUNT(*) AS n FROM modules').first()).n>1000)
  throw Error('模块总数超过 1000，不能启用自动包含全部模块');
 return DB.prepare('INSERT INTO collection_options(collection_id,auto_all) VALUES(?,?) ON CONFLICT(collection_id) DO UPDATE SET auto_all=excluded.auto_all')
 .bind(id,enabled?1:0);
}
