import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';

const src=fs.readFileSync(new URL('./worker.js',import.meta.url),'utf8');
const piece=(a,b)=>src.slice(src.indexOf(a),src.indexOf(b));

test('分组内拖拽排序：可见位置正确换算成全局顺序',()=>{
 const mk=(id,g)=>({id,group_id:g});
 const run=(group,mid,targetIdx)=>{
  const ms=[mk('a','x'),mk('b','y'),mk('c','x'),mk('d','y'),mk('e','x')];
  const ctx={_sortGroup:group,state:{modules:ms},document:{removeEventListener(){},},
   _sortDrag:{mid,targetIdx,moved:true,row:{style:{}},list:{querySelectorAll:()=>[]}},
   renderSortList(){},renderMods(){},_sortDirty:false,
   sortMouseMove(){},sortMouseUp(){},sortTouchMove(){},sortTouchEnd(){}};
  vm.createContext(ctx);vm.runInContext(piece('function sortDragEnd','function sortMouseUp'),ctx);
  ctx.sortDragEnd();return ctx.state.modules.map(m=>m.id).join('');
 };
 // x 组可见: a c e。把 a 拖到最后(others=c,e → targetIdx 2)：x 组内变成 c e a，y 组相对位置不变
 const r1=run('x','a',2);assert.deepEqual([...r1].filter(c=>'ace'.includes(c)),['c','e','a']);assert.deepEqual([...r1].filter(c=>'bd'.includes(c)),['b','d']);
 // 把 e 拖到最前(targetIdx 0)：e a c
 const r2=run('x','e',0);assert.deepEqual([...r2].filter(c=>'ace'.includes(c)),['e','a','c']);
 // 全部视图下行为不变
 assert.equal(run('','e',0),'eabcd');
});

test('登录校验缓存：命中不查库，踢出设备后失效',async()=>{
 assert.ok(/_authCache\.clear\(\)/.test(src),'踢出其他设备要清缓存');
 assert.ok(/hit\.until > nowMs/.test(src));
});

test('迁移失败会被记录并由 hub/build 返回',()=>{
 assert.ok(/migration_errors_v1/.test(src));
 assert.ok(/migrationErrors/.test(src));
});

test('模块列表不再使用逐行相关子查询',()=>{
 const i=src.indexOf('async function getModules');const q=src.slice(i,i+700);
 assert.ok(/LEFT JOIN \(/.test(q));assert.ok(!/WHERE i\.module_id=m\.id/.test(q));
});
