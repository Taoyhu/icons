import {createHash} from 'node:crypto';
import {modulePath,safeFilename} from './filenames.js';
import {resolveTitle} from './metadata.js';
import {deleteModule} from './management.js';
import {fingerprint} from './uploads.js';

const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const values=async(db,sql)=>(await db.prepare(sql).all()).results||[];
// [自改A3] 「两者都留」按成员集合记忆；成员一变，这一组会重新出现。
const ignoreKey=ids=>digest(['ignore',[...ids].sort()]);

function groupByModule(rows){
 const map=new Map();
 for(const row of rows){
  if(!map.has(row.module_id))map.set(row.module_id,[]);
  map.get(row.module_id).push(row);
 }
 return map;
}

// Collection manifests fall back to URL as remote_id; single-module sources use
// the constant "single". Neither is evidence of a module identity.
function declaredId(item,module){
 const id=String(item.remote_id||'').trim();
 return item.kind==='collection'&&id&&id!==item.url&&id!==module.id&&!/^[a-z][a-z0-9+.-]*:\/\//i.test(id)?id:'';
}

export async function scanDuplicateModules(env){
 const DB=env.DB;
 const ignored=new Set((await values(DB,'SELECT group_key FROM duplicate_ignores').catch(()=>[])).map(r=>r.group_key));
 const [modules,collectionRows,subscriptionRows,aliasRows]=await Promise.all([
  values(DB,`SELECT m.*,g.name AS group_name,n.filename AS effective_filename,n.named_url,n.revision AS name_revision
    FROM modules m LEFT JOIN groups g ON g.id=m.group_id LEFT JOIN module_names n ON n.module_id=m.id ORDER BY m.id`),
  values(DB,`SELECT cm.module_id,c.id,c.title,c.slug,cm.position,COALESCE(o.auto_all,0) AS auto_all
    FROM collection_modules cm JOIN collections c ON c.id=cm.collection_id
    LEFT JOIN collection_options o ON o.collection_id=c.id ORDER BY cm.module_id,c.id`),
  values(DB,`SELECT i.module_id,i.source_id,i.remote_id,i.url,i.active,s.title,s.enabled,s.kind
    FROM subscription_items i JOIN subscription_sources s ON s.id=i.source_id
    WHERE i.module_id IS NOT NULL ORDER BY i.module_id,i.source_id,i.remote_id`),
  values(DB,`SELECT module_id,alias,is_current FROM module_share_aliases
    WHERE tombstoned=0 ORDER BY module_id,is_current DESC,alias_key`)
 ]);
 const byModule=new Map(modules.map(m=>[m.id,m])),collections=groupByModule(collectionRows);
 const subscriptions=groupByModule(subscriptionRows),aliases=groupByModule(aliasRows);
 const buckets={hash:new Map(),id:new Map(),filename:new Map()};
 function add(type,value,id,basis=''){
  if(!value)return;
  if(!buckets[type].has(value))buckets[type].set(value,new Map());
  buckets[type].get(value).set(id,basis);
 }
 for(const m of modules){
  const hash=String(m.content_hash||'').trim().toLowerCase();
  if(/^[a-f0-9]{64}$/.test(hash))add('hash',hash,m.id);
  const internal=String(m.metadata_id||'').trim();
  if(internal&&!m.is_encrypted)add('id',internal,m.id,'code');
  else for(const item of subscriptions.get(m.id)||[])add('id',declaredId(item,m),m.id,'manifest');
  add('filename',String(m.filename||'').normalize('NFC'),m.id);
 }

 // Collapse only identical member sets. Overlapping groups with different
 // sets stay separate, so filename matches cannot widen a stronger result.
 const groups=[],sets=new Map(),reported=new Set();
 for(const type of ['hash','id','filename'])for(const [value,members] of buckets[type]){
  if(members.size<2)continue;
  const ids=[...members.keys()].sort(),setKey=JSON.stringify(ids);
  if(ignored.has(ignoreKey(ids)))continue;
  const reason={type,value,...(type==='id'?{basis:Object.fromEntries(members)}:{})};
  let group=sets.get(setKey);
  if(!group){group={key:digest([type,value]),module_ids:ids,reasons:[]};sets.set(setKey,group);groups.push(group);}
  group.reasons.push(reason);
  ids.forEach(id=>reported.add(id));
 }
 for(const group of groups){
  group.token=digest([group.module_ids.map(id=>[id,fingerprint(byModule.get(id))]),
   group.reasons.map(r=>[r.type,r.value,r.basis||null])]);
 }
 const entries=[...reported].map(id=>{
  const m=byModule.get(id),cols=collections.get(id)||[],subs=subscriptions.get(id)||[],shares=aliases.get(id)||[];
  const name=m.effective_filename||safeFilename(m.filename,id);
  const paths=[...new Set([modulePath({...m,effective_filename:name}),'/api/modules/'+id+'.js',
   ...shares.map(a=>'/api/modules/'+encodeURIComponent(a.alias))])];
  return {id,title:resolveTitle(m),version:m.version||'',author:m.author||'',filename:m.filename,effective_filename:name,
   encrypted:!!m.is_encrypted,size:m.file_size||0,updated_at:m.updated_at||0,group:m.group_name||'',
   has_source:!!(m.source_url||m.source_managed),has_share_alias:shares.length>0,paths,
   collections:cols.map(c=>({title:c.title,slug:c.slug,automatic:!!c.auto_all})),
   subscriptions:subs.map(s=>({title:s.title,enabled:!!s.enabled,active:!!s.active})),
   may_reimport:subs.some(s=>s.enabled&&s.active),
   revision:digest([fingerprint(m),m.group_id,m.note,cols,subs,shares,paths])};
 });
 return {groups,modules:entries};
}

// [自改A3] 两者都留：把这一组标记为已确认，以后不再出现在重复列表，也不会被自动去重处理。
export async function ignoreDuplicateGroup(env,{group_token:token}={}){
 if(typeof token!=='string'||!/^[a-f0-9]{64}$/.test(token))throw Error('请重新扫描后再操作');
 const g=(await scanDuplicateModules(env)).groups.find(x=>x.token===token);
 if(!g)throw Error('这一组已变化，请重新扫描');
 await env.DB.prepare('INSERT OR REPLACE INTO duplicate_ignores(group_key,created_at) VALUES (?,?)').bind(ignoreKey(g.module_ids),Date.now()).run();
 return {ok:true};
}
export async function clearDuplicateIgnores(env){
 await env.DB.prepare('DELETE FROM duplicate_ignores').run();
 return {ok:true};
}

// [自改A3] 保留这份：指定保留一个，同组其余的永久删除。apply=false 只返回预览（含风险提示）。
export async function keepOneDuplicate(env,{keep_id:keepId,group_token:token,apply=false}={}){
 if(typeof keepId!=='string'||!keepId||typeof token!=='string'||!/^[a-f0-9]{64}$/.test(token))throw Error('请重新扫描后再操作');
 const report=await scanDuplicateModules(env);
 const group=report.groups.find(g=>g.token===token&&g.module_ids.includes(keepId));
 if(!group)throw Error('这一组已变化，请重新扫描');
 const byId=new Map(report.modules.map(m=>[m.id,m]));
 const keepMod=byId.get(keepId),keepCols=new Set(keepMod.collections.filter(c=>!c.automatic).map(c=>c.slug));
 const remove=group.module_ids.filter(id=>id!==keepId).map(id=>byId.get(id)).filter(Boolean).map(m=>{
  const warnings=[];
  if(m.may_reimport)warnings.push('启用中的订阅仍包含它，之后同步可能再次导入');
  else if(m.has_source||m.subscriptions.length)warnings.push('带订阅或来源关联，删除后关联消失');
  if(m.has_share_alias)warnings.push('有分享链接，删除后链接失效');
  const lost=m.collections.filter(c=>!c.automatic&&!keepCols.has(c.slug)).map(c=>c.title);
  if(lost.length)warnings.push('会从合集移出：'+lost.join('、'));
  return {id:m.id,title:m.title,version:m.version,filename:m.filename,revision:m.revision,warnings};
 });
 const keep={id:keepMod.id,title:keepMod.title,version:keepMod.version};
 if(!apply)return {keep,remove,applied:false};
 const done=[],failed=[];
 for(const r of remove){
  try{await deleteScannedDuplicate(env,{id:r.id,group_token:token,revision:r.revision});done.push({id:r.id,title:r.title});}
  catch(e){failed.push({id:r.id,title:r.title,error:String(e.message||e)});}
 }
 return {keep,remove,applied:true,done,failed};
}

export async function deleteScannedDuplicate(env,input){
 const {id,group_token:token,revision}=input||{};
 const validToken=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
 if(typeof id!=='string'||!id||id.length>100||!validToken(token)||!validToken(revision))throw Error('请重新扫描后再删除');
 return deleteModule(env,id,async()=>{
  const current=await scanDuplicateModules(env);
  const found=current.modules.find(m=>m.id===id);
  if(!found||found.revision!==revision||!current.groups.some(g=>g.token===token&&g.module_ids.includes(id)))
   throw Error('模块、重复分组或引用已变化，请重新核对后再删除');
 });
}

// [自改A3] 一键自动去重（仅安全项）。只处理两类有十足把握的情况：
//   1) 内容哈希完全相同；2) 明文模块内部 ID 相同且双方版本都读得出（留版本最高，同版本留较新）。
// 加密模块只靠文件名/清单判断的一律不动。凡删除会丢失订阅关联、分享链接或合集成员的，整组跳过。
function versionKey(v){
 const parts=String(v||'').match(/\d+/g);
 return parts&&parts.length?parts.map(Number):null;
}
function compareVersion(a,b){
 for(let i=0;i<Math.max(a.length,b.length);i++){const d=(a[i]||0)-(b[i]||0);if(d)return d;}
 return 0;
}
export function planAutoDedupe(report){
 const byId=new Map(report.modules.map(m=>[m.id,m]));
 const manual=m=>new Set(m.collections.filter(c=>!c.automatic).map(c=>c.slug));
 const candidates=[],skipped=[];
 const skip=(group,reason)=>skipped.push({module_ids:group.module_ids,reasons:group.reasons.map(r=>r.type),reason,
  titles:group.module_ids.map(id=>byId.get(id)?.title||id)});
 for(const group of report.groups){
  const members=group.module_ids.map(id=>byId.get(id)).filter(Boolean);
  if(members.length<2)continue;
  const hashGroup=group.reasons.some(r=>r.type==='hash');
  const idGroup=group.reasons.some(r=>r.type==='id'&&Object.values(r.basis||{}).every(x=>x==='code'));
  if(!hashGroup&&!idGroup){skip(group,'只靠文件名或清单声明判断，不自动处理');continue;}
  let keep,basis;
  if(hashGroup){
   // 内容完全相同：留引用最多的一份（订阅 > 手动合集数 > 有分享链接 > 较新）
   const score=m=>[m.has_source||m.subscriptions.length?1:0,manual(m).size,m.has_share_alias?1:0,m.updated_at||0];
   const cmp=(a,b)=>{const x=score(a),y=score(b);for(let i=0;i<x.length;i++)if(x[i]!==y[i])return y[i]-x[i];return a.id<b.id?-1:1;};
   keep=[...members].sort(cmp)[0];basis='内容哈希完全相同';
  }else{
   if(members.some(m=>m.encrypted)){skip(group,'含加密模块，不自动处理');continue;}
   const keys=members.map(m=>versionKey(m.version));
   if(keys.some(k=>!k)){skip(group,'有模块版本读不出，无法判断新旧');continue;}
   const ranked=members.map((m,i)=>({m,k:keys[i]})).sort((a,b)=>compareVersion(b.k,a.k)||(b.m.updated_at||0)-(a.m.updated_at||0)||(a.m.id<b.m.id?-1:1));
   keep=ranked[0].m;basis='内部 ID 相同，保留版本最高';
  }
  const removals=members.filter(m=>m.id!==keep.id);
  const keepCols=manual(keep);
  let blocked='';
  for(const m of removals){
   if(m.may_reimport||m.has_source||m.subscriptions.length){blocked='「'+m.title+'」来自订阅，删除后会被重新导入或失去订阅关联';break;}
   if(m.has_share_alias){blocked='「'+m.title+'」有分享链接，删除后链接失效';break;}
   if([...manual(m)].some(slug=>!keepCols.has(slug))){blocked='「'+m.title+'」在保留项没有加入的合集里，删除会让合集少一个模块';break;}
  }
  if(blocked){skip(group,blocked);continue;}
  candidates.push({group,keep,removals,basis});
 }
 // 同一个模块在不同组里既要保留又要删除 → 相关组全部跳过，留给人工。
 const keepSet=new Set(candidates.map(c=>c.keep.id)),dupDel=new Set(),conflict=new Set();
 for(const c of candidates)for(const m of c.removals){if(keepSet.has(m.id)||dupDel.has(m.id))conflict.add(m.id);dupDel.add(m.id);}
 const plan=[];
 for(const c of candidates){
  if(c.removals.some(m=>conflict.has(m.id))||conflict.has(c.keep.id)){skip(c.group,'与其他重复组重叠，请手动处理');continue;}
  plan.push({group_token:c.group.token,basis:c.basis,
   keep:{id:c.keep.id,title:c.keep.title,version:c.keep.version},
   remove:c.removals.map(m=>({id:m.id,title:m.title,version:m.version,filename:m.filename,revision:m.revision}))});
 }
 return {plan,skipped,total_remove:plan.reduce((n,p)=>n+p.remove.length,0)};
}

export async function runAutoDedupe(env,{apply=false}={}){
 const report=await scanDuplicateModules(env);
 const result=planAutoDedupe(report);
 if(!apply)return {...result,applied:false};
 const done=[],failed=[];
 for(const item of result.plan)for(const r of item.remove){
  try{
   await deleteScannedDuplicate(env,{id:r.id,group_token:item.group_token,revision:r.revision});
   done.push({id:r.id,title:r.title});
  }catch(e){failed.push({id:r.id,title:r.title,error:String(e.message||e)});}
 }
 return {...result,applied:true,done,failed};
}
