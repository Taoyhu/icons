// FWH Admin Lite — D1 版：部署到 Cloudflare Workers + D1 + KV
// 必须绑定：KV 命名空间 → 变量名 KV ；D1 数据库 → 变量名 DB
// 环境变量：ADMIN_PASSWORD（初始密码，之后以 D1 中修改的为准）
// 模块直链：https://<host>/api/modules/<id>.js
// 合集订阅：https://<host>/api/collections/<slug>.rex（兼容旧.fwd)

import { subscriptionSchema, parseManifest, addSubscription, listSubscriptions,
  syncSubscription, subscriptionTick, subscriptionItems,upgradeSubscriptions,previewSource,readSourcePreview,findDuplicates,editSource,legacySources,changeSubscriptionIcon } from './subscriptions.js';
import { uploadSchema, previewUploads, commitUpload, previousVersion, restorePrevious,
  withModuleLock, getFileKey, cleanupUploadJobs } from './uploads.js';
import {parseModuleMeta,resolveTitle,cleanTitle,generatedFilename,titleSource,METADATA_SCAN_BYTES} from './metadata.js';
import {backfillTitles} from './title-maintenance.js';
import {bulkManage,deleteModule,replaceMembers,validatedMembers,memberStatements} from './management.js';
import {managementUI,managementStyles} from './management-ui.js';
import {assertModuleFile,fetchRemote} from './remote.js';
import {sharingSchema,previewShare,saveShare,resolveAlias} from './sharing.js';
import {sharingUI} from './sharing-ui.js';
import {iconSchema,listIconSources,addIconSource,changeIconSource,deleteIconSource,refreshIconSource,queryIcons,cacheIcon,prepareCollectionIcon,assertStoredIcon,iconTick,iconResponse} from './icons.js';
import {iconUI,iconStyles} from './icon-ui.js';
import {backupSchema,exportBackup,beginRestore,stageRestoreFile,commitRestore,cleanupRestoreJobs,setCollectionSlug} from './backup.js';
import {backupUI} from './backup-ui.js';
import {pwaResponse} from './pwa.js';
import {WriteQueue} from './coordinator.js';
import {filenameSchema,decorateNames,prepareName,nameStatement,namingSettings,scanNames,repairNames,
  urlFilename,modulePath,contentDisposition,downloadFilename} from './filenames.js';
import {filenameUI,filenameStyles} from './filename-ui.js';
import {autoRulesUI,autoRulesStyles} from './auto-rules-ui.js';
import {loadAutoRules,saveAutoRules,runAutoRules,autoRulesTick} from './auto-rules.js';
import {autoAllSchema,autoAllInsert,assertAutoAllCapacity,fillAutoAll,collectionOption} from './auto-all.js';
import {scanDuplicateModules,deleteScannedDuplicate,runAutoDedupe,ignoreDuplicateGroup,clearDuplicateIgnores,keepOneDuplicate} from './duplicates.js';
import {duplicatesUI,duplicatesStyles} from './duplicates-ui.js';

const subscriptionHelpers = { fetchCapped, fetchRemote,assertFetchableUrl, nextSortOrder, parseMeta, isEncrypted, putFile, toHex };
const uploadHelpers = { parseMeta, isEncrypted, toHex, nextSortOrder };

// Link imports must not silently add a second copy of a module that already exists.
async function duplicateGate(env,body,p){
  if(!p||p.kind!=='module')return null;
  const dups=await findDuplicates(env,p.meta,p.meta.source_filename,p.url);
  if(!dups.length)return null;
  const action=body.duplicate_action;
  if(action==='new')return null;
  if(action==='replace'){
    const target=dups.find(d=>d.id===body.replace_id);
    if(!target)throw Error('要覆盖的模块已变化，请重新识别');
    const file=new File([p.buffer],p.meta.source_filename,{type:'application/javascript'});
    const preview=await previewUploads(env,[file],'',uploadHelpers,target.id);
    const result=await commitUpload(env,{job_id:preview.job_id,index:0,action:'replace',target_id:target.id,
      mode:String(body.mode||''),file},uploadHelpers);
    return {ok:true,replaced:true,status:result.status,module_id:target.id};
  }
  const e=Error('已有相同模块，请选择覆盖或添加为新模块');e.duplicates=dups;e.status=409;throw e;
}

var HTML = String.raw`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="darkreader-lock">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover,user-scalable=no">
<title>Widget Hub</title>
<link rel="manifest" href="/manifest.webmanifest">
<link rel="apple-touch-icon" sizes="180x180" href="/app-icons/rex-mulberry-v1-180.png">
<link rel="icon" type="image/png" sizes="32x32" href="/app-icons/rex-mulberry-v1-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/app-icons/rex-mulberry-v1-16.png">
<meta name="theme-color" content="#f2f2f6">
<meta name="application-name" content="Rex Hub">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Rex Hub">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<style>
/* ===== 清爽深色 · 对标 Forward 设置页 ===== */
:root{
  --text:#1c1c1e; --text2:#6e6e74; --text3:#aeaeb4;
  --accent:#6d5ef2;
  --bg:#f2f2f6;
  --card:#ffffff;
  --card-brd:rgba(0,0,0,.07);
  --field:#f4f4f6;
  --field-brd:rgba(0,0,0,.1);
  --shadow:0 2px 12px rgba(0,0,0,.06);
  --div:rgba(0,0,0,.06);
  --ico-normal:#e8e8ee; --ico-normal-fg:#55555e;
  --ico-encrypted:#f5e6c8; --ico-encrypted-fg:#8a6d2f;
  --radius:20px;
}
.dark{
  --text:#f4f4f6; --text2:#a0a0a8; --text3:#6e6e76;
  --accent:#8b7cf6;
  --bg:#131318;
  --card:rgba(255,255,255,.045);
  --card-brd:rgba(255,255,255,.09);
  --field:rgba(255,255,255,.06);
  --field-brd:rgba(255,255,255,.12);
  --shadow:0 2px 12px rgba(0,0,0,.25);
  --div:rgba(255,255,255,.07);
  --ico-normal:rgba(255,255,255,.1); --ico-normal-fg:#d8d8de;
  --ico-encrypted:rgba(217,164,65,.16); --ico-encrypted-fg:#d9a441;
}
@media(prefers-color-scheme:dark){
  :root:not(.dark):not(.light){
    --text:#f4f4f6; --text2:#a0a0a8; --text3:#6e6e76;
    --accent:#8b7cf6;
    --bg:#131318;
    --card:rgba(255,255,255,.045);
    --card-brd:rgba(255,255,255,.09);
    --field:rgba(255,255,255,.06);
    --field-brd:rgba(255,255,255,.12);
    --shadow:0 2px 12px rgba(0,0,0,.25);
    --div:rgba(255,255,255,.07);
    --ico-normal:rgba(255,255,255,.1); --ico-normal-fg:#d8d8de;
    --ico-encrypted:rgba(217,164,65,.16); --ico-encrypted-fg:#d9a441;
  }
}
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text',sans-serif;
  color:var(--text); min-height:100vh; -webkit-font-smoothing:antialiased;
  background:var(--bg);
}
/* ---- 顶栏 ---- */
.header{position:sticky;top:0;z-index:20;padding:18px 20px 6px;background:var(--bg);}
.header-in{max-width:640px;margin:0 auto;display:flex;align-items:center;gap:12px}
.avatar{width:42px;height:42px;border-radius:13px;background:var(--field);border:1px solid var(--card-brd);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;color:var(--text2);font-weight:700}
.header h1{font-size:21px;font-weight:700;letter-spacing:-.3px}
.header p{font-size:12.5px;color:var(--text2);margin-top:1px;font-weight:500}
.header .spacer{flex:1}
.avatar img{filter:invert(1)}
.dark .avatar img{filter:none}
@media(prefers-color-scheme:dark){:root:not(.dark):not(.light) .avatar img{filter:none}}
.theme-btn{font-size:16px;width:38px;height:38px;border-radius:12px}
/* ---- 主体 ---- */
.main{max-width:640px;margin:0 auto;padding:6px 16px 140px;position:relative;z-index:1}
.page{display:none}
.page.active{display:block;animation:pop .25s ease}
.page-head{display:flex;justify-content:space-between;align-items:center;margin:14px 4px}
.ftab{flex-shrink:0;font-size:13px;font-weight:600;padding:8px 14px;border-radius:12px;background:var(--card);border:1px solid var(--card-brd);color:var(--text2);cursor:pointer;white-space:nowrap}
.ftab.active{background:var(--accent);border-color:transparent;color:#fff}
.ftab .cnt{font-size:11px;opacity:.7;margin-left:4px}
.folder-tabs{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none}
.folder-tabs::-webkit-scrollbar{display:none}
#groupTabs{flex-wrap:wrap;overflow-x:visible!important}
#groupTabs .ftab{max-width:100%;white-space:normal;overflow-wrap:anywhere}
.page-head .count{font-size:12.5px;color:var(--text2);font-weight:600}
.actions{display:flex;gap:8px;align-items:center;flex:1}
/* ---- 按钮 ---- */
.btn{border:1px solid var(--card-brd);cursor:pointer;font-size:13.5px;font-weight:600;padding:10px 16px;border-radius:14px;font-family:inherit;transition:all .15s;display:inline-flex;align-items:center;gap:7px;background:var(--card);color:var(--text)}
.btn:active{transform:scale(.97)}
.btn svg{width:15px;height:15px;flex-shrink:0;opacity:.8}
.btn-primary{background:var(--accent);border-color:transparent;color:#fff}
.btn-ghost{background:transparent;border-color:transparent;color:var(--accent)}
.btn-sm{font-size:12.5px;padding:8px 13px;border-radius:12px}
.btn-xs{width:32px;height:32px;border-radius:10px;border:none;background:transparent;font-size:15px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:var(--text2)}
.btn-xs.danger{color:#e11d48}
.btn-xs svg{width:15px;height:15px}
/* ---- 列表 ---- */
.row{display:flex;align-items:center;gap:13px;padding:14px 16px;background:var(--card);border:1px solid var(--card-brd);border-radius:18px;box-shadow:var(--shadow);transition:transform .15s;margin-bottom:10px}
.row:active{transform:scale(.985)}
.card>.row{background:transparent;border:none;box-shadow:none;border-radius:0;margin-bottom:0;padding:13px 2px;border-bottom:1px solid var(--div)}
.card>.row:last-child{border-bottom:none}
.card>.row:active{transform:none}
.ico-sq{width:42px;height:42px;border-radius:13px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.ico-sq svg{width:20px;height:20px}
.info{flex:1;min-width:0}
.name{font-size:15px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-.2px}
.sub{font-size:12px;color:var(--text2);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
/* [自改A2] 模块行下方的「当前分组 / 当前合集」快捷标签 */
.mod-tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px}
.mod-tag{font-family:inherit;font-size:11px;font-weight:600;line-height:1.2;padding:3px 9px;border-radius:7px;border:0;cursor:pointer;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mod-tag-group{background:rgba(109,94,242,.12);color:var(--accent)}
.mod-tag-none{background:rgba(120,120,128,.14);color:var(--text2)}
.mod-tag-col{background:rgba(22,163,74,.13);color:#16a34a}
.mod-tag-auto{background:rgba(22,163,74,.08);color:#16a34a;cursor:default;opacity:.8}
.mod-tag-add{background:none;color:var(--text2);border:1px dashed var(--field-brd)}
.dark .mod-tag-col,.dark .mod-tag-auto{color:#4ade80}
.badge{font-size:10.5px;font-weight:700;padding:3px 9px;border-radius:7px;flex-shrink:0}
.badge-blue{background:rgba(109,94,242,.12);color:var(--accent)}
.badge-green{background:rgba(22,163,74,.13);color:#16a34a}
.dark .badge-green{background:rgba(74,222,128,.14);color:#4ade80}
.sort-row{display:flex;align-items:center;gap:12px;padding:12px 4px;border-bottom:1px solid var(--div);user-select:none;-webkit-user-select:none;}
.sort-row:last-child{border-bottom:none;}
.sort-row.drop-hint{border-top:2px solid var(--accent);}
.grip{flex-shrink:0;width:28px;height:32px;display:flex;align-items:center;justify-content:center;cursor:grab;color:var(--text2);opacity:.5;touch-action:none;}
.grip:active{cursor:grabbing;opacity:1;}
.grip svg{width:18px;height:18px;}
.sort-name{flex:1;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.modal-mask{position:fixed;inset:0;background:rgba(0,0,0,.4);display:none;align-items:flex-start;justify-content:center;z-index:100;padding:8vh 16px 16px;}
.modal-box{overscroll-behavior:contain;background:var(--bg);border:1px solid var(--div);border-radius:16px;width:100%;max-width:480px;max-height:80vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 16px 48px rgba(0,0,0,.2);}
.modal-head{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 8px;font-size:16px;font-weight:600;}
.modal-sub{font-size:12px;color:var(--text2);padding:0 18px 10px;}
.modal-foot{padding:12px 18px 18px;display:flex;justify-content:flex-end;}
.sort-scroll{overflow-y:auto;padding:0 18px 18px;-webkit-overflow-scrolling:touch;}
.badge-orange{background:rgba(217,164,65,.14);color:#c08a2d}
.dark .badge-orange{color:#d9a441}
/* origin-dropdown：菜单从触发器边缘"长"出来 */
.od-root{position:relative;display:inline-block;flex-shrink:0}
.od-chev{display:inline-flex;vertical-align:-2px;margin-left:4px}
.od-root.open .od-chev{transform:rotate(180deg)}
.od-menu{position:absolute;top:calc(100% + 8px);right:0;min-width:0;width:max-content;padding:6px;border-radius:14px;background:var(--bg);border:1px solid var(--card-brd);box-shadow:0 14px 36px rgba(0,0,0,.35),inset 0 0 0 300px var(--bg);z-index:300;display:none}
.dark .od-menu{background:#1e1e24;box-shadow:0 14px 36px rgba(0,0,0,.35),inset 0 0 0 300px #1e1e24}
.od-menu.portal{position:fixed;right:auto;left:0;top:0;z-index:9999;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);max-height:calc(100dvh - 16px);overflow:auto;overscroll-behavior:contain}
.od-root.open .od-menu{display:block;transform:translateZ(0)}
.od-menu .mi{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border:0;background:transparent;font-size:14px;font-weight:500;text-align:left;border-radius:10px;cursor:pointer;color:var(--text);font-family:inherit}
.od-menu .mi:active{background:var(--field)}
.od-menu .mi svg{width:16px;height:16px;flex-shrink:0;opacity:.75}
.od-menu .mi.danger{color:#e11d48}
/* ---- 卡片 ---- */
.card{background:var(--card);border:1px solid var(--card-brd);border-radius:var(--radius);padding:20px 18px;margin-bottom:12px;box-shadow:var(--shadow)}
.card h3{font-size:15px;font-weight:700;margin-bottom:12px;letter-spacing:-.2px}
/* ---- 统计 ---- */
.stat-box{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.set-sec{font-size:13px;font-weight:600;color:var(--text2);margin:20px 4px 8px}
.set-group{background:var(--card);border-radius:16px;overflow:hidden}
.set-row{display:flex;align-items:center;gap:12px;padding:13px 16px;font-size:14.5px;cursor:pointer}
.set-row+.set-row{border-top:1px solid var(--div)}
.set-row svg.ic{width:20px;height:20px;flex-shrink:0;color:var(--text2)}
.set-row.danger,.set-row.danger svg.ic{color:#e11d48}
.set-row .chev{margin-left:auto;color:var(--text3);flex-shrink:0}
.set-row .chev svg{width:15px;height:15px;display:block}
.stat{background:var(--field);border-radius:14px;padding:12px 6px;text-align:center}
.stat .num{font-size:19px;font-weight:800;letter-spacing:-.5px;color:var(--text);white-space:nowrap}
.stat .lbl{font-size:11px;color:var(--text2);margin-top:4px;font-weight:600}
/* ---- 表单 ---- */
.input,.textarea{border:1px solid var(--field-brd);border-radius:13px;padding:12px 14px;font-size:14px;width:100%;outline:none;background:var(--field);color:var(--text);font-family:inherit;font-weight:500;transition:all .15s}
.input:focus,.textarea:focus{border-color:var(--accent)}
label.lbl{font-size:12px;font-weight:700;color:var(--text2);margin-bottom:6px;display:block;margin-top:14px}
/* ---- 工具 ---- */
/* ---- 底部 dock ---- */
.dock{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(18px + env(safe-area-inset-bottom,0px));display:flex;gap:4px;padding:8px;background:var(--card);border:1px solid var(--card-brd);border-radius:26px;box-shadow:0 12px 40px rgba(0,0,0,.16);z-index:100}
.dock-item{display:flex;flex-direction:column;align-items:center;gap:3px;padding:9px 20px;border-radius:19px;cursor:pointer;border:none;background:transparent;font-family:inherit;transition:all .15s;color:var(--text3)}
.dock-item .d-icon{display:flex;align-items:center;justify-content:center}
.dock-item .d-icon svg{width:21px;height:21px}
.dock-item .d-label{font-size:10.5px;font-weight:600}
.dock-item.active{background:var(--field);color:var(--text)}
.dock-item:active{transform:scale(.94)}
/* ---- 空状态 ---- */
.empty{text-align:center;padding:64px 20px}
#bootLoader{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:var(--bg);z-index:999}
.boot-spin{width:34px;height:34px;border-radius:50%;border:3px solid var(--card-brd);border-top-color:var(--accent);animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.skel-row{display:flex;align-items:center;gap:12px;padding:14px 16px}
.skel-ico{width:44px;height:44px;border-radius:12px;background:var(--field);flex-shrink:0}
.skel-tx{flex:1;min-width:0}
.skel-l1{height:14px;width:42%;border-radius:6px;background:var(--field);margin-bottom:8px}
.skel-l2{height:11px;width:68%;border-radius:6px;background:var(--field)}
.skel-ico,.skel-l1,.skel-l2{animation:skel 1.2s ease-in-out infinite}
@keyframes skel{0%,100%{opacity:.45}50%{opacity:1}}
.empty .ico{margin-bottom:12px;opacity:.45;color:var(--text2)}
.empty .ico svg{width:52px;height:52px}
.empty p{font-size:13.5px;color:var(--text2);font-weight:500}
/* ---- 弹窗 ---- */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:150;display:flex;align-items:center;justify-content:center;padding:16px}
.modal{background:var(--bg);border:1px solid var(--card-brd);border-radius:22px;padding:24px 20px;width:100%;max-width:420px;max-height:85vh;max-height:85dvh;overflow-y:auto;overscroll-behavior:contain;box-shadow:0 24px 64px rgba(0,0,0,.25);animation:sheetUp .25s ease}
.dark .modal{background:#1c1c22}
.modal h3{font-size:16px;font-weight:700;margin-bottom:14px}
.modal .desc{font-size:13px;color:var(--text2);margin-bottom:6px}
.modal .btn-row{display:flex;gap:10px;margin-top:20px}
.modal .btn-row .btn{flex:1;justify-content:center;padding:12px}
/* ---- Toast ---- */
.toast{position:fixed;top:calc(20px + env(safe-area-inset-top,0px));left:50%;transform:translateX(-50%) translateY(-12px);background:#2c2c32;color:#fff;padding:11px 22px;border-radius:20px;font-size:13px;z-index:300;font-weight:600;opacity:0;transition:all .25s;pointer-events:none;box-shadow:0 8px 24px rgba(0,0,0,.2)}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
/* ---- 选择列表 ---- */
.pick-list{max-height:220px;overflow-y:auto;border:1px solid var(--field-brd);border-radius:13px;margin-top:10px;background:var(--field)}
.pick-item{display:flex;align-items:center;gap:10px;padding:12px 14px;cursor:pointer;font-size:13.5px;font-weight:500;border-bottom:0.5px solid var(--div)}
.pick-item:last-child{border:none}
.group-move-choice.pick-item{width:100%;min-height:44px;text-align:left;background:none;color:var(--text);font-family:inherit;border:0;border-bottom:1px solid var(--div)}
.group-move-choice.pick-item:last-child{border-bottom:0}
.group-move-choice:active{background:var(--card)}
.group-move-choice:disabled{opacity:.6;cursor:default}
.group-move-actions{display:flex;justify-content:flex-end;margin-top:14px}
.group-move-name{overflow-wrap:anywhere}
.pick-item.checked{background:rgba(109,94,242,.16);font-weight:600}
.pick-item.checked::after{content:"";width:20px;height:20px;border-radius:50%;flex-shrink:0;background:#6d5ef2 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='3.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4.5 12.6l5 5L19.5 7'/%3E%3C/svg%3E") center/11px no-repeat}
/* ---- 登录 ---- */
#loginGate{min-height:100vh;display:none;align-items:center;justify-content:center;padding:24px;position:relative;z-index:1}
.login-card{width:100%;max-width:340px;text-align:center;background:var(--card);border:1px solid var(--card-brd);border-radius:28px;padding:44px 32px;box-shadow:var(--shadow)}
.login-card .logo-img{width:72px;height:72px;margin:0 auto 20px}
.login-card .logo-img img{width:100%;height:100%;object-fit:contain;filter:invert(1)}
.dark .login-card .logo-img img{filter:none}
@media(prefers-color-scheme:dark){:root:not(.dark):not(.light) .login-card .logo-img img{filter:none}}
.login-card h2{font-size:22px;font-weight:800;letter-spacing:-.5px}
.login-card p.sub{color:var(--text2);font-size:13px;margin:8px 0 28px;font-weight:500}
.login-card .input{text-align:center;margin-bottom:14px;padding:14px 16px;font-size:16px;border-radius:16px;background:var(--field)}
.login-card .btn-primary{width:100%;justify-content:center;padding:15px;font-size:16px;font-weight:700;border-radius:16px}
.login-err{color:#e11d48;font-size:13px;margin-top:12px;display:none;font-weight:600}
/* ---- 源码编辑器 ---- */
#editorOverlay{display:none;position:fixed;inset:0;z-index:600;background:var(--bg);flex-direction:column}
.ed-bar{display:flex;align-items:center;gap:10px;padding:12px 14px;padding-top:calc(12px + env(safe-area-inset-top,0px));background:var(--card);border-bottom:1px solid var(--div)}
.ed-title{font-size:15px;font-weight:700;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ed-fname{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;background:var(--field);border:1px solid var(--field-brd);color:var(--text);border-radius:9px;padding:8px 10px;width:128px;flex-shrink:0;outline:none}
.ed-fname:focus{border-color:var(--accent)}
.ed-body{flex:1;display:flex;overflow:hidden}
.ed-gutter{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:19px;padding:12px 8px 12px 12px;text-align:right;color:var(--text3);background:var(--field);border-right:1px solid var(--div);overflow:hidden;white-space:pre;user-select:none;-webkit-user-select:none}
.ed-gutter div{will-change:transform}
#edCode{flex:1;border:none;outline:none;resize:none;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;line-height:19px;padding:12px 14px 45vh 12px;background:transparent;color:var(--text);white-space:pre;overflow:auto;tab-size:2}
.ed-foot{display:flex;align-items:center;gap:8px;padding:10px 14px;padding-bottom:calc(10px + env(safe-area-inset-bottom,0px));background:var(--card);border-top:1px solid var(--div);font-size:11.5px;color:var(--text2);font-weight:600}
.ed-dot{width:8px;height:8px;border-radius:50%;background:#30d158;display:inline-block;flex-shrink:0}
.ed-dot.dirty{background:#ff9f0a}
@keyframes pop{from{opacity:0;transform:scale(.98) translateY(6px)}to{opacity:1;transform:scale(1) translateY(0)}}
@keyframes sheetUp{from{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}

/* spotlight 卡片 */
.row{position:relative}
.row::before{content:"";position:absolute;inset:0;pointer-events:none;opacity:0;z-index:0;border-radius:inherit;
background:radial-gradient(380px circle at var(--mx,50%) var(--my,50%),rgba(124,108,246,.14),transparent 65%)}
.row:hover::before{opacity:1}
.row>*{position:relative;z-index:1}
/* 玻璃 dock */
.dock{background:rgba(255,255,255,.72)!important;backdrop-filter:blur(24px) saturate(1.4);-webkit-backdrop-filter:blur(24px) saturate(1.4);
border:1px solid rgba(0,0,0,.08)!important;box-shadow:0 12px 40px rgba(0,0,0,.14),inset 0 1px 0 rgba(255,255,255,.7)!important;border-radius:28px!important;padding:8px!important}
.dark .dock{background:rgba(22,22,30,.55)!important;border:1px solid rgba(255,255,255,.12)!important;box-shadow:0 12px 40px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.08)!important}
.ios-search{display:inline-flex;align-items:center;height:40px;width:170px;padding:0 14px;border-radius:999px;background:#EDEDF0;border:1px solid transparent;flex-shrink:0;min-width:0}
.ios-search:focus-within{background:#E2E2E6;border-color:#C6C6CC}
.ios-search-ico{width:16px;height:16px;flex-shrink:0;margin-right:10px;color:#8E8E93}
.ios-search:focus-within .ios-search-ico{color:#1c1c1e}
.ios-search-input{flex:1;min-width:0;background:transparent;border:none;outline:none;font-size:16px;color:#1c1c1e;font-family:inherit;padding:0}
.ios-search-input::placeholder{color:#8E8E93}
.ios-search-input::-webkit-search-cancel-button{-webkit-appearance:none;appearance:none;display:none}
.ios-search-input::-webkit-search-decoration{display:none}
.ios-search-x{display:flex;align-items:center;justify-content:center;width:20px;height:20px;margin-left:6px;padding:0;border:none;border-radius:50%;background:#D1D1D6;color:#6e6e74;cursor:pointer;flex-shrink:0;visibility:hidden}
.ios-search-x svg{width:12px;height:12px}
.dark .ios-search{background:#0E0E0E;border-color:#1F1F1F}
.dark .ios-search:focus-within{background:#141414;border-color:#4A4A4A}
.dark .ios-search-ico{color:#525252}
.dark .ios-search:focus-within .ios-search-ico{color:#FAFAFA}
.dark .ios-search-input{color:#FAFAFA}
.dark .ios-search-input::placeholder{color:#6B6B6B}
.dark .ios-search-x{background:#141414;color:#525252}
.dock-item{flex-direction:row!important;gap:7px!important;padding:10px 18px!important;border-radius:20px!important;font-size:13.5px!important;white-space:nowrap!important;flex-shrink:0}
.dock{max-width:calc(100vw - 40px)}
.dock-item .d-label{font-size:13.5px!important}
.dock-item .d-icon svg{width:17px!important;height:17px!important}
.dock-item.active{background:linear-gradient(135deg,#7c6cf6,#5b4fe0)!important;color:#fff!important;box-shadow:0 4px 16px rgba(124,108,246,.4)}
@media(max-width:460px){.dock-item{padding:10px 11px!important;gap:4px!important}.dock{gap:0}}
/* 磁吸按钮 */
.btn-mag{transition:transform .18s cubic-bezier(.34,1.56,.64,1),box-shadow .2s!important;will-change:transform}
${managementStyles}
${iconStyles}
${filenameStyles}
${autoRulesStyles}
${duplicatesStyles}
</style>
<script>try{var v=null;try{v=localStorage.getItem('fwh_theme')}catch(_e){}var d=document.documentElement;if(v==='dark')d.classList.add('dark');else if(v==='light')d.classList.add('light');else if(window.matchMedia&&matchMedia('(prefers-color-scheme:dark)').matches)d.classList.add('dark');}catch(e){try{if(matchMedia('(prefers-color-scheme:dark)').matches)document.documentElement.classList.add('dark')}catch(_e2){}}
// 磁吸按钮
document.querySelectorAll('.btn-mag').forEach(function(btn){
  var R = 70;
  document.addEventListener('pointermove', function(e){
    var r = btn.getBoundingClientRect();
    if(r.width===0) return;
    var cx = r.left + r.width/2, cy = r.top + r.height/2;
    var dx = e.clientX - cx, dy = e.clientY - cy;
    var d = Math.hypot(dx, dy);
    if(d < R && d > 0){
      var pull = (1 - d/R) * 10;
      btn.style.transform = 'translate('+(dx/d*pull)+'px,'+(dy/d*pull)+'px) scale(1.04)';
    } else {
      btn.style.transform = '';
    }
  });
  btn.addEventListener('pointerleave', function(){ btn.style.transform=''; });
});
</script>
</head>
<body>
<div id="bootLoader"><div class="boot-spin"></div></div>
<div id="loginGate">
<div class="login-card"><div class="logo-img"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAMT0lEQVR42u2da4xdVRXHf/veaWmhL4TSCkUsDxFKAUMfkSivRgIVCIhBQCSoQHh8QCPxgxrFiMYoRIgJGoyYWITwCFRAMAoVA0p5SFsIjxDlUSiPVmmpLbXt3Pv3w12bWZyeO3PvzNnnnqHdyWRm7uOcvf7ruddeex3YMXaM4QxJQVIY7XSEKgNs8wtunk1AIQTtEME0oNck9Umqd/DZsZJ2Hu3aFaoAOlALIfRnXt8Z2BvYDzgMmA7MBHYBJtlPP3BcCOEtSbUQQnO0CV1fD4GvmzlpmmlB0qHAfOAY4EhgL2DMIJfZCowtUvJDCJK0l83t9fjaB4YBkuohhEYIoWH/7w98HjgFmAdkzc97DMpobAA2AUWCUwMawKHG2N+710Y3A3KAXwhcDBwHeFvecAAHA6CWvZx7L8XYBxhXhpnuKwH4GkAIoWGO7UzgEuBTOaDXcjSgF1HhLGCnUe8DotTb3wuA7wGf9iFlBUDPmjuAg4EpGeEYdYukuv09U9IiDYyGpH6NbDTt938lzfCaNsJ1B5LGS1olaa2kSf69FKOWSOplJudLwFLgHOdMqyTxeebn48A004A5qXBKwgBJfQb8FEk3AL8F9rB4vZaSkAKxONUJyIKqZwzeB779PlzScjMR/c5cFDmSmCBJdUlPuvs8JWlM5XNOzt6fIWm9TX6r0o1CGWDAB0nHOD/VsL9P9D6tcibImZ1LgVuAiRY59DGKhq12L8xEaACX2nuqstn5Zo7kaDRogNPeuZI22/yb7j5bJM3xn60a+F9PbO+TMSATLi9xdCjz9xLnI0KVwL+4B+AXyYBIx0U54GeZcL7/ThUc7mcNiEbJ4BfCAEfHQZLWDUJHpHGtpFlFm6JuJ10zhzsLWJSziBktK/VIxxTgZmDyIHTE16YAN0v6kH23VioD3FJ9InAjsKtb2Y4m8OshhKak8ZZuPsyitloHaerZwK2Sxto16mVqQNxx+iVwuK1u66MM/D4n+XcDRxmwndBRt88uAO6SNNmu1VeK1NjvM0tYZBXuA2yvueZs/hODON2hRvzOMkmzs9FUEntpN9hD0hvOKVWaAS5srLnXviLp3yMAP8uEtyVdkMGq2FDVSf/1BUx8uGDHFLb/aUYGGNh9Rvw2VRWS5km6L5MSH+nw13hQ0jE56Y04p9qwmOLAn1dyyNl0QA821kua3mbuu0g6RdKdDqyi1yvNzBzvk3SapAnd5sDbmh/LgfwROL4LhzWSkb3HRuBlYA0De8HTgBm0KibmAetpbaLvbpHKUbSqKmYOct2i51xzeL4IPAE8DjwLrAJWhhDWdsyAuJ0o6UTg3pLB7wduA+40Il6NW5tuNTqdVtnKrsDZwAnA1Mz1/LZnyrVKvI/Hpx94xhjxHLAkhLCs4zIXFzXcX5Lt93mXOW3yNm0r1iTtJ+kySY+0uW5KUxnHS5J+IekESbsW4XjnlGT3IxHXOsbX2zkwY0TNh5eZ94+TdKu7borIzQO/XNL5cQ85JxLrLjJyDLihhLg/EvLzkcTUMQTMvDZH0m2ZezULnPMaS0iOzUQ/ww9FnQTubWGeEmpAJOTvLoYuYpMoG/8vzGw1NkZgcuJ375C0b3ZXrchU81cT29BIzGZJR6TY8MisgMdL+qGjp38E4P/I41X0witO+N4cJ5NC+q9Lvdvkry3pWEmvdGlaPQ7fyDI3BfgzEpufpv1sknRAdKqJ81nBafdHJC3tggkR/MuTSH2O+Tk7sfmJ171jpBUNI6BxkqTFHdAZ3/tZUvAzk7sucfQTbenJSTOJQ0d5dRcl9Q8yz6VWH5R2T9htujySUAOiSXvL8vJJay87yPKOlfSXHHqj090o6eDkVRHO/u/liquaCc3PXWWbn0FonirphYzUx3lek3IzvpaTF5pFq7iqmSh/EvMgDw9nX7rIEbcVQwhrgHOBzTa/uNW6FrjKNLRZFgMOcgmmFCOq8eMZhvSKCQ3bqlwK/MQlAwNwUwjhNbcdm5QBEYgDU2q9EbYR+FcVGBCzsGaOrgZetTR3P7AotX/KU//JiRmA5cffrAoDLD0cQgjvAD82IVketdSnwlMyIKrYRxPa5gj2yhDCFqvPqUrRa9Ok/Wbgf8BDZnaShsh9XgpsAuNKIPadTnbkytYCE4i1kh4AnjWzVOgqPetL4sIr7tKMZeBwWtmmrxJ8MCG8B3jaHyJPrgFOIsuQyq0VZUDTNOEPwHRJBxgeIzWTMt+6GXjO+5ReVfpWtdtJLEHcE3iwQIEUrXPH/7Ewf020OnkMKEMDxlaUAcGF4uMovva1nnXqfS4MA9gCrCtD1an2mGNS2yhQA2qG79a2PsCW5v0lEDitooyIC7KjDfh6gQwAeNcWodtGIy7UWp3QTkdi9pS0kwt9ez7iAXNaRV2HkKb0fn3UgGh18nJBr5XAgGnAh6u2FjBhuMJwKZL+eK3Xs4c78hjwSmIn16TV9eqAqjAgnhugVWF3NMVXAb7HgCzNecm4FxMDE+3+YVVggK1++yXNBK4hXRoeWiWKQzJghdmpemIzdGSvHXEsPrbCqt/QKu5NsVKP11ueNe95DPgn8FIJfmCupAkWeYVegW///s6ZnqLBjyHoBuD5tgywiKQeQtgK/COhdNbsujOA+QZ+rWTw6y4pdgOtnnWpqr/jfZ4GVtkKuEkbVYuS+FBJfuCcstPR7qDeBOB24DzSHjiM9P3NaK3nrgMywDyUeFLxuqdK2pNWLr6Mwqy6Odx9gfuBzxmdKXNika4/55n12rbzVDBv/UxCMxRM5acAXzbJqCWW+tjF63RaXbzmk76rS6RrNfBoHp61TCpCQGy0d2viKCU6wcvsnFfhWhALqUzqd5f0KzM7UynvxA/A3SGEd9xqu60GeMAXu3A05aJsKnBlUdt/vtLOdWw8D3gMON+YLso5ZB7vcWPXIZoR8kDiCmlfAHWO3bvrFmHuxExf5vWFkh4u6bhSXllj0wq+xnXVENzVTp5e4LnaoeruN0k62QHa1+58rQO8ngP6OElnZc6K9ffgcHm2nL0+2KIoLykFrY2TFcDHnENJ5ayCmbzvAj/NnIoMA25q2wIpI26uxfMnMVDbpMTzHir0XAccGEJY0+50ZCfHVC8CflGC05Kbz6PAr4ElwMvZuhxJk2kdUT0E+CStBhqzc/xYrzb/I1ZXhxAu9x2Eu2FAfG888GQJWpAnsZssObjaOe0JtJ4rsEeOQFShP2mU8vWWcFzZTnOHXOk6LTgLuKmk0C1KcCeRSsMxrCqlLhGj74cQrhhM+jtKNVhsXgMeoLv+OkVqhNqsLqvWqSumsleZSVzPEM+86URqgj1e5GsMbCiXlb+Jibp65idQzTZp0Y9dFkJYZ9ipkzzFYOg3TI2WAVcx0Dlqx8g3PbeFEO4YyvTQjQq7lHEN+KtFHmWaoqqPaHrepNXObc1gjrdbExRzRLK9gvOAtxnI62/vQ44BF4YQVtPFgY6OIwd3nOcF4CIXFmqH6aEP+EEI4R63wd+xkxtOardf0reBK0mfT6/yiLQvBk6PQtnNJtNwGBBMxRqSrgcu2E6ZEGl+nNZzcbY4c00yBjgmxO/eDpy2nTEh0roCODGE8IaG+SS/Ya0eXT990Xos1WKbUP92BP5TwEkjAX9EySp3sG0L8AVLVfS59MAHGfxlwPEhhNcyFRblMcBFRiGEsCWE8EUGztmGD9hiTS7a+ROwwD1AtPd0+nYz1uhpQ0VaHBfdG+5aSWNcjqxCIvL+p1HMl7SiTWfB0TL8vDdIusTRWt2O8a7lzXhJ1/R4W7AIqX9M0ieMpmo8wqQDJviDH8dKenQUMKKZmdsGSd+KHRHV60eXjNAkjVHrOS0vV5AReSZykexxJZU3OR0wwjfM203SdyS9mAFga8nMyGsO3rBG35/xcx8VJqcbbbD/J0o6N6fNcGRGii7nDXdtP9aZxM/zEl+W1IeyGRHzSO7/I4EzgIXA/m3ibz/XMMjclfM7nnb0Ywut+tBbgHtCCCudqQllxvahVxrhGRGjJuAI4FhaGz5zGTixUsRC6gVa5S4P0+qE8nzGTCpVU6bKMSDLCFtVZ2t/ptI61j/bfu8D7EarbX0dmJQz/420NsLfBN4y0J+hVe39vKVN/L3rlj7u2cZS1Y6I1lxOvdnmc+PtcxPbMOBdKyJoFxCEXoNeSQYMwRCw3bdO8u2Z776Xua1Qc6jqM2AIcDvJ1O4YO8bQ4/+y7AiOElPLrgAAAABJRU5ErkJggg==" alt=""></div><h2>Widget Hub</h2><p class="sub">请输入管理密码继续</p><input type="password" id="pwInput" class="input" placeholder="管理密码" onkeydown="if(event.key==='Enter')login()"><button class="btn btn-primary" onclick="login()">登 录</button><p id="loginErr" class="login-err"></p></div></div>

<div id="appMain" style="display:none">
<div class="header"><div class="header-in">
<div class="avatar"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAMT0lEQVR42u2da4xdVRXHf/veaWmhL4TSCkUsDxFKAUMfkSivRgIVCIhBQCSoQHh8QCPxgxrFiMYoRIgJGoyYWITwCFRAMAoVA0p5SFsIjxDlUSiPVmmpLbXt3Pv3w12bWZyeO3PvzNnnnqHdyWRm7uOcvf7ruddeex3YMXaM4QxJQVIY7XSEKgNs8wtunk1AIQTtEME0oNck9Umqd/DZsZJ2Hu3aFaoAOlALIfRnXt8Z2BvYDzgMmA7MBHYBJtlPP3BcCOEtSbUQQnO0CV1fD4GvmzlpmmlB0qHAfOAY4EhgL2DMIJfZCowtUvJDCJK0l83t9fjaB4YBkuohhEYIoWH/7w98HjgFmAdkzc97DMpobAA2AUWCUwMawKHG2N+710Y3A3KAXwhcDBwHeFvecAAHA6CWvZx7L8XYBxhXhpnuKwH4GkAIoWGO7UzgEuBTOaDXcjSgF1HhLGCnUe8DotTb3wuA7wGf9iFlBUDPmjuAg4EpGeEYdYukuv09U9IiDYyGpH6NbDTt938lzfCaNsJ1B5LGS1olaa2kSf69FKOWSOplJudLwFLgHOdMqyTxeebn48A004A5qXBKwgBJfQb8FEk3AL8F9rB4vZaSkAKxONUJyIKqZwzeB779PlzScjMR/c5cFDmSmCBJdUlPuvs8JWlM5XNOzt6fIWm9TX6r0o1CGWDAB0nHOD/VsL9P9D6tcibImZ1LgVuAiRY59DGKhq12L8xEaACX2nuqstn5Zo7kaDRogNPeuZI22/yb7j5bJM3xn60a+F9PbO+TMSATLi9xdCjz9xLnI0KVwL+4B+AXyYBIx0U54GeZcL7/ThUc7mcNiEbJ4BfCAEfHQZLWDUJHpHGtpFlFm6JuJ10zhzsLWJSziBktK/VIxxTgZmDyIHTE16YAN0v6kH23VioD3FJ9InAjsKtb2Y4m8OshhKak8ZZuPsyitloHaerZwK2Sxto16mVqQNxx+iVwuK1u66MM/D4n+XcDRxmwndBRt88uAO6SNNmu1VeK1NjvM0tYZBXuA2yvueZs/hODON2hRvzOMkmzs9FUEntpN9hD0hvOKVWaAS5srLnXviLp3yMAP8uEtyVdkMGq2FDVSf/1BUx8uGDHFLb/aUYGGNh9Rvw2VRWS5km6L5MSH+nw13hQ0jE56Y04p9qwmOLAn1dyyNl0QA821kua3mbuu0g6RdKdDqyi1yvNzBzvk3SapAnd5sDbmh/LgfwROL4LhzWSkb3HRuBlYA0De8HTgBm0KibmAetpbaLvbpHKUbSqKmYOct2i51xzeL4IPAE8DjwLrAJWhhDWdsyAuJ0o6UTg3pLB7wduA+40Il6NW5tuNTqdVtnKrsDZwAnA1Mz1/LZnyrVKvI/Hpx94xhjxHLAkhLCs4zIXFzXcX5Lt93mXOW3yNm0r1iTtJ+kySY+0uW5KUxnHS5J+IekESbsW4XjnlGT3IxHXOsbX2zkwY0TNh5eZ94+TdKu7borIzQO/XNL5cQ85JxLrLjJyDLihhLg/EvLzkcTUMQTMvDZH0m2ZezULnPMaS0iOzUQ/ww9FnQTubWGeEmpAJOTvLoYuYpMoG/8vzGw1NkZgcuJ375C0b3ZXrchU81cT29BIzGZJR6TY8MisgMdL+qGjp38E4P/I41X0witO+N4cJ5NC+q9Lvdvkry3pWEmvdGlaPQ7fyDI3BfgzEpufpv1sknRAdKqJ81nBafdHJC3tggkR/MuTSH2O+Tk7sfmJ171jpBUNI6BxkqTFHdAZ3/tZUvAzk7sucfQTbenJSTOJQ0d5dRcl9Q8yz6VWH5R2T9htujySUAOiSXvL8vJJay87yPKOlfSXHHqj090o6eDkVRHO/u/liquaCc3PXWWbn0FonirphYzUx3lek3IzvpaTF5pFq7iqmSh/EvMgDw9nX7rIEbcVQwhrgHOBzTa/uNW6FrjKNLRZFgMOcgmmFCOq8eMZhvSKCQ3bqlwK/MQlAwNwUwjhNbcdm5QBEYgDU2q9EbYR+FcVGBCzsGaOrgZetTR3P7AotX/KU//JiRmA5cffrAoDLD0cQgjvAD82IVketdSnwlMyIKrYRxPa5gj2yhDCFqvPqUrRa9Ok/Wbgf8BDZnaShsh9XgpsAuNKIPadTnbkytYCE4i1kh4AnjWzVOgqPetL4sIr7tKMZeBwWtmmrxJ8MCG8B3jaHyJPrgFOIsuQyq0VZUDTNOEPwHRJBxgeIzWTMt+6GXjO+5ReVfpWtdtJLEHcE3iwQIEUrXPH/7Ewf020OnkMKEMDxlaUAcGF4uMovva1nnXqfS4MA9gCrCtD1an2mGNS2yhQA2qG79a2PsCW5v0lEDitooyIC7KjDfh6gQwAeNcWodtGIy7UWp3QTkdi9pS0kwt9ez7iAXNaRV2HkKb0fn3UgGh18nJBr5XAgGnAh6u2FjBhuMJwKZL+eK3Xs4c78hjwSmIn16TV9eqAqjAgnhugVWF3NMVXAb7HgCzNecm4FxMDE+3+YVVggK1++yXNBK4hXRoeWiWKQzJghdmpemIzdGSvHXEsPrbCqt/QKu5NsVKP11ueNe95DPgn8FIJfmCupAkWeYVegW///s6ZnqLBjyHoBuD5tgywiKQeQtgK/COhdNbsujOA+QZ+rWTw6y4pdgOtnnWpqr/jfZ4GVtkKuEkbVYuS+FBJfuCcstPR7qDeBOB24DzSHjiM9P3NaK3nrgMywDyUeFLxuqdK2pNWLr6Mwqy6Odx9gfuBzxmdKXNika4/55n12rbzVDBv/UxCMxRM5acAXzbJqCWW+tjF63RaXbzmk76rS6RrNfBoHp61TCpCQGy0d2viKCU6wcvsnFfhWhALqUzqd5f0KzM7UynvxA/A3SGEd9xqu60GeMAXu3A05aJsKnBlUdt/vtLOdWw8D3gMON+YLso5ZB7vcWPXIZoR8kDiCmlfAHWO3bvrFmHuxExf5vWFkh4u6bhSXllj0wq+xnXVENzVTp5e4LnaoeruN0k62QHa1+58rQO8ngP6OElnZc6K9ffgcHm2nL0+2KIoLykFrY2TFcDHnENJ5ayCmbzvAj/NnIoMA25q2wIpI26uxfMnMVDbpMTzHir0XAccGEJY0+50ZCfHVC8CflGC05Kbz6PAr4ElwMvZuhxJk2kdUT0E+CStBhqzc/xYrzb/I1ZXhxAu9x2Eu2FAfG888GQJWpAnsZssObjaOe0JtJ4rsEeOQFShP2mU8vWWcFzZTnOHXOk6LTgLuKmk0C1KcCeRSsMxrCqlLhGj74cQrhhM+jtKNVhsXgMeoLv+OkVqhNqsLqvWqSumsleZSVzPEM+86URqgj1e5GsMbCiXlb+Jibp65idQzTZp0Y9dFkJYZ9ipkzzFYOg3TI2WAVcx0Dlqx8g3PbeFEO4YyvTQjQq7lHEN+KtFHmWaoqqPaHrepNXObc1gjrdbExRzRLK9gvOAtxnI62/vQ44BF4YQVtPFgY6OIwd3nOcF4CIXFmqH6aEP+EEI4R63wd+xkxtOardf0reBK0mfT6/yiLQvBk6PQtnNJtNwGBBMxRqSrgcu2E6ZEGl+nNZzcbY4c00yBjgmxO/eDpy2nTEh0roCODGE8IaG+SS/Ya0eXT990Xos1WKbUP92BP5TwEkjAX9EySp3sG0L8AVLVfS59MAHGfxlwPEhhNcyFRblMcBFRiGEsCWE8EUGztmGD9hiTS7a+ROwwD1AtPd0+nYz1uhpQ0VaHBfdG+5aSWNcjqxCIvL+p1HMl7SiTWfB0TL8vDdIusTRWt2O8a7lzXhJ1/R4W7AIqX9M0ieMpmo8wqQDJviDH8dKenQUMKKZmdsGSd+KHRHV60eXjNAkjVHrOS0vV5AReSZykexxJZU3OR0wwjfM203SdyS9mAFga8nMyGsO3rBG35/xcx8VJqcbbbD/J0o6N6fNcGRGii7nDXdtP9aZxM/zEl+W1IeyGRHzSO7/I4EzgIXA/m3ibz/XMMjclfM7nnb0Ywut+tBbgHtCCCudqQllxvahVxrhGRGjJuAI4FhaGz5zGTixUsRC6gVa5S4P0+qE8nzGTCpVU6bKMSDLCFtVZ2t/ptI61j/bfu8D7EarbX0dmJQz/420NsLfBN4y0J+hVe39vKVN/L3rlj7u2cZS1Y6I1lxOvdnmc+PtcxPbMOBdKyJoFxCEXoNeSQYMwRCw3bdO8u2Z776Xua1Qc6jqM2AIcDvJ1O4YO8bQ4/+y7AiOElPLrgAAAABJRU5ErkJggg==" style="width:26px;height:26px;display:block" alt=""/></div>
<div><h1 id="pageTitle">模块</h1></div>
<div class="spacer"></div>
<button class="btn-xs theme-btn" id="btnThemeToggle" onclick="toggleTheme()" title="切换主题">&#x1f313;</button>
</div></div>

<div class="main">
<div id="page-modules" class="page">
<div class="page-head"><span class="count" id="modCount">0 个模块</span><div class="actions"><span class="ios-search"><svg class="ios-search-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg><input class="ios-search-input" id="modSearch" type="search" placeholder="Search…" oninput="onModSearch()"><button class="ios-search-x" id="modSearchX" onclick="clearModSearch()" aria-label="清除搜索"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></span><button class="btn btn-sm btn-mag" onclick="showImportUrl()" style="margin-left:auto"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.7-1.7"/></svg> 链接</button><button class="btn btn-primary btn-sm btn-mag" onclick="showUploadMods()">&#xff0b; 上传</button></div></div>
<div style="display:flex;gap:6px;align-items:flex-start"><div class="folder-tabs" id="groupTabs" style="display:flex;gap:6px;overflow-x:auto;padding:2px 4px 12px;scrollbar-width:none;flex:1;min-width:0"></div><div class="od-root" id="groupOdRoot"><button class="ftab od-trigger" onclick="toggleGroupMenu(event)" aria-haspopup="menu" aria-expanded="false" style="color:var(--accent);border-style:dashed;background:transparent;flex-shrink:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="width:14px;height:14px;vertical-align:-2px"><path d="M12 5v14M5 12h14"/></svg> 分组<svg class="od-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px"><path d="m6 9 6 6 6-6"/></svg></button><div class="od-menu" role="menu"><button class="mi" role="menuitem" onclick="closeGroupMenu();showNewGroup()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="flex-shrink:0"><path d="M12 5v14M5 12h14"/></svg>新建分组</button><button class="mi" role="menuitem" onclick="closeGroupMenu();showGroupSort()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>管理分组</button></div></div></div><div id="modulesList"><div class="card" style="padding:10px 18px 6px"><div class="skel-row"><div class="skel-ico"></div><div class="skel-tx"><div class="skel-l1"></div><div class="skel-l2"></div></div></div><div class="skel-row"><div class="skel-ico"></div><div class="skel-tx"><div class="skel-l1"></div><div class="skel-l2"></div></div></div><div class="skel-row"><div class="skel-ico"></div><div class="skel-tx"><div class="skel-l1"></div><div class="skel-l2"></div></div></div></div></div></div>

<div id="page-collections" class="page">
<div class="page-head"><span class="count" id="colCount"></span><div class="actions"><button class="btn btn-primary btn-sm" onclick="showAddCol()" style="margin-left:auto">&#xff0b; 新建合集</button></div></div>
<div id="collectionsList"></div></div>

<div id="page-subscriptions" class="page">
<div class="page-head"><span class="count" id="sourceCount">订阅源</span><button class="btn btn-primary btn-sm" onclick="showImportUrl()">＋ 添加订阅</button></div>
<p style="font-size:13px;color:var(--text2);line-height:1.7;margin-bottom:16px">每 6 小时检查上游，较大的合集会分批同步。导入的模块可加入你自己的合集，并持续更新；不会改变你的分组、排序和备注。上游下架只标记，不删除本地模块。</p>
<div id="subscriptionsList"></div></div>

<div id="page-settings" class="page">
<div class="set-sec">数据统计</div>
<div class="stat-box"><div class="stat"><div class="num" id="statCols">0</div><div class="lbl">合集</div></div><div class="stat"><div class="num" id="statMods">0</div><div class="lbl">模块</div></div><div class="stat"><div class="num" id="statSize">0</div><div class="lbl">总大小</div></div></div>
<div class="set-sec">排序</div>
<div class="set-group"><div class="set-row" onclick="openSortModal()"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5h10"/><path d="M11 9h7"/><path d="M11 13h4"/><path d="M3 17l3 3 3-3"/><path d="M6 18V4"/></svg><div><div style="font-weight:600">调整顺序</div><div style="font-size:12px;color:var(--text2);margin-top:1px">调整模块和分组的显示顺序</div></div><span class="chev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg></span></div></div>
<div class="set-sec">工具</div>
<div class="set-group" id="settingsTools">
<div class="set-row" onclick="exportData()"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>备份（模块+合集+订阅源+图标）</div>
<div class="set-row" onclick="importBackup()"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V6"/><path d="M6 12l6-6 6 6"/><path d="M4 21h16"/></svg>恢复（上传备份文件）</div>
<div class="set-row danger" onclick="clearAllData()"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>清除所有数据</div>
</div>
<div class="set-sec">修改密码</div>
<div class="set-group"><div class="set-row" style="cursor:default"><input type="password" id="pwdNew" placeholder="新密码" style="flex:1;min-width:0;background:transparent;border:none;outline:none;font-size:14.5px;color:var(--text);font-family:inherit"><button onclick="changePassword()" style="flex-shrink:0;border:none;cursor:pointer;font-size:14px;font-weight:700;color:#fff;background:var(--accent);border-radius:10px;padding:8px 16px;font-family:inherit">修改</button></div></div>
<div class="set-sec">关于</div>
<!-- [自改A2] 关于页同时适用 CF 与 Docker，版本号与作者原版一致（3.5.0） -->
<div class="set-group"><div class="set-row" style="cursor:default"><div style="font-size:13px;color:var(--text2);line-height:1.7">Rex Hub · 3.5.0<br>Cloudflare Workers / Docker · 同一份代码</div></div></div>
</div>
</div>

<div class="dock">
<button class="dock-item" data-tab="subscriptions" onclick="switchTab('subscriptions')"><span class="d-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5a15 15 0 0115 15M4 11a9 9 0 019 9"/><circle cx="5" cy="19" r="1"/></svg></span><span class="d-label">订阅</span></button>
<button class="dock-item active" data-tab="modules" onclick="switchTab('modules')"><span class="d-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg></span><span class="d-label">模块</span></button>
<button class="dock-item" data-tab="collections" onclick="switchTab('collections')"><span class="d-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/></svg></span><span class="d-label">合集</span></button>
<button class="dock-item" data-tab="settings" onclick="switchTab('settings')"><span class="d-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33h.01a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51h.01a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v.01a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg></span><span class="d-label">设置</span></button></div>
</div>

<div id="editorOverlay">
  <div class="ed-bar">
    <button class="btn-xs" onclick="closeEditor()" style="font-size:16px">&#x2715;</button>
    <span class="ed-title" id="edTitle">源码编辑</span>
    <input class="ed-fname" id="edFilename" placeholder="文件名.js">
    <button class="btn-xs" id="edSaveBtn" onclick="saveEditor()" style="font-size:16px" title="保存">&#x1f4be;</button>
  </div>
  <div class="ed-body">
    <div class="ed-gutter" id="edGutter">1</div>
    <textarea id="edCode" spellcheck="false" autocapitalize="off" autocorrect="off" wrap="off"></textarea>
  </div>
  <div class="ed-foot">
    <span class="ed-dot" id="edDot"></span>
    <span id="edState">已保存</span>
    <span style="flex:1"></span>
    <span id="edLines">1 行</span>
    <span id="edSize">0 B</span>
  </div>
</div>

<div class="toast" id="toast"></div>
<input type="file" id="replaceFileInput" accept=".js,application/javascript,text/javascript" style="position:fixed;top:-100px;left:-100px;opacity:0.01;width:1px;height:1px" onchange="doReplaceMod(this)">

<script>
var state = { modules: [], collections: [], groups: [], subscriptions: [], tab: 'modules', modReplaceId: null, isAuthed: false, activeGroup: '' };

function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
function escJs(s){
  return String(s==null?'':s)
    .replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/\r?\n/g,'\\n')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmt(b){ b=b||0; if(b<1024) return b+' B'; if(b<1048576) return (b/1024).toFixed(1)+' KB'; if(b<1073741824) return (b/1048576).toFixed(1)+' MB'; return (b/1073741824).toFixed(2)+' GB'; }
function debounce(fn,ms){ var t=null; return function(){ var a=arguments,c=this; clearTimeout(t); t=setTimeout(function(){ fn.apply(c,a); },ms); }; }
function org(){ return location.origin; }
function toast(m){ var t=document.getElementById('toast'); t.textContent=m; t.classList.add('show'); clearTimeout(t._t); t._t=setTimeout(function(){ t.classList.remove('show'); },2000); }

async function api(path, opts){
  opts = opts || {};
  var ctrl=null, timer=null;
  try{ ctrl=new AbortController(); }catch(e){ ctrl=null; }
  var fo = { method: opts.method || 'GET', headers: {} };
  var _to = typeof opts.timeout==='number' ? opts.timeout : (opts.body ? 120000 : 15000);
  if(ctrl){ fo.signal=ctrl.signal; timer=setTimeout(function(){ try{ctrl.abort();}catch(e){} },_to); }
  if(opts.json){ fo.headers['Content-Type']='application/json'; fo.body=JSON.stringify(opts.json); }
  if(opts.body) fo.body = opts.body;
  var r;
  try{ r = await fetch(path, fo); }
  finally{ if(timer) clearTimeout(timer); }
  if(r.status===401){ state.isAuthed=false; showLogin(); return null; }
  if(r.status===204) return {ok:true};
  return r.json().catch(function(){ return null; });
}

function showLogin(){ document.getElementById('bootLoader').style.display='none'; document.getElementById('loginGate').style.display='flex'; document.getElementById('appMain').style.display='none'; state.isAuthed=false; }
function showApp(){ document.getElementById('bootLoader').style.display='none'; document.getElementById('loginGate').style.display='none'; document.getElementById('appMain').style.display='block'; loadAll(); }

async function checkAuth(){
  var r=null;
  try{ r = await api('/api/admin/auth'); }catch(e){ r=null; }
  if(!r){ showLogin(); return; }
  if(r.authenticated){ state.isAuthed=true; showApp(); loadAll(); } else showLogin();
}

async function login(){
  var pw = document.getElementById('pwInput').value;
  if(!pw) return;
  var r = await api('/api/admin/auth', {method:'POST',json:{password:pw}});
  if(r&&r.ok){ state.isAuthed=true; showApp(); document.getElementById('pwInput').value=''; }
  else { var e=document.getElementById('loginErr'); e.style.display='block'; e.textContent='密码错误'; }
}

var _loadP=null;
async function loadAll(){
  if(_loadP) return _loadP;
  _loadP=(async function(){
    var res=null;
    for(var i=0;i<2 && !res;i++){
      try{ res = await Promise.all([api('/api/admin/modules'), api('/api/admin/collections'), api('/api/admin/groups'), api('/api/admin/subscriptions')]); }
      catch(e){ res=null; }
    }
    if(!res){
      document.getElementById('modulesList').innerHTML='<div class="empty"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22.61 16.95A5 5 0 0018 10h-1.26a8 8 0 00-7.05-6M5 5a8 8 0 004 15h9a5 5 0 001.7-.3"/><path d="M1 1l22 22"/></svg></div><p>加载失败，可能是网络问题</p><button class="ftab" onclick="loadAll()" style="margin-top:10px">重新加载</button></div>';
      return;
    }
    var mr = res[0], cr = res[1];
    if(mr && Array.isArray(mr)) state.modules = mr;
    var gr = res[2];
    if(gr && Array.isArray(gr)) state.groups = gr;
    if(cr && Array.isArray(cr)) state.collections = cr;
    if(Array.isArray(res[3])) state.subscriptions = res[3];
    try{ localStorage.setItem('fwh_cache_v1', JSON.stringify({modules:state.modules,collections:state.collections,groups:state.groups})); }catch(e){}
    switchTab(state.tab);
  })();
  try{ await _loadP; }finally{ _loadP=null; }
}

function switchTab(tab){
  state.tab=tab;
  document.querySelectorAll('.page').forEach(function(p){ p.classList.remove('active'); });
  var pg = document.getElementById('page-'+tab); if(pg) pg.classList.add('active');
  document.querySelectorAll('.dock-item').forEach(function(el){ el.classList.toggle('active',el.dataset.tab===tab); });
  var titles={modules:'模块',collections:'合集',settings:'设置',subscriptions:'订阅源'};
  document.getElementById('pageTitle').textContent=titles[tab];

  if(tab==='modules') renderMods();
  if(tab==='collections') renderCols();
  if(tab==='settings') renderSettings();
  if(tab==='subscriptions') renderSubscriptions();
}

// ===== MODULES =====
function renderGroupTabs(){
  var el = document.getElementById('groupTabs');
  if(!el) return;
  var h = '<div class="ftab'+(state.activeGroup===''?' active':'')+'" onclick="setGroupTab(\'\')">\u5168\u90e8<span class="cnt">'+state.modules.length+'</span></div>';
  state.groups.forEach(function(g){
    var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
    h += '<div class="ftab'+(state.activeGroup===g.id?' active':'')+'" onclick="setGroupTab(\''+g.id+'\')">'+esc(g.name)+'<span class="cnt">'+n+'</span></div>';
  });
  el.innerHTML = h;
}
function setGroupTab(id){ state.activeGroup = id; renderGroupTabs(); renderMods(); }

// ===== 分组管理 =====






function toggleGroupMenu(e){
  if(e)e.stopPropagation();
  var root=document.getElementById('groupOdRoot');
  var willOpen=!root.classList.contains('open');
  closeGroupMenu();
  closeAllRowMenus();
  if(willOpen){
    root.classList.add('open');
    root.querySelector('.od-trigger').setAttribute('aria-expanded','true');
  }
}
function closeGroupMenu(){
  var root=document.getElementById('groupOdRoot');
  if(!root||!root.classList.contains('open'))return;
  root.classList.remove('open');
  root.querySelector('.od-trigger').setAttribute('aria-expanded','false');
}
function showNewGroup(){
  showModal('新建分组',
    '<input class="input" id="newGroupName2" placeholder="分组名" style="margin-bottom:0">',
    function(close){
      var name = document.getElementById('newGroupName2').value.trim();
      if(!name){ toast('请输入分组名'); return; }
      api('/api/admin/groups',{method:'POST',json:{name:name}}).then(function(r){
        if(r&&r.ok){ toast('已创建'); close(); loadAll(); } else toast('创建失败');
      });
    });
}

function showGroupSort(){
  var h = '<div id="gmanageList">';
  state.groups.forEach(function(g){
    var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
    h += '<div class="row" style="margin-bottom:8px;padding:10px 14px;border-radius:14px">'
      + '<div class="info"><div class="name">'+esc(g.name)+'</div><div class="sub">'+n+' 个模块</div></div>'
      + '<button class="btn-xs" onclick="renameGroup(\''+g.id+'\',\''+escJs(g.name)+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>'
      + '<button class="btn-xs danger" onclick="delGroup(\''+g.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg></button></div>';
  });
  h += '</div>';
  showModal('管理分组', h, function(close){ close(); });
}
function refreshGroupManageList(){
  var list = document.getElementById('gmanageList');
  if(!list) return;
  var h = '';
  state.groups.forEach(function(g){
    var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
    h += '<div class="row" style="margin-bottom:8px;padding:10px 14px;border-radius:14px">'
      + '<div class="info"><div class="name">'+esc(g.name)+'</div><div class="sub">'+n+' 个模块</div></div>'
      + '<button class="btn-xs" onclick="renameGroup(\''+g.id+'\',\''+escJs(g.name)+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>'
      + '<button class="btn-xs danger" onclick="delGroup(\''+g.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg></button></div>';
  });
  list.innerHTML = h;
}
var _gsortDrag = null;
function gsortTouchStart(e){ if(e.touches.length!==1) return; e.preventDefault(); gsortInit(e, true); }
function gsortMouseDown(e){ e.preventDefault(); gsortInit(e, false); }
function gsortInit(e, isTouch){
  var grip = e.currentTarget;
  var row = grip.closest('.gsort-row');
  var list = row.parentElement;
  var cy = isTouch ? e.touches[0].clientY : e.clientY;
  _gsortDrag = { gid: row.dataset.gid, startY: cy, row: row, list: list,
    rows: Array.prototype.slice.call(list.querySelectorAll('.gsort-row')),
    moved: false, isTouch: isTouch };
  if(isTouch){
    document.addEventListener('touchmove', gsortTouchMove, {passive:false});
    document.addEventListener('touchend', gsortTouchEnd);
  } else {
    document.addEventListener('mousemove', gsortMouseMove);
    document.addEventListener('mouseup', gsortMouseUp);
  }
}
function gsortMouseMove(e){ gsortDragMove(e.clientY); }
function gsortTouchMove(e){ if(!_gsortDrag||!_gsortDrag.isTouch||e.touches.length!==1) return; e.preventDefault(); gsortDragMove(e.touches[0].clientY); }
function gsortDragMove(cy){
  var d = _gsortDrag; if(!d) return;
  var dy = cy - d.startY;
  if(!d.moved && Math.abs(dy) < 8) return;
  d.moved = true;
  d.row.style.transform = 'translateY('+dy+'px)';
  d.row.style.position = 'relative'; d.row.style.zIndex = '50'; d.row.style.opacity = '0.92';
  var others = d.rows.filter(function(r){ return r !== d.row; });
  var rh = d.row.offsetHeight, curTop = d.row.offsetTop + dy, ti = 0;
  for(var i=0;i<others.length;i++){
    if(curTop + rh/2 > others[i].offsetTop + others[i].offsetHeight/2) ti = i+1;
  }
  d.targetIdx = ti;
  others.forEach(function(r){
    var oi = d.rows.indexOf(r), fi = d.rows.indexOf(d.row), sh = 0;
    if(fi < ti){ if(oi > fi && oi <= ti) sh = -(rh+8); }
    else { if(oi >= ti && oi < fi) sh = rh+8; }
    r.style.transform = sh ? 'translateY('+sh+'px)' : '';
    r.style.transition = 'transform .15s';
  });
}
function gsortEnd(){
  var d = _gsortDrag; _gsortDrag = null;
  if(!d) return;
  document.removeEventListener('mousemove', gsortMouseMove);
  document.removeEventListener('mouseup', gsortMouseUp);
  document.removeEventListener('touchmove', gsortTouchMove);
  document.removeEventListener('touchend', gsortTouchEnd);
  if(!d.moved) return;
  var ids = d.rows.map(function(r){ return r.dataset.gid; });
  var from = ids.indexOf(d.gid);
  ids.splice(from,1);
  var to = Math.max(0, Math.min(d.targetIdx==null?ids.length:d.targetIdx, ids.length));
  ids.splice(to,0,d.gid);
  var map = {};
  state.groups.forEach(function(g){ map[g.id]=g; });
  state.groups = ids.map(function(id){ return map[id]; }).filter(Boolean);
  renderGroupTabs();
  if(_sortMode==='grp') renderGroupSortInModal();
}

function gsortMouseUp(){ gsortEnd(); }
function gsortTouchEnd(){ gsortEnd(); }


var _modSearchDebounced = debounce(function(){ renderMods(); },120);
function onModSearch(){ toggleSearchX(); _modSearchDebounced(); }
function toggleSearchX(){ var i=document.getElementById('modSearch'),x=document.getElementById('modSearchX'); if(i&&x) x.style.visibility=i.value?'visible':'hidden'; }
function clearModSearch(){ var i=document.getElementById('modSearch'); if(!i) return; i.value=''; i.blur(); renderMods(); toggleSearchX(); }
function onPickSearch(el){ var x=document.getElementById('pickSearchX'); if(x) x.style.visibility=el.value?'visible':'hidden'; try{window._pickSearch(el.value);}catch(e){} }
function clearPickSearch(){ var i=document.getElementById('pickModSearch'); if(!i) return; i.value=''; i.blur(); window._pickSearch(''); var x=document.getElementById('pickSearchX'); if(x) x.style.visibility='hidden'; }
// [自改A2] 模块行标签：当前分组（点击移入/更换分组）与所在合集（点击编辑合集归属）
function moduleTags(m){
  var g=m.group_id?state.groups.find(function(x){return x.id===m.group_id;}):null;
  var h='<div class="mod-tags">';
  h+='<button type="button" class="mod-tag '+(g?'mod-tag-group':'mod-tag-none')+'" onclick="event.stopPropagation();showMoveToGroup(\''+m.id+'\')">'+(g?'分组：'+esc(g.name):'未分类')+'</button>';
  state.collections.forEach(function(c){
    if((c.moduleIds||[]).indexOf(m.id)<0)return;
    if(c.autoAll)h+='<span class="mod-tag mod-tag-auto" title="此合集自动包含全部模块">合集：'+esc(c.title)+'（自动）</span>';
    else h+='<button type="button" class="mod-tag mod-tag-col" onclick="event.stopPropagation();showModuleCollections(\''+m.id+'\')">合集：'+esc(c.title)+'</button>';
  });
  if(state.collections.some(function(c){return !c.autoAll;}))h+='<button type="button" class="mod-tag mod-tag-add" onclick="event.stopPropagation();showModuleCollections(\''+m.id+'\')">＋合集</button>';
  return h+'</div>';
}
function moduleSubtitle(m){
  var parts=[];if(!m.hide_filename||m.named_url)parts.push(m.effective_filename||m.filename);parts.push(fmt(m.file_size));
  if(m.subscription_title)parts.push('订阅：'+m.subscription_title);
  var text=parts.filter(Boolean).map(esc).join(' · ');
  if(m.note)text+='<br>'+esc(m.note);
  if(m.upstream_active===0)text+='<br>上游已下架，保留本地';
  if(m.manual_override)text+='<br>手动维护 · 自动更新已暂停';
  return text;
}
function renderMods(){
  closeAllRowMenus();
  var q = (document.getElementById('modSearch').value || '').toLowerCase().trim();
  renderGroupTabs();
  var groupedView=state.activeGroup&&state.activeGroup!=='__none__';
  var ms = state.modules.filter(function(m){
    if(state.activeGroup==='__none__'?!!m.group_id:(groupedView&&m.group_id!==state.activeGroup)) return false;
    if (!q) return true;
    return ((m.title || '') + ' ' + (m.filename || '') + ' ' + (m.effective_filename||'')+' '+(m.note || '') + ' ' + (m.author || '')).toLowerCase().indexOf(q) >= 0;
  });
  document.getElementById('modCount').style.display = 'none';
  if(!ms.length){ document.getElementById('modulesList').innerHTML='<div class="empty"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5"/><path d="M12 13v8"/></svg></div><p>'+(q ? '没有匹配的模块' : '暂无模块')+'</p></div>'; return; }
  var h='<div class="card" style="padding:10px 18px 6px">';
  ms.forEach(function(m){
    var ib=m.is_encrypted?'var(--ico-encrypted)':'var(--ico-normal)';
    var ie=m.is_encrypted?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="3"/><path d="M8.5 10.5V7.8a3.5 3.5 0 017 0v2.7"/><circle cx="12" cy="15.5" r="1.3" fill="currentColor" stroke="none"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 7L3.5 12l5 5"/><path d="M15.5 7l5 5-5 5"/><path d="M13.2 5.5l-2.4 13"/></svg>';
    h+='<div class="row" data-mid="'+m.id+'"><div class="ico-sq" style="background:'+ib+';color:'+(m.is_encrypted?'var(--ico-encrypted-fg)':'var(--ico-normal-fg)')+'">'+ie+'</div><div class="info"><div class="name">'+esc(m.title||m.filename)+'</div><div class="sub">'+moduleSubtitle(m)+'</div>'+moduleTags(m)+'</div>'+
      (m.is_encrypted?'<span class="badge '+(m.source_url?'badge-green':'badge-orange')+'">加密</span>':'')+
      (m.version?'<span class="badge '+(m.source_url?'badge-green':'badge-blue')+'">'+esc(m.version)+'</span>':'')+

      '<div class="od-root row-od"><button class="btn-xs" aria-label="更多操作" onclick="toggleMenu(event,\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h8"/><path d="M18 7h2"/><path d="M4 17h2"/><path d="M12 17h8"/><circle cx="15" cy="7" r="2.6" fill="currentColor" stroke="none"/><circle cx="9" cy="17" r="2.6" fill="currentColor" stroke="none"/></svg></button>'+
      '<div class="od-menu" id="menu-'+m.id+'">'+
      (m.group_id?'<button class="mi" onclick="setModuleGroup(\''+m.id+'\',\'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg> 移出分组</button>':'')+
      '<button class="mi" onclick="showMoveToGroup(\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 20V5h5v4h9v11H5z"/></svg> '+(m.group_id?'移入其他分组':'添加到分组')+'</button>'+
      '<button class="mi" onclick="editMeta(\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> 编辑信息</button>'+
      '<button class="mi" onclick="openEditor(\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 18l6-6-6-6"/><path d="M8 6l-6 6 6 6"/></svg> 编辑源码</button>'+
      '<button class="mi" onclick="copyModLink(\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.7-1.7"/></svg> 复制链接</button>'+
      '<button class="mi" onclick="promptReplace(\''+m.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V6"/><path d="M6 12l6-6 6 6"/><path d="M4 21h16"/></svg> 替换文件</button>'+
      (m.source_url?'<button class="mi" onclick="refreshMod(\''+m.id+'\')" style="color:#16a34a"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-2.6-6.4"/><path d="M21 3v6h-6"/></svg> 刷新</button>':'')+
      '<button class="mi" onclick="showPreviousVersion(\''+m.id+'\')"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 1 2.6 6.4M3 12V6m0 6h6m3-5v5l3 2"/></svg> 恢复上一版</button>'+
      '<button class="mi" onclick="showShareModule(\''+m.id+'\')"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="12" r="3"/><circle cx="18" cy="5" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4m-6.8 7 6.8 4"/></svg> 分享模块</button>'+
      '<button class="mi" onclick="showModuleInfo(\''+m.id+'\')"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/></svg> 模块信息</button>'+
      '<button class="mi" onclick="downloadModule(\''+m.id+'\',this)"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/></svg> 下载模块</button>'+
      (m.source_url?'<button class="mi" onclick="setModuleMaintenance(\''+m.id+'\','+(m.manual_override?'false':'true')+')"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(m.manual_override?'<path d="m9 5 11 7-11 7z"/>':'<path d="M9 5v14m6-14v14"/>')+'</svg> '+(m.manual_override?'恢复自动更新':'转为手动维护')+'</button>':'')+
      '<button class="mi danger" onclick="promptDeleteMod(\''+m.id+'\',\''+escJs(m.title||m.filename)+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg> 删除</button></div></div></div>';
  });
  h+='</div>';
  document.getElementById('modulesList').innerHTML=h;

}

(function(){
  var list = document.getElementById('modulesList');
  if(!list || list._spot) return;
  list._spot = true;
  list.addEventListener('pointermove', function(e){
    var card = e.target && e.target.closest ? e.target.closest('.row') : null;
    if(!card) return;
    var r = card.getBoundingClientRect();
    card.style.setProperty('--mx', (e.clientX-r.left)+'px');
    card.style.setProperty('--my', (e.clientY-r.top)+'px');
  }, {passive:true});
})();
function renameGroup(id, oldName){
  showModal('重命名分组', '<label>分组名</label><input class="input" id="renameGroupName" value="'+esc(oldName)+'">', function(close){
    var name = document.getElementById('renameGroupName').value.trim();
    if(!name){ toast('请输入名称'); return; }
    api('/api/admin/groups',{method:'PATCH',json:{id:id,name:name}}).then(function(r){
      if(r&&r.ok){ toast('已重命名'); close(); loadAll().then(function(){ refreshGroupManageList(); }); } else toast('失败');
    });
  });
}
function delGroup(id){
  showConfirm('删除该分组？组内模块不受影响', function(ok){
    if(!ok) return;
    api('/api/admin/groups?id='+id,{method:'DELETE'}).then(function(r){
      if(r&&r.ok){ toast('已删除'); loadAll().then(function(){ refreshGroupManageList(); }); } else toast('删除失败');
    });
  });
}
async function writeModuleGroup(mid,gid){
  var r=await api('/api/admin/modules/group',{method:'POST',json:{moduleId:mid,groupId:gid}}),item=r&&r.results&&r.results[0];
  if(!r||!r.ok||!item||!item.ok)throw Error((item&&item.error)||(r&&r.error)||'更新分组失败');
}
async function setModuleGroup(mid,gid){
  try{await writeModuleGroup(mid,gid);toast('已移至未分类');await loadAll();}catch(e){if(state.isAuthed)toast(e.message);}
}
function showMoveToGroup(mid){
  var mod=state.modules.find(function(m){return m.id===mid;});if(!mod)return;
  var heading=mod.group_id?'移入其他分组':'添加到分组',previous=document.activeElement;
  var o=document.createElement('div');o.className='modal-overlay group-move-overlay';
  o.innerHTML='<div class="modal hub-dialog" role="dialog" aria-modal="true" aria-label="'+heading+'"><h3>'+heading+'</h3><p class="hub-help group-move-name"></p><div class="pick-list group-move-list"></div><p class="hub-error group-move-error" role="alert" hidden></p><div class="group-move-actions"><button type="button" class="btn group-move-cancel">取消</button></div></div>';
  o.querySelector('.group-move-name').textContent=mod.title||mod.filename;
  document.body.appendChild(o);
  var busy=false,list=o.querySelector('.group-move-list'),error=o.querySelector('.group-move-error'),cancel=o.querySelector('.group-move-cancel');
  function close(){if(busy)return;o.remove();if(previous&&previous.isConnected)previous.focus();}
  function lock(value){busy=value;o.querySelectorAll('button').forEach(function(b){b.disabled=value;});}
  function render(){
    var groups=state.groups.filter(function(g){return g.id!==mod.group_id;});list.replaceChildren();list.hidden=!groups.length;
    if(!groups.length){error.hidden=false;error.textContent=mod.group_id?'没有其他分组，请先创建新分组。':'还没有分组，请先创建分组。';}
    groups.forEach(function(g){
      var b=document.createElement('button');b.type='button';b.className='pick-item group-move-choice';b.textContent=g.name;list.append(b);
      b.onclick=async function(){
        if(busy)return;lock(true);error.hidden=true;
        try{
          await writeModuleGroup(mid,g.id);lock(false);close();toast('已移入「'+g.name+'」');await loadAll();
        }catch(e){
          lock(false);if(!state.isAuthed){close();return;}if(!o.isConnected)return;
          error.textContent=e.message;error.hidden=false;
          if(e.message==='分组不存在'){await loadAll();if(o.isConnected){render();(list.querySelector('button')||cancel).focus();}}
          else b.focus();
        }
      };
    });
  }
  cancel.onclick=close;o.onclick=function(e){if(e.target===o)close();};
  o.onkeydown=function(e){
    if(e.key==='Escape'){e.preventDefault();close();}
    if(e.key==='Tab'&&!busy){
      var first=list.querySelector('button')||cancel;
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();cancel.focus();}
      else if(!e.shiftKey&&document.activeElement===cancel){e.preventDefault();first.focus();}
    }
  };
  render();(list.querySelector('button')||cancel).focus();
}

// [自改A2] 编辑单个模块所属的合集（勾选即加入，取消勾选即移出；自动包含全部的合集不可改）
function showModuleCollections(mid){
  var mod=state.modules.find(function(m){return m.id===mid;});if(!mod)return;
  var cols=state.collections.filter(function(c){return !c.autoAll;});
  if(!cols.length){toast('还没有可编辑的合集，请先创建合集');return;}
  var previous=document.activeElement;
  var o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal hub-dialog" role="dialog" aria-modal="true" aria-label="编辑所属合集"><h3>所属合集</h3><p class="hub-help mod-col-name"></p><div class="pick-list mod-col-list"></div><p class="hub-error mod-col-error" role="alert" hidden></p><div class="btn-row"><button type="button" class="btn mod-col-cancel">取消</button><button type="button" class="btn btn-primary mod-col-save">保存</button></div></div>';
  o.querySelector('.mod-col-name').textContent=mod.title||mod.filename;
  var list=o.querySelector('.mod-col-list'),err=o.querySelector('.mod-col-error'),save=o.querySelector('.mod-col-save'),cancel=o.querySelector('.mod-col-cancel'),busy=false;
  cols.forEach(function(c){
    var lab=document.createElement('label');lab.className='pick-item';
    var cb=document.createElement('input');cb.type='checkbox';cb.dataset.cid=c.id;cb.checked=(c.moduleIds||[]).indexOf(mid)>=0;cb.dataset.was=cb.checked?'1':'0';
    var t=document.createElement('span');t.style.cssText='flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';t.textContent=c.title;
    lab.append(cb,t);list.append(lab);
  });
  function close(){if(busy)return;o.remove();if(previous&&previous.isConnected)previous.focus();}
  document.body.appendChild(o);
  cancel.onclick=close;o.onclick=function(e){if(e.target===o)close();};
  o.onkeydown=function(e){if(e.key==='Escape'){e.preventDefault();close();}};
  save.onclick=async function(){
    if(busy)return;
    var changes=[].slice.call(list.querySelectorAll('input')).filter(function(cb){return (cb.checked?'1':'0')!==cb.dataset.was;});
    if(!changes.length){close();return;}
    busy=true;save.disabled=cancel.disabled=true;err.hidden=true;
    var failed=[];
    for(var i=0;i<changes.length;i++){
      var cb=changes[i],c=state.collections.find(function(x){return x.id===cb.dataset.cid;});if(!c)continue;
      var cur=(c.moduleIds||[]).slice(),next=cb.checked?cur.concat([mid]):cur.filter(function(x){return x!==mid;});
      try{
        var r=await api('/api/admin/collections/'+c.id+'/members',{method:'PUT',json:{moduleIds:next,expectedModuleIds:cur}});
        if(!r||!r.ok)throw Error((r&&r.error)||'保存失败');
      }catch(e){failed.push(c.title+'：'+e.message);}
    }
    busy=false;
    if(!state.isAuthed){o.remove();return;}
    if(failed.length){save.disabled=cancel.disabled=false;err.textContent=failed.join('；');err.hidden=false;await loadAll();return;}
    o.remove();toast('已更新合集');await loadAll();
  };
  (list.querySelector('input')||cancel).focus();
}
// upload handled by direct input overlay

function openSortModal(){
  var m = document.getElementById('sortModal');
  if (!m) {
    m = document.createElement('div');
    m.id = 'sortModal';
    m.className = 'modal-mask';
    m.innerHTML = '<div class="modal-box"><div class="modal-head"><span>排序</span></div><div class="modal-sub">按住 ≡ 拖动排序，点保存生效</div><div style="display:flex;gap:6px;padding:0 18px 10px"><div class="ftab active" id="sortModeMod" onclick="setSortMode(\'mod\')">模块排序</div><div class="ftab" id="sortModeGrp" onclick="setSortMode(\'grp\')">分组排序</div></div><div id="sortTabs" style="display:flex;gap:6px;overflow-x:auto;padding:2px 18px 12px;scrollbar-width:none;flex-shrink:0"></div><div id="sortList" class="sort-scroll"></div><div class="modal-foot" style="gap:8px"><button class="btn" onclick="closeSortModal()">取消</button><button class="btn btn-primary" onclick="saveSortOrder()">保存排序</button></div></div>';
    m.addEventListener('click', function(e){ if (e.target === m) closeSortModal(); });
    document.body.appendChild(m);
  }
  m.style.display = 'flex';
  syncScrollLock();
  setSortMode('mod');
  renderSortList();
}
function closeSortModal(){
  if (_sortDirty && !confirm('排序尚未保存，确定关闭吗？')) return;
  _sortDirty = false;
  document.getElementById('sortModal').style.display = 'none';
  syncScrollLock();
}
var _sortDrag = null;
var _sortGroup = '';
var _sortMode = 'mod';
function setSortMode(m){
  _sortMode = m;
  var mm = document.getElementById('sortModeMod');
  var gm = document.getElementById('sortModeGrp');
  if(mm) mm.className = 'ftab' + (m==='mod'?' active':'');
  if(gm) gm.className = 'ftab' + (m==='grp'?' active':'');
  var st = document.getElementById('sortTabs');
  if(st) st.style.display = m==='mod' ? 'flex' : 'none';
  renderSortList();
}
function renderGroupSortInModal(){
  var el = document.getElementById('sortList');
  if(!el) return;
  var h = '';
  state.groups.forEach(function(g){
    var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
    h += '<div class="gsort-row" data-gid="'+g.id+'" style="display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--card-brd)">'
      + '<span ontouchstart="gsortTouchStart(event)" onmousedown="gsortMouseDown(event)" style="display:flex;align-items:center;cursor:grab;color:var(--text2);opacity:.5;touch-action:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="width:18px;height:18px"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></svg></span>'
      + '<span style="flex:1;font-size:15px">'+esc(g.name)+'</span>'
      + '<span style="font-size:12px;color:var(--text3)">'+n+' 个</span></div>';
  });
  el.innerHTML = h;
}
function renderSortList(){
  var el = document.getElementById('sortList');
  if (!el) return;
  if(_sortMode==='grp'){ renderGroupSortInModal(); return; }
  // 渲染 tab
  var tabs = document.getElementById('sortTabs');
  if(tabs){
    var h = '<div class="ftab'+(_sortGroup===''?' active':'')+'" onclick="setSortGroup(\'\')">全部<span class="cnt">'+state.modules.length+'</span></div>';
    state.groups.forEach(function(g){
      var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
      h += '<div class="ftab'+(_sortGroup===g.id?' active':'')+'" onclick="setSortGroup(\''+g.id+'\')">'+esc(g.name)+'<span class="cnt">'+n+'</span></div>';
    });
    tabs.innerHTML = h;
  }
  var h2 = '';
  function sortRow(m){
    return '<div class="sort-row" data-mid="'+m.id+'">'
      + '<span class="grip" ontouchstart="sortTouchStart(event)" onmousedown="sortMouseDown(event)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></svg></span>'
      + '<span class="sort-name">'+esc(m.title||m.filename)+'</span>'
      + (m.is_encrypted?'<span class="badge '+(m.source_url?'badge-green':'badge-orange')+'" style="flex-shrink:0">\u52a0\u5bc6</span>':'')
      + '</div>';
  }
  var list = state.modules.filter(function(m){
    if(_sortGroup && m.group_id!==_sortGroup) return false;
    return true;
  });
  list.forEach(function(m){ h2 += sortRow(m); });
  if(!list.length) h2 = '<div style="text-align:center;color:var(--text3);padding:30px;font-size:13px">该分组暂无模块</div>';
  el.innerHTML = h2;
}
function setSortGroup(id){ _sortGroup = id; renderSortList(); }
function sortDragInit(e, isTouch){
  var clientY = isTouch ? e.touches[0].clientY : e.clientY;
  var grip = e.currentTarget;
  var row = grip.closest('.sort-row');
  var list = document.getElementById('sortList');
  _sortDrag = { mid: row.dataset.mid, startY: clientY, row: row, list: list,
    rows: Array.prototype.slice.call(list.querySelectorAll('.sort-row')),
    moved: false, isTouch: isTouch };
  if (isTouch) {
    document.addEventListener('touchmove', sortTouchMove, {passive:false});
    document.addEventListener('touchend', sortTouchEnd);
    document.addEventListener('touchcancel', sortTouchEnd);
  } else {
    document.addEventListener('mousemove', sortMouseMove);
    document.addEventListener('mouseup', sortMouseUp);
  }
}
function sortMouseDown(e){ e.preventDefault(); sortDragInit(e, false); }
function sortTouchStart(e){ if(e.touches.length!==1) return; e.preventDefault(); sortDragInit(e, true); }
function sortDragMove(clientY){
  var d = _sortDrag; if (!d) return;
  var dy = clientY - d.startY;
  if (!d.moved && Math.abs(dy) < 6) return;
  if (!d.moved) {
    d.moved = true;
    d.row.style.position = 'relative'; d.row.style.zIndex = '50';
    d.row.style.background = 'var(--bg)';
    d.row.style.boxShadow = '0 4px 16px rgba(0,0,0,.18)';
    d.row.style.borderRadius = '10px';
  }
  d.row.style.transform = 'translateY('+dy+'px)';
  var others = d.rows.filter(function(r){ return r !== d.row; });
  var rh = d.row.offsetHeight, curTop = d.row.offsetTop + dy, ti = 0;
  for (var i=0;i<others.length;i++){
    if (curTop + rh/2 > others[i].offsetTop + others[i].offsetHeight/2) ti = i+1;
  }
  d.targetIdx = ti;
  others.forEach(function(r){ r.classList.remove('drop-hint'); });
  if (others[ti]) others[ti].classList.add('drop-hint');
}
function sortMouseMove(e){ sortDragMove(e.clientY); }
function sortTouchMove(e){
  if (!_sortDrag || !_sortDrag.isTouch || e.touches.length!==1) return;
  e.preventDefault();
  sortDragMove(e.touches[0].clientY);
}
function sortDragEnd(){
  var d = _sortDrag; _sortDrag = null;
  if (!d) return;
  document.removeEventListener('mousemove', sortMouseMove);
  document.removeEventListener('mouseup', sortMouseUp);
  document.removeEventListener('touchmove', sortTouchMove);
  document.removeEventListener('touchend', sortTouchEnd);
  document.removeEventListener('touchcancel', sortTouchEnd);
  d.row.style.cssText = '';
  d.list.querySelectorAll('.drop-hint').forEach(function(r){ r.classList.remove('drop-hint'); });
  if (!d.moved) return;
  var ms = state.modules;
  var from = ms.findIndex(function(m){ return String(m.id)===String(d.mid); });
  if (from < 0) return;
  var item = ms.splice(from,1)[0];
  // targetIdx 是「当前分组可见行」里的位置，不能直接当全局下标：先换算成全局位置
  var vis = ms.filter(function(m){ return !_sortGroup || m.group_id===_sortGroup; });
  var ti = Math.max(0, Math.min(d.targetIdx==null?vis.length:d.targetIdx, vis.length));
  var to;
  if (ti < vis.length) to = ms.indexOf(vis[ti]);
  else if (vis.length) to = ms.indexOf(vis[vis.length-1]) + 1;
  else to = ms.length;
  ms.splice(to,0,item);
  renderSortList();
  renderMods();
  _sortDirty = true;
}
function sortMouseUp(){ sortDragEnd(); }
function sortTouchEnd(){ sortDragEnd(); }
var _sortDirty = false;
async function saveSortOrder(){
  if(_sortMode==='grp'){
    var gids = state.groups.map(function(g){ return g.id; });
    try {
      var gr = await api('/api/admin/groups/reorder', {method:'POST', json:{ids:gids}});
      if(gr && gr.ok){ _sortDirty=false; toast('分组排序已保存'); closeSortModal(); }
      else toast('保存失败');
    } catch(e){ toast('保存异常'); }
    return;
  }
  var ids = state.modules.map(function(m){ return m.id; });
  try {
    var r = await api('/api/admin/modules/reorder', { method: 'POST', json: { ids: ids } });
    if (r && r.ok) {
      _sortDirty = false;
      toast('排序已保存');
      closeSortModal();
    } else {
      toast('保存失败: ' + JSON.stringify(r).slice(0,100));
    }
  } catch(e) {
    toast('保存异常: ' + String(e).slice(0,100));
  }
}
function showUploadMods(){
  var busy=false;
  showModal('上传模块',
    '<label>选择文件</label><input type="file" id="uploadFiles" multiple accept=".js,application/javascript,text/javascript" class="input" style="padding:8px">'+
    '<p style="font-size:12px;color:var(--text2);line-height:1.7">先预览，再确认上传。优先按模块 ID、其次完整文件名匹配；加密文件仅按文件名匹配。同名但 ID 不同或多个匹配将提示冲突。最多 45 个文件，总计 50 MB。</p>'+
    '<label>新增模块的分组（已有模块不移动）</label><select class="input" id="uploadGroup">'+groupOptions('')+'</select><p id="uploadStartStatus" style="font-size:12px;color:var(--text2)"></p>',
    async function(close){
      if(busy)return;
      var input = document.getElementById('uploadFiles');
      if(!input.files.length){ toast('请先选择文件'); return; }
      var gid = document.getElementById('uploadGroup').value;
      busy=true;var status=document.getElementById('uploadStartStatus');status.textContent='正在检查文件并匹配模块…';
      try{await beginUploadPreview(Array.from(input.files),gid,'',close);}
      catch(e){if(status.isConnected)status.textContent=e.message;toast(e.message);}
      finally{busy=false;}
    });
  document.querySelector('.modal-overlay:last-child #mC').textContent='检查并预览';
}

async function beginUploadPreview(files,gid,targetId,closePrevious){
  var fd=new FormData();files.forEach(function(f){fd.append('files',f);});
  if(gid)fd.append('group_id',gid);if(targetId)fd.append('target_id',targetId);
  var r=await api('/api/admin/modules/upload/preview',{method:'POST',body:fd,timeout:120000});
  if(!r||!r.ok)throw new Error(r?r.error:'检查失败');
  if(closePrevious)closePrevious();
  var labels={new:'新增',replace:'替换',identical:'内容相同，将跳过文件写入',conflict:'需要选择',invalid:'不可上传'};
  var h='<p style="font-size:12px;line-height:1.7;color:var(--text2)">替换会保留模块链接、合集引用、排序、分组和备注；上一版保留 7 天。提交前会再次校验，预览有效期 1 小时。旧模块没有内容指纹时，会在提交时检查并跳过相同内容。</p><div style="max-height:48vh;overflow:auto">';
  r.rows.forEach(function(row){
    h+='<div style="padding:12px 0;border-bottom:1px solid var(--card-brd)"><strong>'+esc(row.filename)+'</strong><p style="font-size:12px;color:var(--text2);line-height:1.7">'+esc(labels[row.kind])+(row.matched_by?' · '+esc(row.matched_by):'')+(row.target?'<br>目标：'+esc(row.target.title||row.target.filename):'')+(row.reason?'<br>'+esc(row.reason):'')+'</p>';
    var options='<option value="skip">跳过此文件</option>';
    if(row.kind!=='invalid'){
      if(row.kind==='new'||(row.kind==='conflict'&&!row.candidates.length&&!row.target))options+='<option value="new" '+(row.kind==='new'?'selected':'')+'>新增模块</option>';
      var candidates=row.candidates.slice();if(row.target&&!candidates.some(function(c){return c.id===row.target.id;}))candidates.push(row.target);
      candidates.forEach(function(c){options+='<option value="replace:'+esc(c.id)+'" '+((row.kind==='replace'||row.kind==='identical')&&row.target&&c.id===row.target.id?'selected':'')+'>替换：'+esc(c.title||c.filename)+' · '+esc(c.id.slice(0,8))+'</option>';});
    }
    h+='<select class="input" id="uploadChoice-'+row.index+'" '+(row.kind==='invalid'?'disabled':'')+'>'+options+'</select>';
    if(row.kind!=='invalid')h+='<label>导入后的文件名（可修改）</label><input class="input" id="uploadFilename-'+row.index+'" value="'+esc(row.effective_filename)+'" maxlength="153"><p style="font-size:12px;color:var(--text2)">原始名称保留用于匹配更新；同名模块自动加编号，不会合并。</p>';
    if((row.target&&row.target.subscribed)||row.candidates.some(function(c){return c.subscribed;})){
      h+='<p style="font-size:12px;color:#b76a21;line-height:1.7">该目标有自动更新来源。临时替换可能被下一次同步覆盖；手动维护只暂停此模块，不影响整个订阅。之后可在模块菜单恢复自动更新。</p><select class="input" id="uploadMode-'+row.index+'"><option value="">请选择更新方式</option><option value="temporary">临时替换，继续自动更新</option><option value="manual" '+(row.target&&row.target.manual?'selected':'')+'>转为手动维护，不再自动覆盖</option></select>';
    }
    h+='<p id="uploadResult-'+row.index+'" style="font-size:12px;white-space:pre-wrap"></p></div>';
  });
  h+='</div><p id="uploadBatchStatus" style="font-size:12px;color:var(--text2)"></p>';
  h+='<p class="batch-progress">显示逐文件进度。请勿关闭页面；成功项目会保留，未完成项需重新检查后继续。</p>';
  var busy=false,completed={},renew=false;
  showModal('上传预览',h,async function(close){
    if(busy)return;
    if(renew){
      busy=true;var remaining=files.filter(function(_,index){return !completed[index];});
      overlay.querySelector('#mC').disabled=true;overlay.querySelector('#mc').disabled=true;
      try{await beginUploadPreview(remaining,gid,targetId,close);}catch(e){toast(e.message);}finally{busy=false;if(overlay.isConnected){overlay.querySelector('#mC').disabled=false;overlay.querySelector('#mc').disabled=false;}}return;
    }
    if(r.rows.every(function(row){return completed[row.index];})){close();return;}
    var actions=[];
    for(var row of r.rows){
      if(completed[row.index])continue;
      var value=document.getElementById('uploadChoice-'+row.index).value;
      var modeEl=document.getElementById('uploadMode-'+row.index),mode=modeEl?modeEl.value:'';
      var selected=value.indexOf('replace:')===0?value.slice(8):'';
      var target=[row.target].concat(row.candidates).filter(Boolean).find(function(c){return c.id===selected;});
      if(target&&target.subscribed&&!mode){toast('请为 '+row.filename+' 选择更新方式');return;}
      var nameEl=document.getElementById('uploadFilename-'+row.index);
      actions.push({row:row,action:selected?'replace':value,target:selected,mode:mode,filename:nameEl?nameEl.value.trim():''});
    }
    var duplicate={};
    for(var a of actions){if(a.target){if(duplicate[a.target]){toast('多个文件选择了同一个目标，请只保留一个');return;}duplicate[a.target]=true;}}
    busy=true;var button=overlay.querySelector('#mC');button.disabled=true;overlay.querySelector('#mc').disabled=true;
    overlay.querySelectorAll('select,input').forEach(function(el){el.disabled=true;});
    var counts={added:0,replaced:0,unchanged:0,skipped:0,failed:0};
    try{
      for(var a of actions){
        var line=document.getElementById('uploadResult-'+a.row.index);
        document.getElementById('uploadBatchStatus').textContent='正在处理 '+(actions.indexOf(a)+1)+' / '+actions.length+'：'+a.row.filename;
        line.style.color='';
        if(a.action==='skip'){line.textContent='已跳过';completed[a.row.index]=true;counts.skipped++;continue;}
        line.textContent='正在提交…';
        try{
          var body=new FormData();body.append('job_id',r.job_id);body.append('index',a.row.index);body.append('action',a.action);
          body.append('target_id',a.target);body.append('mode',a.mode);body.append('file',files[a.row.index]);
          body.append('filename',a.filename);
          var result=await api('/api/admin/modules/upload/commit',{method:'POST',body:body,timeout:120000});
          if(!result||!result.ok)throw new Error(result?result.error:'请求失败，可重试；已完成项目不会重复写入');
          counts[result.status]=(counts[result.status]||0)+1;completed[a.row.index]=true;
          line.textContent=({added:'已新增',replaced:'已替换，可从模块菜单恢复上一版',unchanged:'内容相同，已跳过文件写入'})[result.status]||result.status;
          if(result.effective_filename){line.textContent+=' · 文件名：'+result.effective_filename;document.getElementById('uploadFilename-'+a.row.index).value=result.effective_filename;}
        }catch(e){counts.failed++;line.textContent='失败：'+e.message;line.style.color='#dc6b42';
          if(/过期|预览后|刚刚|重新预览|已有匹配|文件已变更|目标.*不存在/.test(e.message))renew=true;
        }
      }
      var msg='新增 '+counts.added+' · 替换 '+counts.replaced+' · 未变化 '+counts.unchanged+' · 跳过 '+counts.skipped+' · 失败 '+counts.failed;
      document.getElementById('uploadBatchStatus').textContent='本轮：'+msg+'。已完成 '+Object.keys(completed).length+' / '+r.rows.length;toast(msg);await loadAll();
      button.textContent=counts.failed?(renew?'重新检查未完成项目':'仅重试失败项目'):'完成';
    }finally{busy=false;button.disabled=false;overlay.querySelector('#mc').disabled=false;
      r.rows.forEach(function(row){var choice=overlay.querySelector('#uploadChoice-'+row.index),mode=overlay.querySelector('#uploadMode-'+row.index),name=overlay.querySelector('#uploadFilename-'+row.index);choice.disabled=!!completed[row.index]||row.kind==='invalid';if(mode)mode.disabled=!!completed[row.index];if(name)name.disabled=!!completed[row.index];});
    }
  });
  var overlay=document.querySelector('.modal-overlay:last-child');overlay.querySelector('#mC').textContent='确认上传';
  r.rows.forEach(function(row){var choice=overlay.querySelector('#uploadChoice-'+row.index);choice.addEventListener('change',function(){var id=choice.value.indexOf('replace:')===0?choice.value.slice(8):'',target=[row.target].concat(row.candidates).filter(Boolean).find(function(c){return c.id===id;}),input=overlay.querySelector('#uploadFilename-'+row.index);if(input)input.value=target?(target.effective_filename||target.filename):row.effective_filename;});});
  overlay.addEventListener('click',function(e){if(busy&&e.target===overlay){e.stopImmediatePropagation();e.preventDefault();}},true);
}

async function showPreviousVersion(id){
  try{
    var r=await api('/api/admin/modules/'+id+'/previous-version');
    if(!r||!r.ok)throw new Error(r?r.error:'读取备份失败');
    if(!r.previous){toast('暂无可恢复的上一版，上传替换后会保留 7 天');return;}
    var p=r.previous,m=p.metadata;
    showModal('恢复上一版','<p style="font-size:13px;line-height:1.8">文件：'+esc(m.filename)+'<br>版本：'+esc(m.version||'未知')+'<br>备份时间：'+esc(new Date(p.created_at).toLocaleString())+'<br>有效期至：'+esc(new Date(p.expires_at).toLocaleString())+'<br>恢复不改变合集、备注或更新方式。如果仍开启自动更新，后续可能再次被上游覆盖。</p>',async function(close){
      try{var res=await api('/api/admin/modules/'+id+'/previous-version',{method:'POST',json:{created_at:p.created_at}});if(!res||!res.ok)throw new Error(res?res.error:'恢复失败');close();toast('已恢复上一版，当前版本也已备份');await loadAll();}catch(e){toast(e.message);}
    });
  }catch(e){toast(e.message);}
}
async function setModuleMaintenance(id,manual){
  showConfirm(manual?'将此模块转为手动维护？只停止此模块的自动更新。':'恢复此模块的自动更新？手动版本可能被上游覆盖。',async function(ok){
    if(!ok)return;
    try{var r=await api('/api/admin/modules/'+id+'/maintenance',{method:'PATCH',json:{manual:manual}});if(!r||!r.ok)throw new Error(r?r.error:'操作失败');toast(manual?'已转为手动维护':'已恢复自动更新');await loadAll();}catch(e){toast(e.message);}
  });
}

function copyModLink(id){ var m=state.modules.find(function(m){return m.id===id;});copyText(org()+(m&&(m.share_path||m.public_path)||'/api/modules/'+id+'.js')); }

// ===== 源码在线编辑 =====
var ed = { id:null, filename:'', orig:'', dirty:false, saving:false, warn:'' };

async function openEditor(id){
  var m = state.modules.find(function(x){ return x.id===id; });
  if(!m) return;
  toast('正在加载源码…');
  try{
    var r = await fetch('/api/admin/modules/'+id+'/source', {credentials:'same-origin'});
    if(r.status===401){ state.isAuthed=false; showLogin(); return; }
    if(!r.ok){ var e=await r.json().catch(function(){return null;}); toast(e&&e.error?e.error:'读取失败'); return; }
    var d = await r.json();
    ed.id = id; ed.filename = d.filename || m.filename || 'module.js';
    ed.orig = d.content || ''; ed.dirty = false;
    document.getElementById('edTitle').textContent = m.title || m.filename || '模块';
    document.getElementById('edFilename').value = ed.filename;
    var ta = document.getElementById('edCode');
    ta.value = ed.orig;
    // 超大文件关掉行号，避免卡顿
    ed.gutterOff = (ed.orig.length > 120000);
    document.getElementById('edGutter').style.display = ed.gutterOff ? 'none' : 'block';
    document.getElementById('editorOverlay').style.display = 'flex';
    edSyncState(); updateGutter(); scrollGutter();
    ta.focus();
  }catch(err){ toast('读取失败：'+err.message); }
}

function closeEditor(force){
  if(ed.dirty && !force){
    showConfirm('源码还没保存，确定放弃修改？', function(ok){ if(ok) closeEditor(true); });
    return;
  }
  document.getElementById('editorOverlay').style.display='none';
  ed.dirty=false; ed.id=null; ed.orig='';
}

function edApplyWarn(){
  var warn = '';
  try{
    var meta = parseMetaFromText(ed.filename, document.getElementById('edCode').value);
    warn = meta._warn || '';
  }catch(e){}
  document.getElementById('edState').textContent = (ed.dirty?'未保存':'已保存') + (warn ? ' · '+warn : '');
}

function edSyncState(){
  var ta = document.getElementById('edCode');
  var len = ta.value.length;
  document.getElementById('edLines').textContent = (ta.value.split('\n').length) + ' 行';
  document.getElementById('edSize').textContent = fmt(len);
  var dot = document.getElementById('edDot');
  dot.className = 'ed-dot' + (ed.dirty?' dirty':'');
  edApplyWarn();
  var b = document.getElementById('edSaveBtn');
  b.textContent = ed.saving ? '⏳' : '💾';
}

function updateGutter(){
  if(ed.gutterOff) return;
  var ta = document.getElementById('edCode');
  var n = ta.value.split('\n').length;
  var g = document.getElementById('edGutter');
  if(g.childElementCount !== n){
    var html = '';
    for(var i=1;i<=n;i++) html += '<div>'+i+'</div>';
    g.innerHTML = html;
  }
  scrollGutter();
}

function scrollGutter(){
  if(ed.gutterOff) return;
  var ta = document.getElementById('edCode');
  document.getElementById('edGutter').scrollTop = ta.scrollTop;
}

// 编辑器即时提示；以服务端静态解析结果为准。
function parseMetaFromText(fn, text){
  var head = text.slice(0, 32768);
  var meta = {};
  var m = head.match(/\/\*[\s\S]*?WidgetMetadata\s*\{/) || head.match(/WidgetMetadata\s*=\s*\{/);
  if(!m) return meta;
  var depth = 1, i = m.index + m[0].length, start = i;
  while(i < head.length && depth > 0){
    if(head[i]==='{') depth++;
    else if(head[i]==='}') depth--;
    i++;
  }
  var body = head.slice(start, i-1);
  var pairs = body.match(/["']?(\w+)["']?\s*:\s*"([^"]*)"/g) || [];
  pairs.forEach(function(x){ var kv = x.match(/["']?(\w+)["']?\s*:\s*"([^"]*)"/); if(kv && !meta[kv[1]]) meta[kv[1]] = kv[2]; });
  if(!meta.id) meta._warn = '未解析到 WidgetMetadata.id';
  return meta;
}

async function saveEditor(){
  if(!ed.id || ed.saving) return;
  var code = document.getElementById('edCode').value;
  var name = document.getElementById('edFilename').value.trim() || ed.filename;
  if(!/\.js$/i.test(name)) { toast('文件名需要 .js 结尾'); return; }
  ed.saving = true; edSyncState();
  try{
    var fd = new FormData();
    fd.append('name', name);
    fd.append('code', code);
    var r = await fetch('/api/admin/modules/'+ed.id+'/source', {method:'PUT', body:fd, credentials:'same-origin'});
    var d = await r.json().catch(function(){ return null; });
    if(r.ok && d && d.ok){
      ed.orig = code; ed.filename = name; ed.dirty = false;
      toast('已保存');
      loadAll();
      // 同步模块池里的文件名/元信息
      var mx = state.modules.find(function(x){ return x.id===ed.id; });
      if(mx && d.module){ mx.filename = d.module.filename; mx.title = d.module.title; mx.version = d.module.version; }
    } else {
      toast(d && d.error ? d.error : '保存失败');
    }
  }catch(err){ toast('保存失败：'+err.message); }
  ed.saving = false; edSyncState();
}

var portalMenu = null, portalBtn = null, portalHome = null;
function placePortalMenu(){
  if(!portalMenu || !portalBtn) return;
  var br = portalBtn.getBoundingClientRect();
  var mw = portalMenu.offsetWidth, mh = portalMenu.offsetHeight;
  var left = br.right - mw;
  if(left < 8) left = 8;
  if(left + mw > window.innerWidth - 8) left = window.innerWidth - 8 - mw;
  var top;
  if(br.bottom + 8 + mh <= window.innerHeight - 8) top = br.bottom + 8;
  else top = br.top - 8 - mh;
  if(top < 8) top = 8;
  portalMenu.style.left = left + 'px';
  portalMenu.style.top = top + 'px';
  portalMenu.style.visibility = 'visible';
}
function toggleMenu(e, id) {
  e.stopPropagation();
  var d = document.getElementById('menu-' + id);
  var root = e.currentTarget.closest('.od-root');
  var wasOpen = root.classList.contains('open');
  closeAllRowMenus();
  closeGroupMenu();
  if (wasOpen) return;
  root.classList.add('open');
  portalMenu = d; portalBtn = e.currentTarget; portalHome = root;
  document.body.appendChild(d);
  d.classList.add('portal');
  d.style.display = 'block';
  d.style.visibility = 'hidden';
  placePortalMenu();
  window.addEventListener('scroll', placePortalMenu, true);
  window.addEventListener('resize', placePortalMenu);
}
function closeAllRowMenus(){
  document.querySelectorAll('.od-root.row-od.open').forEach(function(w){w.classList.remove('open');});
  if(portalMenu){
    portalMenu.classList.remove('portal');
    portalMenu.style.display = '';
    portalMenu.style.visibility = '';
    portalMenu.style.left = '';
    portalMenu.style.top = '';
    if(portalHome) portalHome.appendChild(portalMenu);
    portalMenu = null; portalBtn = null; portalHome = null;
    window.removeEventListener('scroll', placePortalMenu, true);
    window.removeEventListener('resize', placePortalMenu);
  }
}
document.addEventListener('click', function() {
  closeAllRowMenus();
  closeGroupMenu();
});
document.addEventListener('keydown', function(e) {
  if(e.key==='Escape'){ closeAllRowMenus(); closeGroupMenu(); }
});
function copyText(t){ navigator.clipboard.writeText(t).then(function(){ toast('已复制'); }).catch(function(){ toast('复制失败'); }); }

function promptReplace(id){ state.modReplaceId=id; document.getElementById('replaceFileInput').click(); }
async function refreshMod(id){ var r=await api('/api/admin/modules/'+id+'/refresh',{method:'POST'}); if(r&&r.ok){ toast('已刷新'); loadAll(); } else toast(r?r.error:'刷新失败'); }
function editMeta(id){
  var m = state.modules.find(function(x){ return x.id===id; });
  if(!m) return;
  showModal('编辑模块信息 — '+esc(m.title||m.filename),
    '<label>标题</label><input class="input" id="metaTitle" value="'+esc(m.title||'')+'">'+
    '<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="metaTitleLock" '+(m.title_locked?'checked':'')+'>锁定自定义标题，更新不覆盖</label>'+
    '<p style="font-size:12px;color:var(--text2);line-height:1.7">未锁定时：模块代码 title → 订阅清单标题 → 已保存标题 → 文件名。修改标题会自动勾选锁定。</p>'+
    '<label>版本</label><input class="input" id="metaVersion" value="'+esc(m.version||'')+'">'+
    '<label>作者</label><input class="input" id="metaAuthor" value="'+esc(m.author||'')+'">'+
    '<label>备注</label><textarea class="textarea" id="metaNote" rows="2">'+esc(m.note||'')+'</textarea>',
    async function(close){
      var title = document.getElementById('metaTitle').value.trim();
      var version = document.getElementById('metaVersion').value.trim();
      var author = document.getElementById('metaAuthor').value.trim();
      var note = document.getElementById('metaNote').value.trim();
      var locked=document.getElementById('metaTitleLock').checked;
      var r = await api('/api/admin/modules?id='+id, {method:'PATCH', json:{title:title,title_locked:locked, version:version, author:author, note:note}});
      if(r&&r.ok){toast('已保存');close();await loadAll();}else toast(r?r.error:'保存失败');
    });
  document.getElementById('metaTitle').addEventListener('input',function(){document.getElementById('metaTitleLock').checked=true;});
}
function showModuleInfo(id){
  var m=state.modules.find(function(x){return x.id===id;});if(!m)return;
  var fields=[['显示标题',m.title],['标题来源',m.title_source],['代码 title',m.code_title||'不可读取或未提供'],
    ['订阅清单标题',m.manifest_title||'无'],['原始文件名',m.filename],['对外文件名',m.effective_filename||m.filename],['本地编号',m.id],
    ['代码内部 ID',m.metadata_id||'未读取到（不从加密内容猜测）'],['合集提供的模块标识',m.widget_id],
    ['订阅来源',m.subscription_title||'无'],['源地址',m.source_url||'无']];
  var h='<div style="max-height:55vh;overflow:auto;overflow-wrap:anywhere">';
  fields.forEach(function(f){h+='<div style="padding:8px 0;border-bottom:1px solid var(--card-brd)"><div style="font-size:12px;color:var(--text2)">'+esc(f[0])+'</div><div style="margin-top:3px;font-size:13px">'+esc(String(f[1]||''))+'</div></div>';});
  h+='<button class="btn btn-sm" style="margin-top:14px" onclick="copyModLink(\''+id+'\')">复制模块链接</button></div>';
  showModal('模块信息',h,function(close){close();});
}
async function doReplaceMod(input){
  var id=state.modReplaceId; state.modReplaceId=null;
  if(!input.files.length) return;
  try{await beginUploadPreview([input.files[0]],'',id);}catch(e){toast(e.message);}
  input.value='';
}

function groupOptions(sel){
  var h = '<option value="">全部</option>';
  state.groups.forEach(function(g){
    h += '<option value="'+g.id+'"'+(sel===g.id?' selected':'')+'>'+esc(g.name)+'</option>';
  });
  return h;
}
function showImportUrl(){
  var busy=false;
  showModal('从链接导入模块 / 订阅合集',
    '<label>模块或合集 URL</label><input class="input" id="importUrl" placeholder="https://.../collection.rex 或 widget.js">'+
    '<p style="font-size:12px;color:var(--text2);line-height:1.7">自动识别合集，展开模块并每 6 小时同步。已有模块不重复导入；上游新增模块只进入模块库，除非你的合集启用了“自动包含全部模块”。</p>'+
    '<label>文件名（仅单个模块，可选）</label><input class="input" id="importFilename" placeholder="自动从 URL 提取">'+
    '<label>导入后的文件名（单模块，可修改）</label><input class="input" id="importEffectiveFilename" placeholder="填写 URL 后预览"><p class="icon-help" id="importNamePreview">合集内模块按同一清理规则自动命名。</p>'+
    '<label>新模块分组（已存在模块不移动）</label><select class="input" id="importGroup">'+groupOptions('')+'</select><p id="importProgress" style="font-size:12px;color:var(--text2)"></p>',
    async function(close){
      if(busy) return;
      var url = document.getElementById('importUrl').value.trim();
      if(!url){ toast('请输入 URL'); return; }
      var filename = document.getElementById('importFilename').value.trim();
      var gid = document.getElementById('importGroup').value;
      busy=true;
      var progress=document.getElementById('importProgress'); progress.textContent='正在读取链接…';
      try{
        var identified=await api('/api/admin/subscriptions/preview',{method:'POST',json:{url:url}});
        if(!identified||identified.error)throw Error(identified?identified.error:'链接识别失败');
        var used=document.getElementById('importEffectiveFilename'),effective=used.dataset.edited==='true'?used.value.trim():'';
        var choice=null;
        if(identified.duplicates&&identified.duplicates.length){
          choice=await showDuplicateChoice(identified.duplicates);
          if(!choice){progress.textContent='已取消';return;}
        }
        var payload={url:url, preview_id:identified.preview_id, filename:filename, effective_filename:effective, group_id:gid};
        if(choice){payload.duplicate_action=choice.action;if(choice.action==='replace')payload.replace_id=choice.id;}
        var r = await api('/api/admin/modules/import', {method:'POST', timeout:120000, json:payload});
        if(!r||!r.ok) throw new Error(r?r.error:'导入失败');
        close();
        if(r.replaced){ toast('已覆盖原模块'); await loadAll(); }
        else if(r.subscription){ state.tab='subscriptions'; await loadAll(); await syncSource(r.subscription.id); }
        else { toast('已导入'); await loadAll(); }
      }catch(e){ if(progress.isConnected)progress.textContent=e.message; toast(e.message); }
      finally{busy=false;}
    });
  var overlay=document.querySelector('.modal-overlay:last-child'),stamp=0,used=overlay.querySelector('#importEffectiveFilename');
  used.oninput=function(){used.dataset.edited='true';};
  var previewName=debounce(async function(){var n=++stamp,raw=overlay.querySelector('#importUrl').value.trim(),status=overlay.querySelector('#importNamePreview');if(!raw)return;
    try{var r=await api('/api/admin/subscriptions/preview',{method:'POST',json:{url:raw}});if(n!==stamp||!overlay.isConnected)return;if(!r||r.error)throw Error(r?r.error:'预览失败');if(used.dataset.edited!=='true'&&r.kind==='module')used.value=r.filename||'';status.textContent=r.kind==='collection'?'识别为合集 · '+r.total+' 个模块 · '+r.title:'识别为单模块 · '+r.title+(r.existing_module?' · 将更新已有模块':'');}catch(e){if(n===stamp)status.textContent=e.message;}},500);
  overlay.querySelector('#importUrl').addEventListener('input',previewName);overlay.querySelector('#importFilename').addEventListener('input',previewName);
}

var sourceSyncing={};
function sourceTime(t){ return t ? new Date(t).toLocaleString() : '尚未同步'; }
function renderSubscriptions(){
  var labels={idle:'待同步',syncing:'同步中',ok:'同步成功',partial:'部分失败',error:'同步失败'};
  document.getElementById('sourceCount').textContent='共 '+state.subscriptions.length+' 个订阅源';
  var h='';
  state.subscriptions.forEach(function(s){
    var sum=s.summary||{},busy=sourceSyncing[s.id];
    h+='<div class="card" style="padding:18px;overflow-wrap:anywhere"><div style="display:flex;justify-content:space-between;gap:8px"><strong>'+esc(s.title)+'</strong><span style="font-size:12px;color:var(--text2)">'+(s.kind==='module'?'单模块订阅 · ':'合集订阅 · ')+(!s.enabled?'已暂停':(labels[s.status]||s.status))+'</span></div>'+
      '<div style="font-size:12px;color:var(--text2);margin:8px 0">'+esc(s.url)+'</div>'+
      '<div style="font-size:13px;line-height:1.8">已导入 '+s.imported+' / '+s.total+' 个 · 上游下架 '+s.removed+' 个<br>上次完成：'+esc(sourceTime(s.last_finished_at))+'<br>最近一轮：新增 '+(sum.added||0)+' · 更新 '+(sum.updated||0)+' · 未变化 '+(sum.unchanged||0)+' · 手动保留 '+(sum.manual||0)+' · 失败 '+(sum.failed||0)+'</div>'+
      (s.last_error?'<p style="color:#dc6b42;font-size:12px">'+esc(s.last_error)+'</p>':'')+
      '<p style="font-size:12px;color:var(--text2)" id="syncProgress-'+s.id+'">'+(busy?'正在同步…':s.status==='syncing'?'分批处理中，可点击继续同步；关闭页面后后台仍会继续':s.enabled?'下次检查：'+esc(sourceTime(s.next_sync_at)):'已暂停自动更新')+'</p>'+
      '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-sm" onclick="showSourceItems(\''+s.id+'\')">查看模块</button><button class="btn btn-sm" onclick="editSubscription(\''+s.id+'\')">编辑</button>'+
      '<button class="btn btn-sm" '+(!s.enabled||busy?'disabled':'')+' onclick="syncSource(\''+s.id+'\')">'+(busy?'同步中…':s.status==='syncing'?'继续同步':'立即同步')+'</button>'+
      '<button class="btn btn-sm" onclick="toggleSource(\''+s.id+'\','+(!s.enabled?1:0)+')">'+(s.enabled?'暂停':'恢复')+'</button>'+
      '<button class="btn btn-sm" onclick="removeSource(\''+s.id+'\')">取消订阅</button></div></div>';
  });
  document.getElementById('subscriptionsList').innerHTML='<button class="btn btn-sm" style="margin-bottom:12px" onclick="migrateLegacySources()">整理已有单链接来源</button>'+(h||'<div class="empty"><p>暂无订阅源，可添加合集或单模块链接</p></div>');
}
async function syncSource(id){
  if(sourceSyncing[id]) return;
  sourceSyncing[id]=true; renderSubscriptions();
  try{
    var done=false;
    while(!done){
      var r=await api('/api/admin/subscriptions/'+id+'/sync',{method:'POST',timeout:120000,json:{}});
      if(!r||!r.ok) throw new Error(r?r.error:'同步连接失败，后台稍后会继续');
      done=r.done;
      var p=document.getElementById('syncProgress-'+id); if(p)p.textContent='已处理 '+r.processed+' / '+r.total+' 个模块';
    }
    toast(r.summary&&r.summary.failed?'同步完成，部分失败，请查看详情':'订阅同步完成');
  }catch(e){toast(e.message);}
  finally{delete sourceSyncing[id]; await loadAll();}
}
async function retrySource(id){
  if(sourceSyncing[id]) return;
  sourceSyncing[id]=true; renderSubscriptions();
  try{
    var after='',r,fixed=0,left=0;
    do{
      r=await api('/api/admin/subscriptions/'+id+'/retry',{method:'POST',timeout:120000,json:{after:after}});
      if(!r||!r.ok) throw new Error(r?r.error:'重试连接失败，请稍后再试');
      left=r.remaining; after=r.next||'';
      var p=document.getElementById('syncProgress-'+id); if(p)p.textContent='仍失败 '+left+' 个模块';
    }while(after);
    toast(left?'重试完成，仍有 '+left+' 个失败':'失败的模块已全部重试成功');
  }catch(e){toast(e.message);}
  finally{delete sourceSyncing[id]; await loadAll();}
}
async function toggleSource(id,enabled){
  try{var r=await api('/api/admin/subscriptions/'+id,{method:'PATCH',json:{enabled:enabled}}); if(!r||!r.ok)throw new Error(r?r.error:'操作失败'); await loadAll();}catch(e){toast(e.message);}
}
function removeSource(id){
  showConfirm('取消订阅？模块、分享链接和个人合集都会保留，只停止此来源的更新；其他启用的来源仍可能更新同一模块。',async function(ok){
    if(!ok)return;
    try{var r=await api('/api/admin/subscriptions/'+id,{method:'DELETE'}); if(!r||!r.ok)throw new Error(r?r.error:'操作失败'); await loadAll();}catch(e){toast(e.message);}
  });
}
async function showSourceItems(id){
  try{
    var rows=await api('/api/admin/subscriptions/'+id+'/items'); if(!Array.isArray(rows))throw new Error('加载失败');
    var h='<p style="font-size:12px;color:var(--text2)">已导入模块可在“合集 → 管理模块”中加入自己的合集。下架模块及旧版本均保留。</p><div style="max-height:55vh;overflow:auto">';
    rows.forEach(function(i){h+='<div style="padding:10px 0;border-bottom:1px solid var(--card-brd)"><strong>'+esc(i.local_title||i.title||i.remote_id)+'</strong><div style="font-size:12px;color:var(--text2);line-height:1.8">'+(!i.active?'上游已下架':i.module_id?'已导入 · '+esc(i.local_version||i.version||''):'未导入')+(i.last_error?'<br><span style="color:#dc6b42">'+esc(i.last_error)+'</span>':'')+'</div></div>';});
    showModal('订阅模块',h+'</div>',function(close){close();});
  }catch(e){toast(e.message);}
}

function promptDeleteMod(id, name){
  showConfirm('确定删除 "'+name+'"？', function(ok){
    if (!ok) return;
    api('/api/admin/modules?id='+id,{method:'DELETE'}).then(function(r){
      if(r&&r.ok){ toast('已删除'); loadAll(); } else toast('删除失败');
    });
  });
}

// ===== COLLECTIONS =====
function renderCols(){
  var cs = state.collections;
  document.getElementById('colCount').textContent='共 '+cs.length+' 个合集';
  if(!cs.length){ document.getElementById('collectionsList').innerHTML='<div class="empty"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2v11z"/></svg></div><p>暂无合集</p></div>'; return; }
  var h='';
  cs.forEach(function(c){
    var n = (c.moduleIds||[]).length;
    h+='<div class="card" style="padding-bottom:12px"><div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px"><div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0">';
    if(c.icon_url) h+='<img src="'+esc(c.icon_url)+'" style="width:40px;height:40px;border-radius:12px;object-fit:cover" onerror="this.remove()">';
    h+='<div style="min-width:0"><div style="font-size:16px;font-weight:600">'+esc(c.title)+'</div><div style="font-size:12px;color:var(--text2);margin-top:3px">'+n+' 个模块'+(c.description?' · '+esc(c.description):'')+'</div></div></div>'+
      '<div style="display:flex;gap:2px"><button class="btn-xs" onclick="copyText(\''+org()+'/api/collections/'+encodeURIComponent(c.slug)+'.rex\')" title="复制订阅链接"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg></button><button class="btn-xs" onclick="showEditCol(\''+c.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button><button class="btn-xs danger" onclick="promptDeleteCol(\''+c.id+'\',\''+escJs(c.title)+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg></button></div></div>'+
      '<div style="margin-top:10px"><button class="btn btn-ghost btn-sm" onclick="showPickMods(\''+c.id+'\')">+ 添加模块</button></div></div>';
  });
  document.getElementById('collectionsList').innerHTML=h;
}
function showAddCol(){
  showModal('新建合集',
    '<div style="display:flex;gap:10px"><div style="flex:1"><label>标题</label><input class="input" id="colTitle" placeholder="合集名称"></div>'+
    '<div style="flex:1"><label>路径</label><input class="input" id="colSlug" placeholder="mysub"></div></div>'+
    '<label>描述</label><input class="input" id="colDesc" placeholder="可选">'+
    '<label>图标 URL</label><input class="input" id="colIcon" placeholder="可选，https://...">',
    function(close){
      var slug=document.getElementById('colSlug').value.trim();
      var title=document.getElementById('colTitle').value.trim();
      if(!/^[A-Za-z0-9]+$/.test(slug)){ toast('路径只能填英文字母和数字'); return; }
      if(!title){ toast('请输入标题'); return; }
      api('/api/admin/collections',{method:'POST',json:{slug:slug,title:title,description:document.getElementById('colDesc').value.trim(),icon_url:document.getElementById('colIcon').value.trim()}}).then(function(r){
        if(r&&r.ok){ toast('合集已创建'); close(); loadAll(); } else toast('创建失败：'+((r&&r.error)||''));
      });
    });
}

function showEditCol(id){
  var col = state.collections.find(function(c){ return c.id===id; });
  if(!col) return;
  showModal('编辑合集',
    '<div style="display:flex;gap:10px"><div style="flex:1"><label>标题</label><input class="input" id="colTitle" value="'+esc(col.title)+'"></div>'+
    '<div style="flex:1"><label>路径</label><input class="input" id="colSlug" value="'+esc(col.slug)+'"></div></div>'+
    '<label>描述</label><input class="input" id="colDesc" value="'+esc(col.description||'')+'">'+
    '<label>图标 URL</label><input class="input" id="colIcon" value="'+esc(col.icon_url||'')+'">',
    function(close){
      var slug=document.getElementById('colSlug').value.trim();
      var title=document.getElementById('colTitle').value.trim();
      if(!/^[A-Za-z0-9]+$/.test(slug)){ toast('路径只能填英文字母和数字'); return; }
      if(!title){ toast('请输入标题'); return; }
      api('/api/admin/collections',{method:'PATCH',json:{id:id,slug:slug,title:title,description:document.getElementById('colDesc').value.trim(),icon_url:document.getElementById('colIcon').value.trim()}}).then(function(r){
        if(r&&r.ok){ toast('已更新'); close(); loadAll(); } else toast('更新失败：'+((r&&r.error)||''));
      });
    });
}

function showPickMods(colId){
  var col = state.collections.find(function(c){ return c.id===colId; });
  if(!col) return;
  if(!state.modules.length){ toast('请先上传模块'); return; }
  var modIds = col.moduleIds || [];
  var pickTab = '', pickQ = '';

  function pickRow(m){
    var ck = modIds.indexOf(m.id)>=0 ? ' checked' : '';
    var encBadge = m.is_encrypted ? '<span class="badge '+(m.source_url?'badge-green':'badge-orange')+'" style="flex-shrink:0">加密</span>' : '';
    return '<div class="pick-item'+ck+'" data-mid="'+m.id+'" onclick="window._pickToggle(this)"><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(m.title||m.filename)+'</span>'+encBadge+'<span style="font-size:11px;color:var(--text3);flex-shrink:0">'+fmt(m.file_size)+'</span></div>';
  }
  function filteredList(){
    return state.modules.filter(function(m){
      if(pickTab && m.group_id!==pickTab) return false;
      if(pickQ && ((m.title||'')+' '+(m.filename||'')).toLowerCase().indexOf(pickQ)<0) return false;
      return true;
    });
  }
  function renderPickBody(){
    var listEl = document.getElementById('pickModList');
    if(!listEl) return;
    var list = filteredList(), h = '';
    // 全部平铺，tab 已经负责分组过滤
    list.forEach(function(m){ h += pickRow(m); });
    if(!list.length) h = '<div style="text-align:center;color:var(--text3);padding:30px;font-size:13px">没有匹配的模块</div>';
    listEl.innerHTML = h;
    // 恢复已选状态（切换 tab/搜索后）
    var cur = {};
    (col._pickSel || modIds).forEach(function(id){ cur[id]=1; });
    listEl.querySelectorAll('.pick-item').forEach(function(el){
      if(cur[el.dataset.mid]) el.classList.add('checked');
    });
    updatePickCount();
  }
  function renderPickTabs(){
    var tabs = document.getElementById('pickModTabs');
    if(!tabs) return;
    var h = '<div class="ftab'+(pickTab===''?' active':'')+'" data-ptab="" style="font-size:12px;padding:7px 12px">全部<span class="cnt">'+state.modules.length+'</span></div>';
    state.groups.forEach(function(g){
      var n = state.modules.filter(function(m){return m.group_id===g.id}).length;
      h += '<div class="ftab'+(pickTab===g.id?' active':'')+'" data-ptab="'+g.id+'" style="font-size:12px;padding:7px 12px">'+esc(g.name)+'<span class="cnt">'+n+'</span></div>';
    });
    tabs.innerHTML = h;
    tabs.querySelectorAll('.ftab').forEach(function(t){
      t.onclick = function(){ pickTab = t.dataset.ptab; renderPickTabs(); renderPickBody(); toggleSelectAllBtn(); };
    });
  }
  function toggleSelectAllBtn(){
    var el = document.getElementById('pickSelectAllRow');
    if(el) el.style.display = pickTab ? 'flex' : 'none';
  }
  function updatePickCount(){
    var n = (col._pickSel || []).length;
    var e = document.getElementById('pickSelCount');
    if(e) e.textContent = n;
  }
  function syncSel(){
    var sel = [];
    document.querySelectorAll('#pickModList .pick-item.checked').forEach(function(el){ sel.push(el.dataset.mid); });
    // 合并：保留不在当前列表中的已选项
    var visible = {};
    filteredList().forEach(function(m){ visible[m.id]=1; });
    var keep = (col._pickSel||[]).filter(function(id){ return !visible[id]; });
    col._pickSel = keep.concat(sel.filter(function(id){ return keep.indexOf(id)<0; }));
    updatePickCount();
  }
  window._pickSearch = function(v){ syncSel(); pickQ = (v||'').toLowerCase().trim(); renderPickBody(); };
  window._pickSelectAll = function(sel){
    var listEl = document.getElementById('pickModList');
    if(!listEl) return;
    listEl.querySelectorAll('.pick-item').forEach(function(el){ el.classList.toggle('checked', sel); });
    syncSel(); renderPickBody();
  };
  window._pickToggle = function(el){ el.classList.toggle('checked'); syncSel(); };

  var body = ''
    + '<span class="ios-search" style="width:100%;margin:8px 0 10px"><svg class="ios-search-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg><input class="ios-search-input" id="pickModSearch" type="text" placeholder="Search…" oninput="onPickSearch(this)"><button class="ios-search-x" id="pickSearchX" onclick="clearPickSearch()" aria-label="清除搜索"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></span>'
    + '<div id="pickModTabs" class="folder-tabs" style="padding:0 0 10px"></div>'
    + '<div id="pickSelectAllRow" style="display:none;margin-bottom:8px;align-items:center">'
    + '<span style="font-size:12px;color:var(--text2)">已选 <b id="pickSelCount">0</b> 个</span><span style="flex:1"></span>'
    + '<button onclick="window._pickSelectAll(true)" style="background:none;border:none;color:var(--accent);font-size:12.5px;font-weight:600;cursor:pointer;padding:6px 8px;font-family:inherit">全选本组</button>'
    + '<button onclick="window._pickSelectAll(false)" style="background:none;border:none;color:var(--text2);font-size:12.5px;font-weight:600;cursor:pointer;padding:6px 8px;font-family:inherit">全不选</button></div>'
    + '<div class="pick-list" id="pickModList" style="max-height:40vh;overflow-y:auto"></div>';
  col._pickSel = modIds.slice();
  showModal('挑选模块 — '+esc(col.title), body, function(close){
    syncSel();
    var ids = col._pickSel;
    api('/api/admin/collections',{method:'PATCH',json:{id:colId,moduleIds:ids}}).then(function(r){
      col._pickSel = null;
      if(r&&r.ok){ col.moduleIds = ids; toast('已更新'); close(); loadAll(); } else toast('更新失败');
    });
  });
  renderPickTabs(); renderPickBody(); toggleSelectAllBtn(); updatePickCount();
}


function promptDeleteCol(id, name){
  showConfirm('确定删除合集 "'+name+'"？（模块文件不受影响）', function(ok){
    if (!ok) return;
    api('/api/admin/collections?id='+id,{method:'DELETE'}).then(function(r){
      if(r&&r.ok){ toast('已删除'); loadAll(); } else toast('删除失败');
    });
  });
}

// ===== SETTINGS =====
function renderSettings(){var tm=0,ts=0;state.modules.forEach(function(m){tm++;ts+=m.file_size||0;});
  document.getElementById('statCols').textContent=state.collections.length;
  document.getElementById('statMods').textContent=tm;
  document.getElementById('statSize').textContent=fmt(ts);
}

function getThemePref(){try{return localStorage.getItem('fwh_theme')||'auto';}catch(e){return 'auto';}}
function sysIsDark(){try{return window.matchMedia&&matchMedia('(prefers-color-scheme:dark)').matches;}catch(e){return false;}}
function applyThemeClass(){var pref=getThemePref(),root=document.documentElement;root.classList.remove('dark');root.classList.remove('light');if(pref==='dark')root.classList.add('dark');else if(pref==='light')root.classList.add('light');else if(sysIsDark())root.classList.add('dark');}
function toggleTheme(){var pref=getThemePref();var next=pref==='dark'?'light':(pref==='light'?'auto':'dark');try{localStorage.setItem('fwh_theme',next);}catch(e){}applyThemeClass();updateThemeIcon();}
function updateThemeIcon(){var btn=document.getElementById('btnThemeToggle');if(!btn)return;var pref=getThemePref();btn.textContent=pref==='dark'?'\u{1F319}':(pref==='light'?'\u2600\uFE0F':'\u{1F313}');}
try{var _mq=window.matchMedia?matchMedia('(prefers-color-scheme:dark)'):null;if(_mq){var _onSys=function(){if(getThemePref()==='auto'){applyThemeClass();updateThemeIcon();}};if(_mq.addEventListener)_mq.addEventListener('change',_onSys);else if(_mq.addListener)_mq.addListener(_onSys);}}catch(e){}

function exportData(){
  showPrompt('导出备份', 'fwh-backup-' + new Date().toISOString().slice(0,10), function(filename) {
    if (!filename) return;
    function doExport() {
      var combined = { meta: { modules: state.modules, collections: state.collections, exportedAt: new Date().toISOString() }, files: {} };
      var queue = state.modules.slice();
      var CONC = 6;
      function worker() {
        var m = queue.shift();
        if (!m) return Promise.resolve();
        return fetch(org() + '/api/modules/' + m.id).then(function(r) { return r.text(); }).then(function(code) {
          combined.files[m.id] = { filename: m.filename, content: code };
        }).catch(function() {
          combined.files[m.id] = { filename: m.filename, error: 'download failed' };
        }).then(worker);
      }
      var workers = [];
      for (var i = 0; i < Math.min(CONC, queue.length); i++) workers.push(worker());
      Promise.all(workers).then(function() {
        var blob = new Blob([JSON.stringify(combined, null, 2)], {type:'application/json'});
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename + '.json';
        a.click();
        toast('已导出 ' + Object.keys(combined.files).length + ' 个模块');
      });
    }
    if (state.modules.length > 20) {
      showConfirm('共 ' + state.modules.length + ' 个模块，逐个导出可能较慢。\n\n继续导出所有模块？', function(ok) { if(ok) doExport(); });
    } else { doExport(); }
  });
}

function importBackup(){
  var input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = async function() {
    if (!input.files.length) return;
    var file = input.files[0];
    try {
      var text = await file.text();
      var data = JSON.parse(text);
      if (!data.meta || !data.files) { toast('无效的备份文件'); return; }
      var modCount = Object.keys(data.files).length;
      if (!await showConfirmAsync('将导入 ' + modCount + ' 个模块及合集配置，已有同名模块将被覆盖。\n\n确认导入？')) return;
      var uploaded = 0;
      for (var fid in data.files) {
        var f = data.files[fid];
        var blob = new Blob([f.content], {type:'application/javascript'});
        var fd = new FormData();
        fd.append('files', blob, f.filename);
        var r = await api('/api/admin/modules', {method:'POST', body:fd});
        if (r && r.ok) uploaded++;
      }
      if (data.meta.collections && data.meta.collections.length) {
        for (var ci = 0; ci < data.meta.collections.length; ci++) {
          await api('/api/admin/collections', {method:'POST', json:data.meta.collections[ci]});
        }
      }
      toast('导入完成：' + uploaded + '/' + modCount + ' 个模块');
      loadAll();
    } catch(e) { toast('解析失败：' + e.message); }
  };
  input.click();
}

async function changePassword(){
  var pwd = document.getElementById('pwdNew').value.trim();
  if (!pwd) { toast('请输入密码'); return; }
  if (pwd.length < 4) { toast('密码至少 4 位'); return; }
  var r = await api('/api/admin/change-password', {method:'POST', json:{password:pwd}});
  if (r && r.ok) { toast('密码已修改，下次登录生效'); document.getElementById('pwdNew').value = ''; }
  else toast(r ? r.error : '修改失败');
}


function clearAllData(){
  var o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal" role="dialog" aria-modal="true" aria-label="清除所有数据"><h3>清除所有数据</h3><p style="margin:8px 0;line-height:1.5">将删除所有模块、合集、分组、订阅源和图标，不可撤销。建议先导出一份备份。</p><p style="margin:8px 0;line-height:1.5">确认请在下面输入「清除」两个字：</p><input id="clrIn" class="input" autocomplete="off" placeholder="清除" style="width:100%;box-sizing:border-box"><div class="btn-row"><button class="btn" id="mc" type="button">取消</button><button class="btn btn-primary" id="mC" type="button" disabled>确认清除</button></div></div>';
  document.body.appendChild(o);
  var input=o.querySelector('#clrIn'),go=o.querySelector('#mC'),busy=false;
  function cl(){o.remove();}
  input.addEventListener('input',function(){go.disabled=input.value.trim()!=='清除';});
  o.addEventListener('click',function(e){if(e.target===o)cl();});
  o.querySelector('#mc').addEventListener('click',cl);
  go.addEventListener('click',function(){
    if(busy||input.value.trim()!=='清除')return;busy=true;go.disabled=true;
    api('/api/admin/reset',{method:'POST'}).then(function(r){
      if(r && r.ok){ cl(); toast('已清除'); state.modules=[]; state.collections=[]; state.groups=[]; loadAll(); }
      else{ busy=false; go.disabled=false; toast((r&&r.error)||'清除失败'); }
    });
  });
  setTimeout(function(){try{input.focus();}catch(e){}},50);
}

// ===== MODAL =====
function showModal(t,b,oc){
  var o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal"><h3>'+t+'</h3><div class="desc"></div>'+b+'<div class="btn-row"><button class="btn" id="mc">取消</button><button class="btn btn-primary" id="mC">确认</button></div></div>';
  document.body.appendChild(o);
  function cl(){o.remove();}
  o.addEventListener('click',function(e){if(e.target===o)cl();});
  o.querySelector('#mc').addEventListener('click',cl);
  o.querySelector('#mC').addEventListener('click',function(){oc(cl);});
}

function showConfirm(msg, onOk) {
  var o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal"><h3>确认</h3><p style="margin:8px 0;line-height:1.5">'+msg+'</p><div class="btn-row"><button class="btn" id="mc">取消</button><button class="btn btn-primary" id="mC">确认</button></div></div>';
  document.body.appendChild(o);
  var done = false;
  function cl(r){ if(done)return; done=true; o.remove(); onOk(r); }
  o.addEventListener('click',function(e){if(e.target===o)cl(false);});
  o.querySelector('#mc').addEventListener('click',function(){cl(false);});
  o.querySelector('#mC').addEventListener('click',function(){cl(true);});
}
function showDuplicateChoice(dups) {
  return new Promise(function(resolve) {
    var o=document.createElement('div');o.className='modal-overlay';
    var rows=dups.map(function(d,i){return '<label style="display:block;padding:8px 0;border-bottom:1px solid var(--border,#333);font-size:13px;line-height:1.6"><input type="radio" name="dupPick" value="'+esc(d.id)+'"'+(i===0?' checked':'')+'> <strong>'+esc(d.title||d.filename)+'</strong><br><span style="color:var(--text2)">'+esc(d.matched_by)+'相同 · '+esc(d.filename)+' · 版本 '+esc(d.version||'未知')+(d.subscribed?' · 已订阅':'')+'</span></label>';}).join('');
    o.innerHTML='<div class="modal"><h3>已有相同模块</h3><p style="margin:8px 0;font-size:13px;line-height:1.5">模块库里已有同一个模块。覆盖会更新其内容并保留分组、备注、合集成员；旧版本保留 7 天，可在模块里恢复。</p>'+rows+'<div class="btn-row" style="margin-top:12px"><button class="btn" id="dcX">取消</button><button class="btn" id="dcN">添加为新模块</button><button class="btn btn-primary" id="dcR">覆盖</button></div></div>';
    document.body.appendChild(o);
    var done=false;
    function fin(v){if(done)return;done=true;o.remove();resolve(v);}
    o.addEventListener('click',function(e){if(e.target===o)fin(null);});
    o.querySelector('#dcX').addEventListener('click',function(){fin(null);});
    o.querySelector('#dcN').addEventListener('click',function(){fin({action:'new'});});
    o.querySelector('#dcR').addEventListener('click',function(){var c=o.querySelector('input[name=dupPick]:checked');fin({action:'replace',id:c?c.value:''});});
  });
}
function showConfirmAsync(msg) {
  return new Promise(function(resolve) { showConfirm(msg, resolve); });
}

var _scrLockY = 0, _scrLocked = false;
function _anyModalOpen(){
  if (document.querySelector('.modal-overlay')) return true;
  var ms = document.querySelectorAll('.modal-mask');
  for (var i = 0; i < ms.length; i++) { if (ms[i].style.display && ms[i].style.display !== 'none') return true; }
  return false;
}
function syncScrollLock(){
  var open = _anyModalOpen();
  if (open && !_scrLocked) {
    _scrLocked = true;
    _scrLockY = window.scrollY || 0;
    var b = document.body.style;
    b.position = 'fixed'; b.top = (-_scrLockY) + 'px'; b.left = '0'; b.right = '0'; b.overflow = 'hidden';
  } else if (!open && _scrLocked) {
    _scrLocked = false;
    var b2 = document.body.style;
    b2.position = ''; b2.top = ''; b2.left = ''; b2.right = ''; b2.overflow = '';
    window.scrollTo(0, _scrLockY);
  }
}
new MutationObserver(syncScrollLock).observe(document.body, { childList: true });

function showPrompt(title, def, cb) {
  var o=document.createElement('div');o.className='modal-overlay';
  o.innerHTML='<div class="modal"><h3>'+title+'</h3><input class="input" id="promptInput" value="'+esc(def)+'" style="margin:8px 0"><div class="btn-row"><button class="btn" id="mc">取消</button><button class="btn btn-primary" id="mC">确认</button></div></div>';
  document.body.appendChild(o);
  var done = false;
  function cl(v){ if(done)return; done=true; o.remove(); cb(v); }
  o.addEventListener('click',function(e){if(e.target===o)cl(null);});
  o.querySelector('#mc').addEventListener('click',function(){cl(null);});
  o.querySelector('#mC').addEventListener('click',function(){cl(o.querySelector('#promptInput').value);});
}


(function(){
  try{
    var c=JSON.parse(localStorage.getItem('fwh_cache_v1')||'null');
    if(c && Array.isArray(c.modules) && c.modules.length){
      state.modules=c.modules; state.collections=c.collections||[]; state.groups=c.groups||[];
    }
  }catch(e){}
})();
checkAuth();
</script>
<script>${managementUI}</script>
<script>${backupUI}</script>
<script>${filenameUI}</script>
<script>${autoRulesUI}</script>
<script>${duplicatesUI}</script>
<script>${sharingUI}</script>
<script>${iconUI}</script>
</body>
</html>`;


const MAX_FILE_BYTES   = 25 * 1024 * 1024; // KV 单值上限
const MAX_SOURCE_BYTES = 3 * 1024 * 1024;  // 在线编辑器允许的最大源码
const MAX_IMPORT_BYTES = 10 * 1024 * 1024; // 从 URL 导入时的响应体上限
const PBKDF2_ITER      = 100000;
// 单次上传文件数上限。每个文件占 1 次 KV put 子请求，再叠加 nextSortOrder / DB.batch
// 与引导期往返，都是 1 次；免费版单请求子请求上限 50，取 45 留余量。
const MAX_UPLOAD_FILES = 45;

export const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS modules (
     id TEXT PRIMARY KEY,
     filename TEXT NOT NULL,
     widget_id TEXT,
     title TEXT,
     version TEXT,
     author TEXT,
     file_size INTEGER DEFAULT 0,
     is_encrypted INTEGER DEFAULT 0,
     source_url TEXT,
     note TEXT,
     group_id TEXT DEFAULT '',
     sort_order INTEGER DEFAULT 0,
     created_at INTEGER,
     updated_at INTEGER
   )`,
  `CREATE TABLE IF NOT EXISTS groups (
     id TEXT PRIMARY KEY,
     name TEXT NOT NULL,
     position INTEGER DEFAULT 0,
     created_at INTEGER
   )`,
  `CREATE INDEX IF NOT EXISTS idx_groups_position ON groups(position)`,
  `CREATE INDEX IF NOT EXISTS idx_modules_sort ON modules(sort_order, created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_modules_group ON modules(group_id)`,
  `CREATE TABLE IF NOT EXISTS collections (
     id TEXT PRIMARY KEY,
     slug TEXT UNIQUE NOT NULL,
     title TEXT NOT NULL,
     description TEXT DEFAULT '',
     icon_url TEXT DEFAULT '',
     created_at INTEGER,
     updated_at INTEGER
   )`,
  `CREATE INDEX IF NOT EXISTS idx_collections_created ON collections(created_at DESC)`,
  `CREATE TABLE IF NOT EXISTS collection_modules (
     collection_id TEXT NOT NULL,
     module_id TEXT NOT NULL,
     position INTEGER DEFAULT 0,
     PRIMARY KEY (collection_id, module_id)
   )`,
  `CREATE INDEX IF NOT EXISTS idx_cm_collection ON collection_modules(collection_id, position)`,
  `CREATE TABLE IF NOT EXISTS collection_aliases (
     slug TEXT PRIMARY KEY,
     collection_id TEXT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS sessions (
     token TEXT PRIMARY KEY,
     created_at INTEGER,
     expires_at INTEGER
   )`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_exp ON sessions(expires_at)`,
  `CREATE TABLE IF NOT EXISTS settings (
     key TEXT PRIMARY KEY,
     value TEXT
   )`,
  ...subscriptionSchema,
  ...uploadSchema
];

const SCHEMA_READY = new WeakSet();
async function ensureSchema(env) {
  if (SCHEMA_READY.has(env.DB)) return;
  // Avoid re-running all DDL on every cold start (notably minute cron invocations).
  let installed = null;
  try {
    installed = await env.DB.prepare("SELECT value FROM settings WHERE key='schema_titles_v1'").first();
  } catch (e) { if (!String(e.message).includes('no such table')) throw e; }
  if (installed?.value === '1') { SCHEMA_READY.add(env.DB); return; }
  await env.DB.batch(SCHEMA.map(sql => env.DB.prepare(sql)));
  const columns = await env.DB.prepare('PRAGMA table_info(modules)').all();
  const names = new Set((columns.results || []).map(c => c.name));
  for (const definition of ["group_id TEXT DEFAULT ''", "sort_order INTEGER DEFAULT 0",
    "content_hash TEXT DEFAULT ''", "required_version TEXT DEFAULT '0.0.1'", "source_managed INTEGER DEFAULT 0",
    "manual_override INTEGER DEFAULT 0", "file_key TEXT DEFAULT ''", "metadata_id TEXT DEFAULT ''",
    "code_title TEXT DEFAULT ''", "manifest_title TEXT DEFAULT ''", "title_locked INTEGER DEFAULT 0",
    "generated_filename INTEGER DEFAULT 0", "title_scan_v1 INTEGER DEFAULT 0"]) {
    if (names.has(definition.split(' ')[0])) continue;
    try { await env.DB.prepare('ALTER TABLE modules ADD COLUMN ' + definition).run(); }
    catch (e) { if (!String(e.message).includes('duplicate column')) throw e; }
  }
  await env.DB.prepare(`UPDATE modules SET generated_filename=1 WHERE filename=id||'.js'
    AND EXISTS (SELECT 1 FROM subscription_items i WHERE i.module_id=modules.id)`).run();
  await env.DB.prepare("INSERT OR REPLACE INTO settings (key,value) VALUES ('schema_titles_v1','1')").run();
  SCHEMA_READY.add(env.DB);
}

const BOOT = new WeakMap();
export async function bootstrap(env) {
  if(!BOOT.has(env.DB))BOOT.set(env.DB,(async()=>{
    await ensureSchema(env);
    const flag=await env.DB.prepare("SELECT value FROM settings WHERE key='schema_cf_v31_1'").first();
    if(flag?.value!=='1')await env.DB.batch([...iconSchema,...backupSchema,
      "INSERT OR REPLACE INTO settings(key,value) VALUES('schema_cf_v31_1','1')"].map(sql=>env.DB.prepare(sql)));
    const namesFlag=await env.DB.prepare("SELECT value FROM settings WHERE key='schema_cf_v32_1'").first();
    if(namesFlag?.value!=='1')await env.DB.batch([...filenameSchema,...autoAllSchema,
      "INSERT OR REPLACE INTO settings(key,value) VALUES('schema_cf_v32_1','1')"].map(sql=>env.DB.prepare(sql)));
    const sharingFlag=await env.DB.prepare("SELECT value FROM settings WHERE key='schema_cf_v33_1'").first();
    if(sharingFlag?.value!=='1'){
      await env.DB.batch(sharingSchema.map(sql=>env.DB.prepare(sql)));
      await upgradeSubscriptions(env);
      await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_cf_v33_1','1')").run();
    }
    const migFail=[];
    for(const [name,fn] of [['排序迁移',()=>migrateSortOrder(env.DB)],['旧数据迁移',()=>migrateLegacyKV(env)],['自动维护',()=>autoMaintain(env,env.DB)]]){
      try{await fn();}catch(e){console.error('迁移失败 '+name+': '+(e&&e.message||e));migFail.push(name+'：'+String(e&&e.message||e).slice(0,120));}
    }
    try{
      if(migFail.length)await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('migration_errors_v1',?)").bind(JSON.stringify({at:Date.now(),errors:migFail})).run();
      else await env.DB.prepare("DELETE FROM settings WHERE key='migration_errors_v1'").run();
    }catch(e){}
  })());
  try{await BOOT.get(env.DB);}catch(e){BOOT.delete(env.DB);throw e;}
}

let LEGACY_READY = false;
async function migrateLegacyKV(env) {
  if (LEGACY_READY) return { skipped: true };
  const flag = await env.DB.prepare('SELECT value FROM settings WHERE key = ?')
    .bind('migrated_v1').first();
  if (flag) { LEGACY_READY = true; return { skipped: true }; }

  let legacyMods = null, legacyCols = null;
  try {
    legacyMods = await env.KV.get('modules', 'json');
    legacyCols = await env.KV.get('collections', 'json');
  } catch (e) {  }

  const stmts = [];
  let modCount = 0, colCount = 0, linkCount = 0;

  if (Array.isArray(legacyMods)) {
    for (const m of legacyMods) {
      if (!m || !m.id) continue;
      stmts.push(env.DB.prepare(
        `INSERT OR IGNORE INTO modules
           (id, filename, widget_id, title, version, author, file_size, is_encrypted, source_url, note, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
      ).bind(
        m.id, m.filename || '', m.widget_id || m.id, m.title || '', m.version || '',
        m.author || '', m.file_size || 0, m.is_encrypted ? 1 : 0,
        m.source_url || null, m.note || '',
        m.created_at || Date.now(), m.updated_at || Date.now()
      ));
      modCount++;
    }
  }

  if (Array.isArray(legacyCols)) {
    for (const c of legacyCols) {
      if (!c || !c.id) continue;
      stmts.push(env.DB.prepare(
        `INSERT OR IGNORE INTO collections (id, slug, title, description, icon_url, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?)`
      ).bind(c.id, c.slug || c.id, c.title || 'untitled', c.description || '',
             c.icon_url || '', c.created_at || Date.now(), c.updated_at || Date.now()));
      colCount++;
      const ids = c.moduleIds || (Array.isArray(c.modules) ? c.modules.map(x => x.id) : []);
      ids.forEach((mid, i) => {
        if (!mid) return;
        stmts.push(env.DB.prepare(
          'INSERT OR IGNORE INTO collection_modules (collection_id, module_id, position) VALUES (?,?,?)'
        ).bind(c.id, mid, i));
        linkCount++;
      });
    }
  }

  if (stmts.length) await env.DB.batch(stmts);
  await env.DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
    .bind('migrated_v1', String(Date.now())).run();

  LEGACY_READY = true;
  return { skipped: false, modules: modCount, collections: colCount, links: linkCount };
}


// ===== 登录限流 =====
const _loginAttempts = new Map();
const _authCache = new Map();
const LOGIN_WINDOW = 300000;
const LOGIN_MAX_TRY = 5;
const LOGIN_MAP_CAP = 5000;
function _loginAllowed(ip) {
  const now = Date.now();
  if (_loginAttempts.size > LOGIN_MAP_CAP) {
    for (const [k, v] of _loginAttempts) { if (now > v.resetAt) _loginAttempts.delete(k); }
    // Never clear() the whole table: that would reset every victim's counter. Evict oldest entries only.
    for (const k of _loginAttempts.keys()) { if (_loginAttempts.size <= LOGIN_MAP_CAP * 0.9) break; _loginAttempts.delete(k); }
  }
  const rec = _loginAttempts.get(ip);
  if (!rec || now > rec.resetAt) { _loginAttempts.set(ip, { count: 1, resetAt: now + LOGIN_WINDOW }); return true; }
  rec.count++;
  return rec.count <= LOGIN_MAX_TRY;
}


const ENC_HEURISTIC_V = '2';
async function nextSortOrder(DB){
  try{
    const r = await DB.prepare('SELECT COALESCE(MIN(sort_order), 0) - 1 AS m FROM modules').first();
    const v = r ? Number(r.m) : -1;
    return Number.isFinite(v) ? v : -1;
  }catch(e){ return -1; }
}

let SORT_READY = false;
async function migrateSortOrder(DB) {
  if (SORT_READY) return;
  const flag = await DB.prepare('SELECT value FROM settings WHERE key = ?').bind('sort_order_v1').first();
  if (!flag) {
    const { results } = await DB.prepare('SELECT id FROM modules WHERE sort_order IS NULL ORDER BY created_at DESC').all();
    const list = results || [];
    for (let i = 0; i < list.length; i += 100) {
      await DB.batch(list.slice(i, i + 100).map((r, k) =>
        DB.prepare('UPDATE modules SET sort_order = ? WHERE id = ?').bind(i + k, r.id)));
    }
    await DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
      .bind('sort_order_v1', String(Date.now())).run();
  }
  SORT_READY = true;
}

let MAINT_READY = false;
const MAINT_BATCH = 8;
const MAINT_MAX_BYTES = 1024 * 1024;
const ENC_FLAG_KEY = 'enc_heuristic_v';
const ENC_CURSOR_KEY = 'enc_scan_cursor';
async function autoMaintain(env, DB) {
  if (MAINT_READY) return;
  MAINT_READY = true;
  const flag = await DB.prepare('SELECT value FROM settings WHERE key = ?').bind(ENC_FLAG_KEY).first();
  if (flag && flag.value === ENC_HEURISTIC_V) return;

  // 每轮只扫一批、按 id 游标推进，扫完一轮才落最终标记。
  // 只取 1 MB 以内的模块：判定只需文件头 32 字节，而 KV 不支持按范围读，
  // 大文件整块读会顶到 isolate 的 128 MB 内存上限，也会瞬间打满子请求配额。
  const cur = await DB.prepare('SELECT value FROM settings WHERE key = ?').bind(ENC_CURSOR_KEY).first();
  const after = cur && cur.value ? String(cur.value) : '';
  const { results } = await DB.prepare(
    'SELECT id, is_encrypted FROM modules WHERE id > ? AND file_size <= ? ORDER BY id LIMIT ?'
  ).bind(after, MAINT_MAX_BYTES, MAINT_BATCH).all();
  const list = results || [];

  if (!list.length) {
    await DB.batch([
      DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').bind(ENC_CURSOR_KEY, ''),
      DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').bind(ENC_FLAG_KEY, ENC_HEURISTIC_V)
    ]);
    return;
  }

  const bufs = await Promise.all(list.map(r =>
    getFileKey(env,r.id).then(key=>env.KV.get(key,'arrayBuffer')).catch(() => null)));
  const stmts = [];
  list.forEach((r, k) => {
    const buf = bufs[k];
    if (!buf) return;
    const enc = isEncrypted(new Uint8Array(buf));
    if (Number(r.is_encrypted) === enc) return;
    stmts.push(DB.prepare('UPDATE modules SET is_encrypted = ?, updated_at = ? WHERE id = ?')
      .bind(enc, Date.now(), r.id));
  });
  stmts.push(DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
    .bind(ENC_CURSOR_KEY, list[list.length - 1].id));
  await DB.batch(stmts);
}

// ===== KV 文件读写 =====
async function putFile(env,id,buf,updatedAt) {
  const key='source-content:'+crypto.randomUUID(),size=buf.byteLength;
  await env.KV.put(key,buf,{metadata:{u:updatedAt||Date.now(),s:size}});
  return key;
}

// ===== 密码哈希（PBKDF2-SHA256） =====
function toHex(u8) { return Array.from(u8).map(b => b.toString(16).padStart(2, '0')).join(''); }
function hexToBytes(hex) {
  const a = new Uint8Array(hex.length >> 1);
  for (let i = 0; i < a.length; i++) a[i] = parseInt(hex.substr(i * 2, 2), 16);
  return a;
}
function safeEqualHex(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
async function pbkdf2Hex(password, saltU8, iter) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: saltU8, iterations: iter, hash: 'SHA-256' }, key, 256);
  return toHex(new Uint8Array(bits));
}
async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const h = await pbkdf2Hex(password, salt, PBKDF2_ITER);
  return 'pbkdf2$' + PBKDF2_ITER + '$' + toHex(salt) + '$' + h;
}
async function verifyPassword(password, stored, envPassword) {
  if (stored && stored.indexOf('pbkdf2$') === 0) {
    const p = stored.split('$');
    if (p.length !== 4) return false;
    const iter = parseInt(p[1], 10) || PBKDF2_ITER;
    const h = await pbkdf2Hex(password, hexToBytes(p[2]), iter);
    return safeEqualHex(h, p[3]);
  }
  const expected = await sha256(stored || envPassword || '');
  return safeEqualHex(await sha256(password), expected);
}

// ===== 外部 URL 抓取 =====
const MAX_REDIRECTS = 5;
function isBlockedHost(hostname) {
  let h = String(hostname || '').toLowerCase();
  if (h.startsWith('[') && h.endsWith(']')) h = h.slice(1, -1);
  if (!h) return true;
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.internal') || h.endsWith('.local')) return true;
  // IPv6 字面量一律拒绝：覆盖 [::1]、[::ffff:127.0.0.1] 等写法
  if (h.indexOf(':') >= 0) return true;
  // 纯数字主机：十进制 / 八进制 / 十六进制形式的 IP（如 2130706433、0177.0.0.1）
  if (/^(0x[0-9a-f]+|\d+)$/i.test(h)) return true;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  if (/^0\d/.test(m[1]) || /^0\d/.test(m[2]) || /^0\d/.test(m[3]) || /^0\d/.test(m[4])) return true;
  const a = +m[1], b = +m[2];
  if (a === 0 || a === 10 || a === 127) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a >= 224) return true;
  return false;
}
// 来源地址策略（Docker 部署可配置；Cloudflare 上保持默认：全部检查）。
//  check=false：允许内网/局域网来源（仍拒绝 169.254.x.x 云元数据与 0.x 地址、非 http/https）。
//  trusted：逐个 origin 白名单，命中则跳过主机检查。
let SOURCE_POLICY = { check: true, trusted: [] };
export function configureSourcePolicy(opts = {}) {
  const raw = opts.check === undefined || opts.check === null || opts.check === '' ? 'true' : String(opts.check);
  SOURCE_POLICY = {
    check: !/^(0|false|no|off)$/i.test(raw.trim()),
    trusted: String(opts.trusted || '').split(/[\s,]+/).filter(Boolean)
      .map(x => { try { return new URL(x).origin; } catch (e) { return ''; } }).filter(Boolean)
  };
}
function isAlwaysBlockedHost(hostname) {
  const h = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (!h) return true;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (m && (+m[1] === 0 || (+m[1] === 169 && +m[2] === 254) || +m[1] >= 224)) return true;
  if (/^(0x[0-9a-f]+|\d+)$/i.test(h)) return true;
  return false;
}
export function assertFetchableUrl(raw) {
  let u;
  try { u = new URL(raw); } catch (e) { throw new Error('URL 格式不合法'); }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('只支持 http/https');
  if (u.username || u.password) throw new Error('地址不能包含用户名或密码');
  const relaxed = !SOURCE_POLICY.check || SOURCE_POLICY.trusted.includes(u.origin);
  if (relaxed ? isAlwaysBlockedHost(u.hostname) : isBlockedHost(u.hostname)) throw new Error('不允许的地址');
  return u;
}
export async function fetchCapped(rawUrl, maxBytes, info) {
  let u = assertFetchableUrl(rawUrl), resp = null;
  // One budget covers connection, all redirects and the complete response body.
  const signal = AbortSignal.timeout(60000);
  try {
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    // redirect:manual —— 每一跳都重新校验，避免 302 到内网绕过首跳检查
    resp = await fetch(u.toString(), {
      redirect: 'manual',
      signal
    });
    if (resp.status < 300 || resp.status >= 400) break;
    const loc = resp.headers.get('Location');
    if (loc) await resp.body?.cancel();
    if (!loc) break;
    if (hop === MAX_REDIRECTS) throw new Error('重定向次数过多');
    u = assertFetchableUrl(new URL(loc, u).toString());
  }
  if (!resp.ok) { await resp.body?.cancel(); throw new Error('Failed to fetch: ' + resp.status); }
  if(info){info.contentType=resp.headers.get('content-type')||'';info.contentDisposition=resp.headers.get('content-disposition')||'';}
  const len = Number(resp.headers.get('content-length') || 0);
  if (len && len > maxBytes) throw new Error('文件过大（' + Math.round(len / 1048576) + ' MB），上限 ' + Math.round(maxBytes / 1048576) + ' MB');
  if (!resp.body) return new ArrayBuffer(0);
  const reader = resp.body.getReader(), chunks = [];
  let size = 0;
  try {
    while (true) {
      const {done,value} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) { await reader.cancel(); throw new Error('文件过大，上限 ' + Math.round(maxBytes / 1048576) + ' MB'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk,offset); offset += chunk.byteLength; }
  return bytes.buffer;
  } catch (e) {
    if (signal.aborted || e?.name === 'TimeoutError') {
      throw new Error('读取外部链接超时（60 秒），源站响应较慢，请稍后重试或下载文件后上传');
    }
    throw e;
  }
}

// ===== 响应工具 =====
function htmlHeaders() {
  return {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
    'Content-Security-Policy': "default-src 'self'; manifest-src 'self'; img-src * data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'"
  };
}

const application = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;


    if (method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Cookie',
          'Access-Control-Max-Age': '86400'
        }
      });
    }

    if (!env.DB) {
      return json({ error: '未绑定 D1：请在 Worker 的 Settings → Bindings 添加 D1 Database，变量名填 DB' }, 500);
    }

    if (!env.KV) {
      return json({ error: '未绑定 KV：请在 Worker 的 Settings → Bindings 添加 KV Namespace，变量名填 KV' }, 500);
    }

    try {
      await bootstrap(env);
    } catch (e) {
      return json({ error: '数据库初始化失败：' + String((e && e.message) || e) }, 500);
    }

    const DB = env.DB;

    try {



    if(path.startsWith('/api/icons/')){
      if(!['GET','HEAD'].includes(method))return json({error:'Method not allowed'},405);
      // [优化4] 图标 URL 本身就是内容哈希、天然版本化：先查边缘缓存（复用 A1
      // 的版本化键 helper），命中直接返回；未命中才打 D1+KV，200 时写入缓存。
      // Docker/Node 无 Cache API 时 helper 自动跳过，行为与原来一致。
      const iconHash=/^\/api\/icons\/([a-f0-9]{64})\.(?:png|jpg|webp)$/.exec(path)?.[1];
      if(method==='GET'&&iconHash){
        const cachedIcon=await a1CacheMatch(request,iconHash);
        if(cachedIcon)return cachedIcon;
        const iconResp=await iconResponse(env,path,request);
        a1CacheStore(ctx,request,iconHash,iconResp);
        return iconResp;
      }
      return iconResponse(env,path,request);
    }
    if(path==='/api/admin/icon-sources'||path.startsWith('/api/admin/icon-sources/')||path==='/api/admin/icons'||path.startsWith('/api/admin/icons/')){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      try{
        if(path==='/api/admin/icon-sources'){
          if(method==='GET')return json(await listIconSources(env));
          if(method==='POST')return json(await addIconSource(env,await request.json()),201);
        }
        const source=path.match(/^\/api\/admin\/icon-sources\/([A-Za-z0-9-]+)(\/refresh)?$/);
        if(source){
          if(source[2]&&method==='POST')return json({ok:true,...await refreshIconSource(env,source[1])});
          if(!source[2]&&method==='PATCH')return json(await changeIconSource(env,source[1],await request.json()));
          if(!source[2]&&method==='DELETE')return json(await deleteIconSource(env,source[1]));
        }
        if(path==='/api/admin/icons'&&method==='GET')return json(await queryIcons(env,url.searchParams));
        const entry=path.match(/^\/api\/admin\/icons\/([a-f0-9]{64})\/cache$/);
        if(entry&&method==='POST')return json({ok:true,...await cacheIcon(env,entry[1])});
        return json({error:'Method not allowed'},405);
      }catch(e){return json({error:String(e.message||e)},400);}
    }
    if(path==='/api/admin/backup'||path.startsWith('/api/admin/backup/')){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      try{
        if(path==='/api/admin/backup'&&method==='GET')return await exportBackup(env);
        if(path==='/api/admin/backup/restore/start'&&method==='POST'){
          if(Number(request.headers.get('content-length'))>2000000)return json({error:'备份清单过大'},413);
          return json(await beginRestore(env,await request.json()));
        }
        const restore=path.match(/^\/api\/admin\/backup\/restore\/([a-f0-9-]+)\/(commit|files\/[^/]+)$/);
        if(restore){
          if(restore[2]==='commit'&&method==='POST')return json(await commitRestore(env,restore[1]));
          if(restore[2].startsWith('files/')&&method==='PUT'){
            if(Number(request.headers.get('content-length'))>MAX_FILE_BYTES)return json({error:'备份文件过大'},413);
            const bytes=await request.arrayBuffer();if(bytes.byteLength>MAX_FILE_BYTES)return json({error:'备份文件过大'},413);
            return json(await stageRestoreFile(env,restore[1],decodeURIComponent(restore[2].slice(6)),bytes,{parseMeta,isEncrypted}));
          }
        }
        return json({error:'Method not allowed'},405);
      }catch(e){return json({error:String(e.message||e)},400);}
    }

    async function adminPasswordRow() {
      return await DB.prepare('SELECT value FROM settings WHERE key = ?').bind('admin_password').first();
    }

    async function verifyAuth(r) {
      const m = (r.headers.get('Cookie') || '').match(/fwh_admin=([^;]+)/);
      if (!m) return false;
      const nowMs = Date.now(), hit = _authCache.get(m[1]);
      if (hit && hit.until > nowMs && hit.exp > nowMs) return true;
      const row = await DB.prepare('SELECT expires_at FROM sessions WHERE token = ?').bind(m[1]).first();
      if (!row) { _authCache.delete(m[1]); return false; }
      if (Number(row.expires_at) < nowMs) {
        _authCache.delete(m[1]);
        await DB.prepare('DELETE FROM sessions WHERE token = ?').bind(m[1]).run();
        return false;
      }
      // 通过的校验缓存 5 秒（单实例内），踢出其他设备时会立即清空
      if (_authCache.size >= 200) _authCache.delete(_authCache.keys().next().value);
      _authCache.set(m[1], { until: nowMs + 5000, exp: Number(row.expires_at) });
      return true;
    }


    async function getModules() {
      const { results } = await DB.prepare(`SELECT m.*, sub.subscription_title, sub.upstream_active
        FROM modules m LEFT JOIN (
          SELECT i.module_id AS module_id, MIN(s.title) AS subscription_title, MAX(i.active) AS upstream_active
          FROM subscription_items i JOIN subscription_sources s ON s.id=i.source_id
          GROUP BY i.module_id) sub ON sub.module_id=m.id
        ORDER BY m.sort_order ASC, m.created_at DESC`).all();
      return decorateNames(env,(results || []).map(r => ({ ...r,title:resolveTitle(r),title_source:titleSource(r),
        hide_filename:generatedFilename(r),is_encrypted: Number(r.is_encrypted) || 0 })));
    }
    async function getModule(id) {
      const r = await DB.prepare('SELECT * FROM modules WHERE id = ?').bind(id).first();
      return r ? { ...r, is_encrypted: Number(r.is_encrypted) || 0 } : null;
    }
    async function getCollections() {
      const { results: cols } = await DB.prepare('SELECT * FROM collections ORDER BY created_at DESC').all();
      const { results: links } = await DB.prepare(
        'SELECT collection_id, module_id FROM collection_modules ORDER BY collection_id, position'
      ).all();
      const map = {};
      for (const l of (links || [])) {
        (map[l.collection_id] = map[l.collection_id] || []).push(l.module_id);
      }
      const options=new Map((await DB.prepare('SELECT * FROM collection_options').all()).results.map(o=>[o.collection_id,!!o.auto_all]));
      return (cols || []).map(c => ({ ...c,autoAll:options.get(c.id)||false, moduleIds: map[c.id] || [] }));
    }

    async function ensureUniqueSlug(base, excludeId) {
      let slug = base, n = 2;
      while (true) {
        const hit = await DB.prepare('SELECT id FROM collections WHERE slug = ?').bind(slug).first();
        const taken = hit && (!excludeId || hit.id !== excludeId);
        const alias = taken ? null
          : await DB.prepare('SELECT 1 AS x FROM collection_aliases WHERE slug = ?').bind(slug).first();
        if (!taken && !alias) return slug;
        slug = base + '-' + n++;
      }
    }
    async function findCollectionBySlug(rawSlug) {
      const candidates = [];
      try {
        const decoded = decodeURIComponent(rawSlug);
        if (decoded !== rawSlug) candidates.push(decoded);
      } catch (e) {  }
      candidates.push(rawSlug);
      for (const s of candidates) {
        const row = await DB.prepare('SELECT * FROM collections WHERE slug = ?').bind(s).first();
        if (row) return row;
      }

      for (const s of candidates) {
        const a = await DB.prepare('SELECT collection_id FROM collection_aliases WHERE slug = ?').bind(s).first();
        if (a) {
          const row = await DB.prepare('SELECT * FROM collections WHERE id = ?').bind(a.collection_id).first();
          if (row) return row;
        }
      }
      return null;
    }
    async function setCollectionModules(colId, ids) {
      return replaceMembers(env,colId,ids);
    }


    if (path === '/api/admin/auth') {
      if (method === 'GET') {
        return json({ enabled: !!(env.ADMIN_PASSWORD || await adminPasswordRow()), authenticated: await verifyAuth(request) });
      }
      if (method === 'POST') {
        const _ip = request.headers.get('CF-Connecting-IP') || 'unknown';
        if (!_loginAllowed(_ip)) return json({ error: '尝试次数过多，请 5 分钟后再试' }, 429);
        const { password } = await request.json().catch(() => ({}));
        if (!password) return json({ error: '密码不能为空' }, 400);
        const prow = await adminPasswordRow();
        const stored = (prow && prow.value) ? prow.value : '';
        if (!(await verifyPassword(password, stored, env.ADMIN_PASSWORD))) {
          return json({ error: '密码错误' }, 401);
        }
        if (!stored || stored.indexOf('pbkdf2$') !== 0) {
          try {
            await DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
              .bind('admin_password', await hashPassword(password)).run();
          } catch (e) {}
        }
        const token = genId() + genId().replace(/-/g, '');
        const now = Date.now(), exp = now + 86400000 * 7;
        await DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now).run();
        await DB.prepare('INSERT INTO sessions (token, created_at, expires_at) VALUES (?,?,?)')
          .bind(token, now, exp).run();
        _loginAttempts.delete(_ip);
        return json({ ok: true }, 200, {
          'Set-Cookie': 'fwh_admin=' + token + '; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=' + (86400 * 7)
        });
      }
    }


    if (path === '/api/admin/migrate') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const flag = await DB.prepare('SELECT value FROM settings WHERE key = ?').bind('migrated_v1').first();
      if (method === 'GET') {
        const { results } = await DB.prepare('SELECT COUNT(*) AS n FROM modules').all();
        return json({
          migrated: !!flag,
          migratedAt: flag ? Number(flag.value) : null,
          modulesInD1: (results && results[0] && results[0].n) || 0
        });
      }
      if (method === 'POST') {

        await DB.prepare('DELETE FROM settings WHERE key = ?').bind('migrated_v1').run();
        const report = await migrateLegacyKV(env);
        return json({ ok: true, report });
      }
    }


    if(path==='/api/admin/modules/bulk'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='POST')return json({error:'Method not allowed'},405);
      try{return json(await bulkManage(env,await request.json()));}
      catch(e){return json({error:String(e.message||e)},400);}
    }
    const membersMatch=path.match(/^\/api\/admin\/collections\/([^/]+)\/members$/);
    if(membersMatch){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='PUT')return json({error:'Method not allowed'},405);
      try{const body=await request.json();if(!Array.isArray(body.expectedModuleIds))throw Error('请重新打开合集管理窗口');
        return json(await replaceMembers(env,membersMatch[1],body.moduleIds,body.expectedModuleIds));}
      catch(e){return json({error:String(e.message||e)},409);}
    }
    if(path==='/api/admin/modules/scan-titles'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='POST')return json({error:'Method not allowed'},405);
      return json(await backfillTitles(env,2));
    }
    if(path==='/api/admin/filename-preview'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='POST')return json({error:'Method not allowed'},405);
      try{const body=await request.json(),u=assertFetchableUrl(body.url,env);
        if(/\.(rex|fwd)$/i.test(u.pathname))return json({ok:true,collection:true,suggested:''});
        let original=String(body.filename||urlFilename(u.href,'import.js'));if(!/\.js$/i.test(original))original+='.js';
        const id=toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(u.href))));
        const n=await prepareName(env,id,original);return json({ok:true,original,suggested:n.filename});
      }catch(e){return json({error:String(e.message||e)},400);}
    }
    if(path==='/api/admin/auto-rules'||path==='/api/admin/auto-rules/run'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      try{
        if(path==='/api/admin/auto-rules'){
          if(method==='GET')return json(await loadAutoRules(env),200,{'Cache-Control':'no-store'});
          if(method==='PUT')return json(await saveAutoRules(env,await request.json().catch(()=>null)));
          return json({error:'Method not allowed'},405);
        }
        if(method!=='POST')return json({error:'Method not allowed'},405);
        return json(await runAutoRules(env,(await request.json().catch(()=>({}))).scope));
      }catch(e){return json({error:String(e.message||e)},400);}
    }
    if(path==='/api/admin/filename-settings'||path==='/api/admin/modules/filenames'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      try{
        if(path.endsWith('filename-settings')){
          if(method==='GET')return json(await namingSettings(env));
          if(method!=='PATCH')return json({error:'Method not allowed'},405);
          const body=await request.json();if(typeof body.auto_clean!=='boolean')throw Error('配置无效');
          await DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('filename_auto_clean',?)").bind(String(body.auto_clean)).run();
          return json({ok:true,...await namingSettings(env)});
        }
        if(method==='GET')return env.ATOMIC(async()=>json(await scanNames(env)));
        if(method==='POST')return json(await repairNames(env,(await request.json()).rows));
        return json({error:'Method not allowed'},405);
      }catch(e){return json({error:String(e.message||e)},409);}
    }
    if(['','/delete','/auto','/keep','/ignore','/ignore/clear'].some(x=>path==='/api/admin/modules/duplicates'+x)){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      const sub=path.slice('/api/admin/modules/duplicates'.length);
      const deleting=sub==='/delete',auto=sub==='/auto';
      if(method!==(sub?'POST':'GET'))return json({error:'Method not allowed'},405);
      try{
        // [自改A3] 保留这份 / 两者都留（忽略此组）/ 清除忽略
        if(sub==='/keep'){const body=await request.json().catch(()=>({}));
          const data=body.apply===true?await keepOneDuplicate(env,{...body,apply:true}):await env.ATOMIC(()=>keepOneDuplicate(env,{...body,apply:false}));
          return json(data,200,{'Cache-Control':'no-store'});}
        if(sub==='/ignore'){const body=await request.json().catch(()=>({}));
          return json(await env.ATOMIC(()=>ignoreDuplicateGroup(env,body)),200,{'Cache-Control':'no-store'});}
        if(sub==='/ignore/clear')return json(await env.ATOMIC(()=>clearDuplicateIgnores(env)),200,{'Cache-Control':'no-store'});
        // [自改A3] 一键自动去重：apply=false 只返回计划，apply=true 才真正删除。
        if(auto){const body=await request.json().catch(()=>({}));
          const data=body.apply===true?await runAutoDedupe(env,{apply:true}):await env.ATOMIC(()=>runAutoDedupe(env,{apply:false}));
          return json(data,200,{'Cache-Control':'no-store'});}
        const data=deleting?await deleteScannedDuplicate(env,await request.json()):
          await env.ATOMIC(()=>scanDuplicateModules(env));
        return json(data,200,{'Cache-Control':'no-store'});
      }catch(e){return json({error:String(e.message||e)},deleting?409:500,{'Cache-Control':'no-store'});}
    }
    const downloadMatch=path.match(/^\/api\/admin\/modules\/([^/]+)\/download$/);
    if(downloadMatch){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='GET')return json({error:'Method not allowed'},405);
      return env.ATOMIC(async()=>{
        const mod=await getModule(downloadMatch[1]);if(!mod)return json({error:'模块不存在'},404);
        const bytes=await env.KV.get(await getFileKey(env,mod.id),'arrayBuffer');
        if(!bytes)return json({error:'模块文件缺失，无法下载'},404);
        const m=(await decorateNames(env,[mod]))[0];
        return new Response(bytes,{headers:{'Content-Type':'application/javascript; charset=utf-8',
          'Content-Disposition':contentDisposition(downloadFilename(m),true),'Content-Length':String(bytes.byteLength),
          'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
      });
    }
    if (path === '/api/admin/modules/upload/preview' || path === '/api/admin/modules/upload/commit') {
      if (!await verifyAuth(request)) return json({error:'Unauthorized'},401);
      if (method!=='POST') return json({error:'Method not allowed'},405);
      try {
        if (Number(request.headers.get('Content-Length')||0)>51*1024*1024) throw new Error('一批上传总大小不能超过 50 MB');
        const fd=await request.formData();
        if(path.endsWith('/preview')) {
          const files=fd.getAll('files').filter(f=>f instanceof File && f.name);
          return json(await previewUploads(env,files,String(fd.get('group_id')||''),uploadHelpers,String(fd.get('target_id')||'')));
        }
        return json(await commitUpload(env,{job_id:String(fd.get('job_id')||''),index:Number(fd.get('index')),
          action:String(fd.get('action')||''),target_id:String(fd.get('target_id')||''),
          mode:String(fd.get('mode')||''),filename:fd.has('filename')?String(fd.get('filename')):undefined,file:fd.get('file')},uploadHelpers));
      }catch(e){return json({error:String(e.message||e)},400);}
    }
    const versionMatch=path.match(/^\/api\/admin\/modules\/([^/]+)\/(previous-version|maintenance)$/);
    if(versionMatch){
      if (!await verifyAuth(request)) return json({error:'Unauthorized'},401);
      const id=versionMatch[1];
      try{
        if(versionMatch[2]==='previous-version'){
          if(method==='GET')return json({ok:true,previous:await previousVersion(env,id)});
          if(method==='POST'){
            const body=await request.json();return json(await restorePrevious(env,id,body.created_at));
          }
        }else if(method==='PATCH'){
          const body=await request.json();
          return json(await withModuleLock(env,'module:'+id,async()=>{
            const m=await getModule(id);if(!m)throw new Error('模块不存在');
            await DB.prepare('UPDATE modules SET manual_override=? WHERE id=?').bind(body.manual?1:0,id).run();
            if(!body.manual) await DB.prepare(`UPDATE subscription_sources SET next_sync_at=0 WHERE id IN
              (SELECT source_id FROM subscription_items WHERE module_id=?)`).bind(id).run();
            return {ok:true};
          }));
        }
        return json({error:'Method not allowed'},405);
      }catch(e){return json({error:String(e.message||e)},400);}
    }

    const shareMatch=path.match(/^\/api\/admin\/modules\/([^/]+)\/share(?:\/(preview))?$/);
    if(shareMatch){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(!((shareMatch[2]&&method==='POST')||(!shareMatch[2]&&method==='PUT')))return json({error:'Method not allowed'},405);
      try{const body=await request.json();return json(shareMatch[2]?await previewShare(env,shareMatch[1],body.alias):await saveShare(env,shareMatch[1],body));}
      catch(e){return json({error:e.message},409);}
    }
    if(path==='/api/admin/subscriptions/preview'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(method!=='POST')return json({error:'Method not allowed'},405);
      try{const body=await request.json();return json(await previewSource(env,body.url,subscriptionHelpers));}catch(e){return json({error:e.message},400);}
    }
    if(path==='/api/admin/subscriptions/legacy'){
      if(!await verifyAuth(request))return json({error:'Unauthorized'},401);
      if(!['GET','POST'].includes(method))return json({error:'Method not allowed'},405);
      try{return json(await legacySources(env,method==='POST'?await request.json():null));}catch(e){return json({error:e.message},409);}
    }
    if (path === '/api/admin/subscriptions') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      if (method === 'GET') return json(await listSubscriptions(env));
      if (method === 'POST') {
        const body = await request.json().catch(() => ({}));
        try {
          const p=body.preview_id?await readSourcePreview(env,body):null;
          const dup=await duplicateGate(env,body,p);if(dup)return json(dup);
          return json({ ok: true, subscription: await addSubscription(env,p?.url||body.url,body.group_id,subscriptionHelpers,p?.buffer,{...body,filename:body.filename||p?.meta.source_filename}) });
        } catch(e) { return json({error:String(e.message||e),duplicates:e.duplicates},e.status||400); }
      }
      return json({error:'Method not allowed'},405);
    }
    const subscriptionMatch = path.match(/^\/api\/admin\/subscriptions\/([^/]+)(?:\/(sync|retry|items|icon))?$/);
    if (subscriptionMatch) {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const id=subscriptionMatch[1], operation=subscriptionMatch[2];
      if (operation==='items' && method==='GET') return json(await subscriptionItems(env,id));
      if (operation==='retry' && method==='POST') {
        try { const b=await request.json().catch(()=>({})); return json(await syncSubscription(env,id,'retry',subscriptionHelpers,b&&b.after)); }
        catch(e) { return json({error:String(e.message||e)},400); }
      }
      if (operation==='sync' && method==='POST') {
        try { return json(await syncSubscription(env,id,'continue',subscriptionHelpers)); }
        catch(e) { return json({error:String(e.message||e)},400); }
      }
      const source=await DB.prepare('SELECT * FROM subscription_sources WHERE id=?').bind(id).first();
      if (!source) return json({error:'Not found'},404);
      if(operation==='icon'&&method==='PATCH'){
        try{return json(await changeSubscriptionIcon(env,source,(await request.json())||{}));}
        catch(e){return json({error:e.message},e.message.includes('已变化')?409:400);}
      }
      if (source.lease_until>Date.now()) return json({error:'订阅正在同步，请完成后再操作'},409);
      if (!operation && method==='PATCH') {
        const body=await request.json().catch(()=>({}));
        if(body.url!==undefined||body.title!==undefined){try{return json(await editSource(env,source,body,subscriptionHelpers));}catch(e){return json({error:e.message},409);}}
        await DB.prepare("UPDATE subscription_sources SET enabled=?,next_sync_at=0,revision=? WHERE id=?")
          .bind(body.enabled?1:0,crypto.randomUUID(),id).run();
        return json({ok:true});
      }
      if (!operation && method==='DELETE') {
        await DB.batch([
          DB.prepare('DELETE FROM subscription_items WHERE source_id=?').bind(id),
          DB.prepare('DELETE FROM subscription_sources WHERE id=?').bind(id)
        ]);
        return json({ok:true});
      }
      return json({error:'Method not allowed'},405);
    }

    if (path === '/api/admin/modules/import') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      if (method !== 'POST') return json({ error: 'Method not allowed' }, 405);
      const body = await request.json().catch(() => ({}));
      if (!body.url) return json({ error: 'url required' }, 400);
      try {
        const p=body.preview_id?await readSourcePreview(env,body):null;
        const dup=await duplicateGate(env,body,p);if(dup)return json(dup);
        const subscription=await addSubscription(env,p?.url||body.url,body.group_id,subscriptionHelpers,p?.buffer,{...body,filename:body.filename||p?.meta.source_filename});
        return json({ok:true,subscription,existing:subscription.existing,added:await decorateNames(env,subscription.added||[])},201);
      } catch (e) {
        return json({ error: String((e && e.message) || e),duplicates:e.duplicates }, e.status||400);
      }
    }


    const sourceMatch = path.match(/^\/api\/admin\/modules\/([^\/]+)\/source$/);
    if (sourceMatch) {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const sid = sourceMatch[1];
      const mod = await getModule(sid);
      if (!mod) return json({ error: 'Not found' }, 404);

      if (method === 'GET') {
        if (mod.is_encrypted) return json({ error: '该模块是加密文件，无法在线编辑' }, 400);
        const buf = await env.KV.get(await getFileKey(env,sid), 'arrayBuffer');
        if (!buf) return json({ error: 'File not found' }, 404);
        return json({
          ok: true, id: sid, filename: mod.filename,
          content: new TextDecoder().decode(buf),
          size: buf.byteLength, source_url: mod.source_url || null
        });
      }

      if (method === 'PUT' || method === 'POST') {
        return await withModuleLock(env,'module:'+sid,async()=>{
        const mod=await getModule(sid);
        if(!mod)return json({error:'Not found'},404);
        let name = '', code = '';
        const ctype = request.headers.get('Content-Type') || '';
        if (ctype.indexOf('application/json') >= 0) {
          const body = await request.json().catch(() => ({}));
          name = String(body.name || body.filename || '');
          code = typeof body.code === 'string' ? body.code : '';
        } else {
          const fd = await request.formData();
          name = String(fd.get('name') || fd.get('filename') || '');
          code = String(fd.get('code') || '');
        }
        if (!code.trim()) return json({ error: '内容不能为空' }, 400);


        code = code.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        if (code.length > MAX_SOURCE_BYTES) return json({ error: '源码超过 3 MB，请改用上传方式' }, 413);
        const filename = (name || mod.filename || 'module.js').replace(/[\/\\]/g, '_').trim();
        if (!/\.js$/i.test(filename)) return json({ error: '文件名需要 .js 结尾' }, 400);

        const buf = new TextEncoder().encode(code);
        const head = new Uint8Array(buf.slice(0, METADATA_SCAN_BYTES));
        const meta = parseMeta(filename, head);
        const title = resolveTitle({...mod,filename},meta.title,mod.manifest_title);
        const now = Date.now();
        const enc = isEncrypted(head);
        assertModuleFile(buf);
        const naming=await prepareName(env,sid,mod.filename,{existing:true});
        naming.originals=JSON.stringify([...new Set([...JSON.parse(naming.originals),filename])]);
        const key=await putFile(env,sid,buf,now),hash=toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',buf)));
        await DB.batch([DB.prepare(
          `UPDATE modules SET filename = ?, widget_id = ?, metadata_id = ?, title = ?, version = ?, author = ?,
             file_size = ?, is_encrypted = ?, updated_at = ?, content_hash = ?, file_key=?,code_title=?,title_scan_v1=1,
             generated_filename=0 WHERE id = ?`
        ).bind(
          filename, meta.id || mod.widget_id || mod.id, meta.id || '', title, meta.version || '', meta.author || '',
          buf.byteLength, enc, now,hash,key,cleanTitle(meta.title), sid
        ),nameStatement(env,naming)]).catch(async error=>{await env.KV.delete(key).catch(()=>{});throw error;});
        await DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) VALUES(?,?)').bind(mod.file_key||'file:'+sid,now).run();
        return json({
          ok: true,
          module: {
            id: sid, filename, widget_id: meta.id || mod.widget_id || mod.id, title,
            version: meta.version || '', author: meta.author || '',
            file_size: buf.byteLength, is_encrypted: enc,
            source_url: mod.source_url || null,
            created_at: mod.created_at, updated_at: now
          }
        });
        });
      }
      return json({ error: 'Method not allowed' }, 405);
    }


    if (path === '/api/admin/modules') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);

      if (method === 'GET') return json(await getModules());

      if (method === 'POST') {
        // Compatibility for the backup importer, which already asks for confirmation.
        const fd=await request.formData();
        const files=fd.getAll('files').filter(f=>f instanceof File && f.name);
        if(files.length!==1)return json({error:'批量上传请使用新版上传预览'},428);
        try{
          const preview=await previewUploads(env,files,String(fd.get('group_id')||''),uploadHelpers);
          const row=preview.rows[0];
          if(row.kind==='invalid'||row.kind==='conflict'||row.target?.subscribed)
            return json({error:row.reason||'该模块需要选择替换目标或自动更新方式，请使用上传预览'},409);
          const result=await commitUpload(env,{job_id:preview.job_id,index:0,
            action:row.target?'replace':'new',target_id:row.target?.id,file:files[0]},uploadHelpers);
          return json({...result,added:result.status==='added'?[{id:result.module_id}]:[],replaced:result.status==='replaced'?[{id:result.module_id}]:[]});
        }catch(e){return json({error:String(e.message||e)},400);}
      }

      if (method === 'PATCH') {
        const body = await request.json().catch(() => ({}));
        const id = url.searchParams.get('id');
        if (!id) return json({ error: 'id required' }, 400);
        return await withModuleLock(env,'module:'+id,async()=>{
        const mod = await getModule(id);
        if (!mod) return json({ error: 'Not found' }, 404);
        const requestedTitle=cleanTitle(pickStr(body.title,mod.title,500));
        const locked=body.title_locked===undefined?(body.title!==undefined?1:mod.title_locked):(body.title_locked?1:0);
        if(locked&&!requestedTitle)return json({error:'锁定标题不能为空'},400);
        const title=resolveTitle({...mod,title:requestedTitle,title_locked:locked});
        const version = pickStr(body.version, mod.version, 64);
        const author = pickStr(body.author, mod.author, 120);
        const note = pickStr(body.note, mod.note, 1000);
        const enc = body.is_encrypted === undefined
          ? (Number(mod.is_encrypted) || 0)
          : (body.is_encrypted ? 1 : 0);
        await DB.prepare(
          `UPDATE modules SET title = ?, version = ?, author = ?, note = ?, is_encrypted = ?, updated_at = ?,title_locked=?,
            title_scan_v1=CASE WHEN title_scan_v1=0 THEN -1 ELSE title_scan_v1 END WHERE id = ?`
        ).bind(title, version, author, note, enc, Date.now(),locked, id).run();
        return json({ ok: true });
        });
      }

      if (method === 'PUT') {
        const id = url.searchParams.get('id');
        const mod = await getModule(id);
        if (!mod) return json({ error: 'Not found' }, 404);
        const fd = await request.formData();
        const file = fd.get('file');
        if (!(file instanceof File) || !file.name) return json({ error: 'No file' }, 400);
        if (!/\.js$/i.test(file.name)) return json({ error: '只接受 .js 文件' }, 400);
        if (file.size > MAX_FILE_BYTES) return json({ error: '文件超过 25 MB' }, 413);
        const preview=await previewUploads(env,[file],'',uploadHelpers,id);
        try{return json(await commitUpload(env,{job_id:preview.job_id,index:0,action:'replace',target_id:id,
          mode:String(fd.get('mode')||''),file},uploadHelpers));}
        catch(e){return json({error:String(e.message||e)},400);}
      }

      if (method === 'DELETE') {
        const id = url.searchParams.get('id');
        if(!id)return json({error:'id required'},400);
        return json(await deleteModule(env,id));
      }
    }


    const refreshMatch = path.match(/^\/api\/admin\/modules\/([^\/]+)\/refresh$/);
    if (refreshMatch && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const modId = refreshMatch[1];
      const mod = await getModule(modId);
      if (!mod) return json({ error: 'Not found' }, 404);
      if (!mod.source_url) return json({ error: 'No source URL' }, 400);
      try {
        await refreshModuleFromSource(env, mod, true);
        return json({ ok: true });
      } catch (e) {
        const msg = String((e && e.message) || e);
        return json({ error: msg.indexOf('Failed to fetch') === 0 ? msg : 'Refresh failed: ' + msg }, 400);
      }
    }


    if (path === '/api/admin/hub/build' && method === 'GET') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      let migrationErrors=[];
      try{const r=await DB.prepare("SELECT value FROM settings WHERE key='migration_errors_v1'").first();if(r)migrationErrors=JSON.parse(r.value).errors||[];}catch(e){}
      return json({ build: (env.CF_VERSION_METADATA && env.CF_VERSION_METADATA.id) || '', migrationErrors }, 200, { 'Cache-Control': 'no-store' });
    }
    if (path === '/api/admin/reset' && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const n=await DB.prepare('SELECT COUNT(*) AS n FROM modules').first();
      const now=Date.now();
      await DB.batch([
        DB.prepare("INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT CASE WHEN file_key IS NULL OR file_key='' THEN 'file:'||id ELSE file_key END,? FROM modules").bind(now),
        DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT kv_key,? FROM module_previous_versions').bind(now),
        DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) SELECT kv_key,? FROM icon_assets').bind(now),
        DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('content_generation',?)").bind(crypto.randomUUID()),
        DB.prepare('UPDATE module_share_aliases SET tombstoned=1,is_current=0'),
        DB.prepare('DELETE FROM source_previews'),
        ...['collection_modules','collection_aliases','collections','modules','groups','subscription_items','subscription_sources','module_previous_versions','upload_results','upload_jobs','icon_entries','icon_sources','icon_assets','module_names','collection_options'].map(table=>DB.prepare('DELETE FROM '+table))
      ]);
      env.CONTENT_EPOCH=(env.CONTENT_EPOCH||0)+1;
      const ids={length:n.n};
      return json({ ok: true, removed: ids.length });
    }

    if (path === '/api/admin/change-password' && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const body = await request.json().catch(() => ({}));
      if (!body.password || String(body.password).length < 8) return json({ error: '密码至少 8 位' }, 400);
      await DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
        .bind('admin_password', await hashPassword(String(body.password))).run();

      const me = (request.headers.get('Cookie') || '').match(/fwh_admin=([^;]+)/);
      await DB.prepare('DELETE FROM sessions WHERE token != ?').bind(me ? me[1] : '').run();
      _authCache.clear();
      return json({ ok: true });
    }

    if (path === '/api/admin/modules/reorder' && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const body = await request.json().catch(() => ({}));
      const ids = body.ids || [];
      if (!Array.isArray(ids)) return json({ error: 'ids must be array' }, 400);
      const now = Date.now();
      for (let i = 0; i < ids.length; i += 100) {
        await DB.batch(ids.slice(i, i + 100).map((id, k) =>
          DB.prepare('UPDATE modules SET sort_order = ?, updated_at = ? WHERE id = ?').bind(i + k, now, id)));
      }
      return json({ ok: true, count: ids.length });
    }

    if (path === '/api/admin/groups') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      if (method === 'GET') {
        const r = await DB.prepare('SELECT * FROM groups ORDER BY position, created_at').all();
        return json(r.results || []);
      }
      if (method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const name = (body.name || '').trim();
        if (!name) return json({ error: 'name required' }, 400);
        const id = genId();
        const maxPos = await DB.prepare('SELECT MAX(position) AS mp FROM groups').first();
        await DB.prepare('INSERT INTO groups (id, name, position, created_at) VALUES (?,?,?,?)')
          .bind(id, name, ((maxPos && maxPos.mp) || 0) + 1, Date.now()).run();
        return json({ ok: true, id });
      }
      if (method === 'PATCH') {
        const body = await request.json().catch(() => ({}));
        const id = body.id;
        if (!id) return json({ error: 'id required' }, 400);
        const name = String(body.name || '').trim();
        if (!name) return json({ error: 'name required' }, 400);
        await DB.prepare('UPDATE groups SET name = ? WHERE id = ?').bind(name, id).run();
        return json({ ok: true });
      }
      if (method === 'DELETE') {
        const id = new URL(request.url).searchParams.get('id');
        if (!id) return json({ error: 'id required' }, 400);
        await DB.batch([
          DB.prepare('UPDATE modules SET group_id = ? WHERE group_id = ?').bind('', id),
          DB.prepare('DELETE FROM groups WHERE id = ?').bind(id)
        ]);
        return json({ ok: true });
      }
    }

    if (path === '/api/admin/groups/reorder' && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const body = await request.json().catch(() => ({}));
      const ids = body.ids || [];
      if (!Array.isArray(ids)) return json({ error: 'ids must be array' }, 400);
      for (let i = 0; i < ids.length; i += 100) {
        await DB.batch(ids.slice(i, i + 100).map((id, k) =>
          DB.prepare('UPDATE groups SET position = ? WHERE id = ?').bind(i + k, id)));
      }
      return json({ ok: true, count: ids.length });
    }

    if (path === '/api/admin/modules/group' && method === 'POST') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);
      const body = await request.json().catch(() => ({}));
      try{return json(await bulkManage(env,{action:'group',ids:body.moduleIds||[body.moduleId],groupId:body.groupId||''}));}
      catch(e){return json({error:String(e.message||e)},400);}
    }


    if (path === '/api/admin/collections') {
      if (!await verifyAuth(request)) return json({ error: 'Unauthorized' }, 401);

      if (method === 'GET') return json(await getCollections());

      if (method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const title = (body.title || '').trim();
        if (!title) return json({ error: 'title required' }, 400);
        const slugInput = (body.slug || '').trim();
        if (!slugInput) return json({ error: '路径必填' }, 400);
        if (!/^[A-Za-z0-9]+$/.test(slugInput)) return json({ error: '路径只能是英文字母和数字' }, 400);
        const now = Date.now();
        const id = genId();
        const desc = pickStr(body.description, '', 2000);
        let choice;try{choice=await prepareCollectionIcon(env,body,null);}catch(e){return json({error:e.message},400);}
        const icon=choice?.url||'';await assertStoredIcon(env,icon);
        const initialIds=body.moduleIds===undefined?[]:await validatedMembers(DB,body.moduleIds);
        const initialOption=await collectionOption(DB,id,body.autoAll??false);
        let slug = await ensureUniqueSlug(slugInput);
        for (let attempt = 0; ; attempt++) {
          try {
            await DB.batch([DB.prepare(
              `INSERT INTO collections (id, slug, title, description, icon_url, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?)`
            ).bind(id, slug, pickStr(title, '', 200), desc, icon, now, now),
              ...memberStatements(DB,id,initialIds),initialOption,fillAutoAll(DB,id)]);
            break;
          } catch (e) {
            // 并发建同名路径时 UNIQUE 会撞，重新取一个可用 slug 再试
            if (attempt >= 2 || !/UNIQUE/i.test(String((e && e.message) || e))) throw e;
            slug = await ensureUniqueSlug(slugInput);
          }
        }
        return json({ ok: true, id, slug }, 201);
      }

      if (method === 'PATCH') {
        const body = await request.json().catch(() => ({}));
        return await withModuleLock(env,'collection:'+body.id,async()=>{
        const col = await DB.prepare('SELECT * FROM collections WHERE id = ?').bind(body.id).first();
        if (!col) return json({ error: 'Not found' }, 404);
        if(body.expectedUpdatedAt!==undefined&&body.expectedUpdatedAt!==col.updated_at)return json({error:'合集已被其他操作更新，请重新打开后再保存'},409);
        let choice;try{choice=await prepareCollectionIcon(env,body,col);}catch(e){return json({error:e.message},400);}
        const icon=choice?choice.url:col.icon_url;await assertStoredIcon(env,icon);
        let slug = col.slug;
        if (body.slug !== undefined) {
          const s = String(body.slug).trim();
          if (s && s!==col.slug && !/^[A-Za-z0-9]+$/.test(s)) return json({ error: '路径只能是英文字母和数字' }, 400);
          if (s && s !== col.slug) slug = s;
        }
        const ids=body.moduleIds===undefined?null:await validatedMembers(DB,body.moduleIds);
        try {
          const update=DB.prepare(
            `UPDATE collections SET slug = ?, title = ?, description = ?, icon_url = ?, updated_at = ? WHERE id = ?`
          ).bind(
            slug,
            pickStr(body.title, col.title, 200),
            pickStr(body.description, col.description, 2000),
            icon,
            Date.now(), body.id
          );
          const aliases=await setCollectionSlug(DB,body.id,slug);
          const options=body.autoAll===undefined?[]:[await collectionOption(DB,body.id,body.autoAll)];
          await DB.batch([...aliases,update,...(ids?memberStatements(DB,body.id,ids):[]),...options,fillAutoAll(DB,body.id)]);
        } catch (e) {
          if (/UNIQUE/i.test(String((e && e.message) || e))) return json({ error: '该路径已被占用，请换一个' }, 409);
          throw e;
        }
        return json({ ok: true });
        });
      }

      if (method === 'DELETE') {
        const id = url.searchParams.get('id');
        return await withModuleLock(env,'collection:'+id,async()=>{
        const col = await DB.prepare('SELECT id FROM collections WHERE id = ?').bind(id).first();
        if (!col) return json({ error: 'Not found' }, 404);
        await DB.batch([
          DB.prepare('DELETE FROM collections WHERE id = ?').bind(id),
          DB.prepare('DELETE FROM collection_modules WHERE collection_id = ?').bind(id),
          DB.prepare('DELETE FROM collection_aliases WHERE collection_id = ?').bind(id),
          DB.prepare('DELETE FROM collection_options WHERE collection_id=?').bind(id)
        ]);
        return json({ ok: true });
        });
      }
    }


    const fwdMatch = path.match(/^\/api\/collections\/([^\/]+?)(?:\/(?:fwd|rex)|\.(?:fwd|rex))?$/);
    if (fwdMatch) {
      const col = await findCollectionBySlug(fwdMatch[1]);
      if (!col) return json({ error: 'Not found' }, 404);

      const { results: rows } = await DB.prepare(
        `SELECT m.*, cm.position AS _pos FROM collection_modules cm
           JOIN modules m ON m.id = cm.module_id
         WHERE cm.collection_id = ? ORDER BY cm.position`
      ).bind(col.id).all();

      const decorated = await decorateNames(env,rows || []);
      const widgets = decorated.map((m) => {
        const t = resolveTitle(m);
        return {
          id: m.widget_id || m.id,
          title: t,
          description: m.note || '',
          requiredVersion: m.required_version || '0.0.1',
          version: m.version || '1.0.0',
          author: m.author || '',
          url: url.origin + (m.share_path||modulePath(m))
        };
      });

      const payload = {
        title: col.title,
        description: col.description || '',
        icon: col.icon_url?.startsWith('/api/icons/')?url.origin+col.icon_url:(col.icon_url||''),
        widgets: widgets
      };
      // [自改A1] 合集 ETag 绑定实际清单内容及每个模块的更新时间。
      const collectionEtag = '"' + (await sha256(JSON.stringify({
        title: payload.title,
        description: payload.description,
        icon: payload.icon,
        widgets: payload.widgets,
        moduleUpdatedAt: decorated.map((m) => m.updated_at ?? null)
      }))).slice(0, 32) + '"';
      const collectionHeaders = { 'Cache-Control': 'public, max-age=60, stale-while-revalidate=300', ETag: collectionEtag };
      // [自改A1] 清单未变化时直接返回 304。
      if (a1EtagMatch(request.headers.get('If-None-Match'), collectionEtag)) {
        return new Response(null, { status: 304, headers: { 'Access-Control-Allow-Origin': '*', ...collectionHeaders } });
      }
      // [自改A1] 命中版本化边缘缓存时直接返回缓存清单。
      const cachedCollection = await a1CacheMatch(request, collectionEtag);
      if (cachedCollection) return cachedCollection;
      const collectionResponse = pubJson(payload, 200, collectionHeaders);
      // [自改A1] 未命中时把本版清单写入版本化边缘缓存。
      a1CacheStore(ctx, request, collectionEtag, collectionResponse);
      return collectionResponse;
    }


    const namedMatch=path.match(/^\/api\/modules\/([^/]+)\/file\/[^/]+\.js$/i);
    const rawMatch = namedMatch || path.match(/^\/api\/modules\/([^\/]+?)(?:\.js|\/raw)?$/);
    if (rawMatch) {
      if(!['GET','HEAD'].includes(method))return json({error:'Method not allowed'},405);
      let module=await getModule(rawMatch[1]),alias=null;
      if(!module&&!namedMatch&&!path.endsWith('/raw')){
        alias=await resolveAlias(env,path.slice('/api/modules/'.length));
        if(alias)module=await getModule(alias.module_id);
      }
      if(!module)return json({error:'Not found'},404);
      const kvr = await env.KV.getWithMetadata(await getFileKey(env,module.id), 'stream');
      if (!kvr || !kvr.value) return json({ error: 'File not found' }, 404);
      const meta = kvr.metadata || {};
      const etag = meta.u ? 'W/"' + meta.u + '"' : null;
      const h = {
        'Content-Type': 'application/javascript; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=300, stale-while-revalidate=600'
      };
      if (etag) h.ETag = etag;
      if (etag && a1EtagMatch(request.headers.get('If-None-Match'), etag)) {
        return new Response(null, { status: 304, headers: h });
      }
      // [自改A1] 命中与当前 ETag 对应的边缘缓存时直接返回。
      const cachedModule = await a1CacheMatch(request, etag);
      if (cachedModule) return cachedModule;
      // 只有真正要回内容时才查文件名/分享名（304 与缓存命中不需要这两次查询）。
      const named=(await decorateNames(env,[module]))[0];
      h['Content-Disposition']=contentDisposition(alias?.alias||named.effective_filename);
      const moduleResponse = new Response(method==='HEAD'?null:kvr.value, { headers: h });
      // [自改A1] 未命中时写入与当前 ETag 对应的边缘缓存。
      a1CacheStore(ctx, request, etag, moduleResponse);
      return moduleResponse;
    }


    const directMatch = path.match(/^\/([a-f0-9-]{36})(?:\.js)?$/);
    if (directMatch) {
      if(!['GET','HEAD'].includes(method))return json({error:'Method not allowed'},405);
      const module=await getModule(directMatch[1]);if(!module)return json({error:'Not found'},404);
      const kvr = await env.KV.getWithMetadata(await getFileKey(env,directMatch[1]), 'stream');
      if (kvr && kvr.value) {
        const meta = kvr.metadata || {};
        const h = {
          'Content-Type': 'application/javascript; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'public, max-age=300, stale-while-revalidate=600'
        };
        const etag = meta.u ? 'W/"' + meta.u + '"' : null;
        if (etag) h.ETag = etag;
        // [自改A1] 直达链接补齐 If-None-Match 校验，命中返回 304。
        if (etag && a1EtagMatch(request.headers.get('If-None-Match'), etag)) {
          return new Response(null, { status: 304, headers: h });
        }
        // [自改A1] 命中与当前 ETag 对应的边缘缓存时直接返回。
        const cachedDirect = await a1CacheMatch(request, etag);
        if (cachedDirect) return cachedDirect;
        const named=(await decorateNames(env,[module]))[0];
        h['Content-Disposition']=contentDisposition(named.effective_filename);
        const directResponse = new Response(method==='HEAD'?null:kvr.value, { headers: h });
        // [自改A1] 未命中时写入与当前 ETag 对应的边缘缓存。
        a1CacheStore(ctx, request, etag, directResponse);
        return directResponse;
      }
    }

    if (path.startsWith('/api/')) {
      return new Response('Not found', { status: 404, headers: { 'Access-Control-Allow-Origin': '*' } });
    }
    // 只有首页返回界面；其余路径按 404 处理，避免任意路径都回一页 200 HTML
    if (path === '/' || path === '/index.html') {
      return new Response(HTML, { headers: htmlHeaders() });
    }
    return new Response('Not found', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }
    });
    } catch (err) {
      const rid = Date.now().toString(36);
      console.error('[fatal][' + rid + ']', (err && err.stack) || err);
      return json({ error: 'Internal error', ref: rid }, 500);
    }
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil((async () => {
      await bootstrap(env);
      // 互不依赖的维护任务并行跑；任一失败不拖累其余，全部跑完后再抛出第一个错误（不静默）。
      const settled=await Promise.allSettled([backfillTitles(env,2),cleanupUploadJobs(env),cleanupRestoreJobs(env),iconTick(env),autoRulesTick(env)]);
      const failed=settled.find(r=>r.status==='rejected');
      for(const r of settled)if(r.status==='rejected')console.log('[scheduled]',String(r.reason?.message||r.reason));
      const syncing=await subscriptionTick(env,subscriptionHelpers);
      if (!syncing) await autoRefreshLinkModules(env);
      if (failed) throw failed.reason;
    })());
  }
};

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...extraHeaders } });
}
function pickStr(v, fallback, max) {
  if (typeof v !== 'string') return fallback;
  return max && v.length > max ? v.slice(0, max) : v;
}

function pubJson(data, status = 200, extraHeaders = {}) {
  return json(data, status, { 'Access-Control-Allow-Origin': '*', ...extraHeaders });
}
async function sha256(t) {
  const d = new TextEncoder().encode(t);
  const h = await crypto.subtle.digest('SHA-256', d);
  return Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function a1EtagMatch(header, etag) {
  // [自改A2] If-None-Match 按弱比较：忽略 W/ 前缀、支持逗号列表与 *。
  // 原因：Cloudflare 压缩响应时会把强 ETag 改成 W/"…"，严格相等会让合集清单永远回不了 304。
  if (!header || !etag) return false;
  const norm = (v) => String(v).trim().replace(/^W\//, '');
  const want = norm(etag);
  return String(header).split(',').some((t) => { const v = t.trim(); return v === '*' || norm(v) === want; });
}
function a1CacheRequest(request, etag) {
  // [自改A1] 以原 URL 加 ETag 组成版本化缓存键，内容变化时自然换键。
  const keyUrl = new URL(request.url);
  keyUrl.searchParams.set('__a1_etag', String(etag).replace(/[^A-Za-z0-9._-]/g, '_'));
  return new Request(keyUrl.toString(), { method: 'GET' });
}
async function a1CacheMatch(request, etag) {
  // [自改A1] 仅在 Cache API 可用时读边缘缓存；Docker/Node 无 caches 时保持原行为。
  if (request.method !== 'GET' || !etag || typeof caches === 'undefined' || !caches.default) return null;
  try { return await caches.default.match(a1CacheRequest(request, etag)); } catch { return null; }
}
function a1CacheStore(ctx, request, etag, response) {
  // [自改A1] 仅缓存 GET 200 响应，304 与其他状态不写入缓存。
  if (request.method !== 'GET' || !etag || response.status !== 200 || typeof caches === 'undefined' || !caches.default || !ctx || typeof ctx.waitUntil !== 'function') return;
  try { ctx.waitUntil(Promise.resolve(caches.default.put(a1CacheRequest(request, etag), response.clone())).catch(() => {})); } catch {}
}
function genId() { return crypto.randomUUID(); }

function parseMeta(fn, head) {
  return parseModuleMeta(fn,head);
}
function isEncrypted(buf) {
  // 唯一标准：首行固定为 REXENC 标记
  let head;
  try {
    head = new TextDecoder('utf-8').decode(buf.slice(0, 32));
  } catch (e) { return 0; }
  return head.split('\n')[0].replace(/^\uFEFF/, '').trim() === 'REXENC' ? 1 : 0;
}

export async function refreshModuleFromSource(env,original,force=false) {
  const info={},buf=await fetchCapped(original.source_url,MAX_FILE_BYTES,info);
  assertModuleFile(new Uint8Array(buf),info.contentType);
  return withModuleLock(env,'module:'+original.id,async()=>{
    const mod=await env.DB.prepare('SELECT * FROM modules WHERE id=?').bind(original.id).first();
    if(!mod||(!force&&mod.manual_override)||mod.updated_at!==original.updated_at||mod.file_key!==original.file_key||mod.source_url!==original.source_url)throw Error('下载期间模块已变化，已取消旧更新');
    const head=new Uint8Array(buf.slice(0,METADATA_SCAN_BYTES)),meta=parseMeta(mod.filename,head),now=Date.now();
    const hash=toHex(new Uint8Array(await crypto.subtle.digest('SHA-256',buf)));
    const key=mod.content_hash===hash&&mod.file_key?mod.file_key:await putFile(env,mod.id,buf,now);
    try{await env.DB.prepare("UPDATE modules SET title=?,version=?,author=?,file_size=?,is_encrypted=?,updated_at=?,file_key=?,content_hash=?,code_title=?,title_scan_v1=1 WHERE id=?")
      .bind(resolveTitle(mod,meta.title,mod.manifest_title),meta.version||'',meta.author||'',buf.byteLength,isEncrypted(head),now,key,hash,cleanTitle(meta.title),mod.id).run();}
    catch(e){if(key!==mod.file_key)await env.KV.delete(key).catch(()=>{});throw e;}
    if(key!==mod.file_key)await env.DB.prepare('INSERT OR IGNORE INTO resource_gc(kv_key,created_at) VALUES(?,?)').bind(mod.file_key||'file:'+mod.id,now).run();
  });
}

export { parseMeta, isEncrypted };
export function getHTML(){return HTML;}

const REFRESH_BATCH = 4;
const REFRESH_CONC  = 4;
async function autoRefreshLinkModules(env) {
  try {
    const { results } = await env.DB.prepare(
      "SELECT * FROM modules WHERE source_url IS NOT NULL AND source_url != '' AND source_managed=0 AND manual_override=0 AND updated_at<? ORDER BY updated_at ASC LIMIT ?"
    ).bind(Date.now()-6*60*60*1000,REFRESH_BATCH).all();
    const list = results || [];
    let ok = 0, fail = 0, i = 0;
    async function worker() {
      while (i < list.length) {
        const mod = list[i++];
        try { await refreshModuleFromSource(env, mod); ok++; }
        catch (e) {
          fail++;
          console.log('[auto-refresh] failed: ' + (mod.filename || mod.id) + ' - ' + String((e && e.message) || e));
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(REFRESH_CONC, list.length) }, worker));
    console.log('[auto-refresh] done: ok=' + ok + ' fail=' + fail + ' total=' + list.length);
  } catch (e) {
    console.log('[auto-refresh] fatal: ' + String((e && e.message) || e));
  }
}

const TICK_PATH='/__hub_coordinator_tick';
export class HubCoordinator {
  constructor(ctx,env){
    this.ctx=ctx;this.queue=new WriteQueue();this.env={...env,ATOMIC:work=>this.queue.run(work)};
    this.ready=bootstrap(this.env);
  }
  async fetch(request){
    try{await this.ready;}catch(e){return json({error:'数据库初始化失败：'+e.message},500);}
    if(new URL(request.url).pathname===TICK_PATH){
      if(this.queue.pending)return new Response('busy',{status:202});
      return this.queue.run(async()=>{
        const pending=[];await application.scheduled({},this.env,{waitUntil:p=>pending.push(p)});
        await Promise.all(pending);return new Response('ok');
      });
    }
    const work=async()=>{const response=await application.fetch(request,this.env,this.ctx);if(response.hubCompletion)this.ctx.waitUntil(response.hubCompletion);return response;};
    // Download up to three previews concurrently; only their publication takes
    // the shared writer lock. The icon library rechecks the reset/restore epoch.
    if(request.method==='POST'&&/^\/api\/admin\/icons\/[a-f0-9]{64}\/cache$/.test(new URL(request.url).pathname))return work();
    const backup=new URL(request.url).pathname==='/api/admin/backup';
    if(!['GET','HEAD','OPTIONS'].includes(request.method)||backup){
      const result=this.queue.run(work);this.ctx.waitUntil(result);return result;
    }
    return work();
  }
}
function coordinator(env){if(!env.COORDINATOR)throw Error('未绑定 HubCoordinator，拒绝绕过并发保护');return env.COORDINATOR.get(env.COORDINATOR.idFromName('widget-hub-primary'));}
export default {
  async fetch(request,env,ctx){
    const resource=await pwaResponse(request,env);if(resource)return resource;
    const path=new URL(request.url).pathname;
    if(path==='/'||path==='/index.html')return new Response(request.method==='HEAD'?null:HTML,{headers:htmlHeaders()});
    if(path===TICK_PATH)return new Response('Not found',{status:404});
    try{return await coordinator(env).fetch(request);}catch(e){console.error('[coordinator]',e.message);return json({error:'后台暂时不可用，请稍后重试'},503);}
  },
  async scheduled(event,env,ctx){ctx.waitUntil(coordinator(env).fetch(new Request('https://coordinator.internal'+TICK_PATH,{method:'POST'})).then(r=>{if(!r.ok)throw Error('后台同步失败：'+r.status);}));}
};
