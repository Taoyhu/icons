// Icon catalogs and immutable, content-addressed images. No module code executes.
import {createHash} from 'node:crypto';
import {fetchRemote,assertFetchableUrl} from './remote.js';

export const ICON_LIMITS={sources:20,entries:2000,manifest:1024*1024,image:2*1024*1024,assets:128*1024*1024};
export const ICON_DAY=86400000;
export const iconSchema=[
  `CREATE TABLE IF NOT EXISTS icon_sources(id TEXT PRIMARY KEY,url TEXT UNIQUE NOT NULL,name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,etag TEXT DEFAULT '',last_modified TEXT DEFAULT '',last_attempt_at INTEGER DEFAULT 0,
    last_success_at INTEGER DEFAULT 0,next_sync_at INTEGER DEFAULT 0,last_error TEXT DEFAULT '',failures INTEGER DEFAULT 0,
    lease_token TEXT DEFAULT '',lease_until INTEGER DEFAULT 0,revision TEXT DEFAULT '',created_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS icon_entries(id TEXT PRIMARY KEY,source_id TEXT NOT NULL,url TEXT NOT NULL,name TEXT NOT NULL,
    position INTEGER NOT NULL,active INTEGER DEFAULT 1,asset_hash TEXT DEFAULT '',cached_at INTEGER DEFAULT 0,
    UNIQUE(source_id,url))`,
  `CREATE INDEX IF NOT EXISTS idx_icon_entries_source ON icon_entries(source_id,active,position)`,
  `CREATE TABLE IF NOT EXISTS icon_assets(hash TEXT PRIMARY KEY,mime TEXT NOT NULL,ext TEXT NOT NULL,
    size INTEGER NOT NULL,kv_key TEXT NOT NULL,created_at INTEGER NOT NULL,last_used_at INTEGER NOT NULL)`
];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
export const iconPath=asset=>'/api/icons/'+asset.hash+'.'+asset.ext;
const atomic=(env,work)=>env.ATOMIC?env.ATOMIC(work):work();
function sourceUrl(env,raw){if(typeof raw!=='string'||raw.length>2048)throw Error('图标地址无效');return (env.SOURCE_URL_POLICY?.assertUrl(raw)||assertFetchableUrl(raw)).href;}
function name(value,fallback=''){if(typeof value!=='string')value=fallback;value=value.trim();if(!value||value.length>200||/[\u0000-\u001f]/.test(value))throw Error('图标名称无效（最多 200 字）');return value;}
export function parseIconManifest(env,bytes){
  if(bytes.length>ICON_LIMITS.manifest)throw Error('图标清单超过 1 MiB');
  let data;try{data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw Error('图标清单不是有效 JSON');}
  if(!data||Array.isArray(data)||!Array.isArray(data.icons)||!data.icons.length||data.icons.length>ICON_LIMITS.entries)throw Error('图标清单需包含 1–2000 项 icons 数组');
  const title=name(data.name,'图标集'),seen=new Set(),items=[];
  for(const item of data.icons){if(!item||typeof item!=='object')throw Error('图标条目无效');const url=sourceUrl(env,item.url),label=name(item.name);
    if(!seen.has(url)){seen.add(url);items.push({name:label,url});}}
  return {name:title,items};
}

// Validate containers and dimensions before serving as an image. SVG is excluded.
export function validateIcon(bytes,type=''){
  bytes=Buffer.from(bytes);if(!bytes.length||bytes.length>ICON_LIMITS.image)throw Error('图片为空或超过 2 MiB');
  let mime,ext,width=0,height=0;
  if(bytes.length>=45&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))){
    if(bytes.readUInt32BE(8)!==13||bytes.toString('ascii',12,16)!=='IHDR')throw Error('PNG 结构无效');
    width=bytes.readUInt32BE(16);height=bytes.readUInt32BE(20);let offset=8,ended=false,hasData=false;
    while(offset+12<=bytes.length){const len=bytes.readUInt32BE(offset);if(len>bytes.length-offset-12)throw Error('PNG 数据不完整');const chunk=bytes.toString('ascii',offset+4,offset+8);
      if(chunk==='IDAT'&&len)hasData=true;offset+=len+12;if(chunk==='IEND'){if(len!==0||offset!==bytes.length)throw Error('PNG 结束标记无效');ended=true;break;}}
    if(!ended||!hasData)throw Error('PNG 数据不完整');mime='image/png';ext='png';
  }else if(bytes.length>=12&&bytes[0]===255&&bytes[1]===216&&bytes.at(-2)===255&&bytes.at(-1)===217){
    let p=2;while(p+4<bytes.length){if(bytes[p++]!==255)break;let marker=bytes[p++];while(marker===255)marker=bytes[p++];if(marker===0xda||marker===0xd9)break;
      if(marker===0x01||(marker>=0xd0&&marker<=0xd7))continue;const len=bytes.readUInt16BE(p);if(len<2||p+len>bytes.length)break;
      if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)&&len>=8){height=bytes.readUInt16BE(p+3);width=bytes.readUInt16BE(p+5);break;}p+=len;}
    mime='image/jpeg';ext='jpg';
  }else if(bytes.length>=30&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP'&&bytes.readUInt32LE(4)===bytes.length-8){
    const chunk=bytes.toString('ascii',12,16);if(chunk==='VP8X'){width=1+bytes.readUIntLE(24,3);height=1+bytes.readUIntLE(27,3);}
    else if(chunk==='VP8L'&&bytes[20]===0x2f){const bits=bytes.readUInt32LE(21);width=(bits&0x3fff)+1;height=((bits>>>14)&0x3fff)+1;}
    else if(chunk==='VP8 '&&bytes[23]===0x9d&&bytes[24]===1&&bytes[25]===0x2a){width=bytes.readUInt16LE(26)&0x3fff;height=bytes.readUInt16LE(28)&0x3fff;}
    mime='image/webp';ext='webp';
  }
  const declared=type.split(';')[0].trim().toLowerCase().replace('image/jpg','image/jpeg');
  if(!mime||!width||!height||width>8192||height>8192||width*height>16777216)throw Error('仅支持有效的 PNG/JPEG/WebP 图片（最多 1600 万像素）');
  if(declared&&declared!=='application/octet-stream'&&declared!==mime)throw Error('图片内容与 Content-Type 不匹配');
  return {hash:hash(bytes),mime,ext,size:bytes.length,bytes};
}

const runtime=new WeakMap();
function state(env){if(!runtime.has(env))runtime.set(env,{sync:new Map(),cache:new Map(),active:0,waiting:[]});return runtime.get(env);}
async function limited(env,work){const s=state(env);if(s.active>=3)await new Promise(r=>s.waiting.push(r));else s.active++;
  try{env.SHUTDOWN_SIGNAL?.throwIfAborted();return await work();}finally{const next=s.waiting.shift();if(next)next();else s.active--;}}
async function remote(env,url,max,options={}){return fetchRemote(url,max,{...options,signal:env.SHUTDOWN_SIGNAL,transport:env.REMOTE_FETCH||fetch,assertUrl:raw=>new URL(sourceUrl(env,raw))});}
export async function listIconSources(env){return (await env.DB.prepare(`SELECT s.*,COUNT(e.id) AS count FROM icon_sources s
  LEFT JOIN icon_entries e ON e.source_id=s.id AND e.active=1 GROUP BY s.id ORDER BY s.created_at,s.id`).all()).results.map(({lease_token,...s})=>({...s,syncing:s.lease_until>Date.now()}));}
export async function addIconSource(env,body){const url=sourceUrl(env,body.url);const id=crypto.randomUUID(),now=Date.now();
  await atomic(env,async()=>{if((await env.DB.prepare('SELECT COUNT(*) AS n FROM icon_sources').first()).n>=ICON_LIMITS.sources)throw Error('最多支持 20 个图标源');
    const existing=await env.DB.prepare('SELECT id FROM icon_sources WHERE url=?').bind(url).first();if(existing)throw Error('该图标源已存在');
    await env.DB.prepare('INSERT INTO icon_sources(id,url,name,created_at,next_sync_at) VALUES(?,?,?,?,?)').bind(id,url,name(body.name,'图标集'),now,now).run();});
  const result=await refreshIconSource(env,id);return {ok:true,id,...result};
}
export async function changeIconSource(env,id,body){return atomic(env,async()=>{
  const s=await env.DB.prepare('SELECT * FROM icon_sources WHERE id=?').bind(id).first();if(!s)throw Error('图标源不存在');
  if(body.url!==undefined&&sourceUrl(env,body.url)!==s.url)throw Error('修改链接请新建图标源，以保留原图标身份');
  if(body.enabled!==undefined&&typeof body.enabled!=='boolean')throw Error('enabled 必须是布尔值');
  await env.DB.prepare("UPDATE icon_sources SET name=?,enabled=?,lease_token='',lease_until=0,next_sync_at=? WHERE id=?")
    .bind(body.name===undefined?s.name:name(body.name),body.enabled===undefined?s.enabled:Number(body.enabled),Date.now(),id).run();return {ok:true};});}
export async function deleteIconSource(env,id){return atomic(env,async()=>{await env.DB.batch([
  env.DB.prepare('DELETE FROM icon_entries WHERE source_id=?').bind(id),env.DB.prepare('DELETE FROM icon_sources WHERE id=?').bind(id)]);return {ok:true};});}
export function refreshIconSource(env,id){const jobs=state(env).sync;if(jobs.has(id))return jobs.get(id);
  const job=doRefresh(env,id).finally(()=>jobs.delete(id));jobs.set(id,job);return job;}
async function doRefresh(env,id){const now=Date.now(),token=crypto.randomUUID(),epoch=env.CONTENT_EPOCH||0;
  const s=await atomic(env,async()=>{const row=await env.DB.prepare('SELECT * FROM icon_sources WHERE id=?').bind(id).first();if(!row)throw Error('图标源不存在');
    if(row.lease_until>now)throw Error('图标源正在同步，请稍后重试');await env.DB.prepare('UPDATE icon_sources SET lease_token=?,lease_until=?,last_attempt_at=? WHERE id=?').bind(token,now+60000,now,id).run();return row;});
  try{
    const headers={};if(s.last_success_at){if(s.etag)headers['If-None-Match']=s.etag;if(s.last_modified)headers['If-Modified-Since']=s.last_modified;}
    const response=await remote(env,s.url,ICON_LIMITS.manifest,{headers,allowNotModified:!!s.last_success_at});
    const parsed=response.status===304?null:parseIconManifest(env,response.bytes);
    return await atomic(env,async()=>{
      const current=await env.DB.prepare('SELECT lease_token FROM icon_sources WHERE id=?').bind(id).first();if(current?.lease_token!==token||epoch!==(env.CONTENT_EPOCH||0))throw Error('图标同步已被取消');
      const statements=[];
      if(parsed){
        const items=parsed.items.map((item,i)=>({id:hash(id+'\0'+item.url),url:item.url,name:item.name,position:i}));
        statements.push(env.DB.prepare("UPDATE icon_entries SET active=0 WHERE source_id=?").bind(id));
        for(let i=0;i<items.length;i+=100)statements.push(env.DB.prepare(
          "INSERT INTO icon_entries(id,source_id,url,name,position,active) SELECT json_extract(value,'$.id'),?,json_extract(value,'$.url'),json_extract(value,'$.name'),json_extract(value,'$.position'),1 FROM json_each(?) WHERE 1 ON CONFLICT(source_id,url) DO UPDATE SET name=excluded.name,position=excluded.position,active=1"
        ).bind(id,JSON.stringify(items.slice(i,i+100))));
        statements.push(env.DB.prepare('DELETE FROM icon_entries WHERE source_id=? AND active=0').bind(id));
        statements.push(env.DB.prepare("UPDATE icon_entries SET asset_hash='',cached_at=0 WHERE source_id=?").bind(id));
      }
      statements.push(env.DB.prepare("UPDATE icon_sources SET etag=?,last_modified=?,last_success_at=?,next_sync_at=?,last_error='',failures=0,lease_token='',lease_until=0,revision=? WHERE id=?")
        .bind(response.etag||(parsed?'':s.etag),response.lastModified||(parsed?'':s.last_modified),Date.now(),Date.now()+ICON_DAY,parsed?token:s.revision,id));
      await env.DB.batch(statements);
      const count=(await env.DB.prepare('SELECT COUNT(*) AS n FROM icon_entries WHERE source_id=? AND active=1').bind(id).first()).n;
      // Preserve administrator-defined names; fill the default from the manifest only.
      if(parsed&&s.name==='图标集')await env.DB.prepare('UPDATE icon_sources SET name=? WHERE id=?').bind(parsed.name,id).run();
      return {synced:true,count,notModified:response.status===304};});
  }catch(error){await atomic(env,()=>env.DB.prepare(`UPDATE icon_sources SET last_error=?,failures=failures+1,
    next_sync_at=?,lease_token='',lease_until=0 WHERE id=? AND lease_token=?`).bind(String(error.message).slice(0,500),Date.now()+Math.min(ICON_DAY,300000*2**Math.min(s.failures,8)),id,token).run());
    return {synced:false,error:error.message};}
}

const aliases={'蓝色':'blue','绿色':'green','紫色':'purple','红色':'red','橙色':'orange','黄色':'yellow','黑色':'black','白色':'white','彩虹':'rainbow'};
export async function queryIcons(env,params){let q=String(params.get('q')||'').slice(0,200).trim().toLowerCase();for(const [key,value] of Object.entries(aliases))q=q.replaceAll(key,value);
  const source=params.get('source')||'',page=Math.max(1,Math.min(2000,Number(params.get('page'))||1))|0;
  const preview=!!source&&params.get('preview')==='1';
  const requested=Number(params.get('size'));
  const size=preview&&Number.isInteger(requested)&&requested>0?Math.min(60,requested):12;
  const where=(preview?'':'s.enabled=1 AND ')+"e.active=1 AND (?='' OR e.source_id=?) AND (?='' OR instr(lower(e.name),?)>0)";
  const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM icon_entries e JOIN icon_sources s ON s.id=e.source_id WHERE '+where).bind(source,source,q,q).first();
  const result=(await env.DB.prepare('SELECT e.*,s.name AS source_name,a.ext FROM icon_entries e JOIN icon_sources s ON s.id=e.source_id LEFT JOIN icon_assets a ON a.hash=e.asset_hash WHERE '+where+' ORDER BY s.created_at,s.id,e.position,e.id LIMIT ? OFFSET ?').bind(source,source,q,q,size,(page-1)*size).all()).results;
  const cached=result.filter(e=>e.ext);
  if(!preview&&cached.length)await env.DB.prepare('UPDATE icon_assets SET last_used_at=? WHERE hash IN (SELECT value FROM json_each(?))').bind(Date.now(),JSON.stringify(cached.map(e=>e.asset_hash))).run();
  return {total:count.n,page,pages:Math.max(1,Math.ceil(count.n/size)),items:result.map(e=>({...e,preview_url:e.ext?iconPath({hash:e.asset_hash,ext:e.ext}):''}))};
}
export async function cleanupIcons(env,needed=0){return atomic(env,async()=>{
  const rows=(await env.DB.prepare(`WITH pinned(url) AS (
    SELECT COALESCE(icon_url,'') FROM collections
    UNION SELECT COALESCE(json_extract(CASE WHEN json_valid(summary) THEN summary ELSE '{}' END,'$.custom_icon_url'),'') FROM subscription_sources
  ) SELECT a.hash,a.kv_key,a.size,a.last_used_at FROM icon_assets a
    WHERE ('/api/icons/'||a.hash||'.'||a.ext) NOT IN (SELECT url FROM pinned) ORDER BY a.last_used_at`).all()).results;
  let total=(await env.DB.prepare('SELECT COALESCE(SUM(size),0) AS n FROM icon_assets').first()).n;
  for(const row of rows){if(total+needed<=ICON_LIMITS.assets&&row.last_used_at>Date.now()-30*ICON_DAY)continue;
    await env.DB.prepare('DELETE FROM icon_assets WHERE hash=?').bind(row.hash).run();await env.KV.delete(row.kv_key).catch(()=>{});await env.DB.prepare("UPDATE icon_entries SET asset_hash='',cached_at=0 WHERE asset_hash=?").bind(row.hash).run();total-=row.size;}
  if(total+needed>ICON_LIMITS.assets)throw Error('图标缓存已满（128 MiB），不会删除合集或订阅正在使用的图片');return total;});}
async function storeAsset(env,asset){
  const exists=await env.DB.prepare('SELECT hash,kv_key FROM icon_assets WHERE hash=?').bind(asset.hash).first();
  if(exists){await env.DB.prepare('UPDATE icon_assets SET last_used_at=? WHERE hash=?').bind(Date.now(),asset.hash).run();return asset;}
  await cleanupIcons(env,asset.size);const now=Date.now(),key='icon:'+asset.hash+':'+crypto.randomUUID();
  await env.KV.put(key,asset.bytes,{metadata:{s:asset.size}});
  try{await env.DB.prepare('INSERT INTO icon_assets(hash,mime,ext,size,kv_key,created_at,last_used_at) VALUES(?,?,?,?,?,?,?)')
    .bind(asset.hash,asset.mime,asset.ext,asset.size,key,now,now).run();}
  catch(e){await env.KV.delete(key).catch(()=>{});throw e;}
  return asset;
}
export async function cacheIcon(env,id){const jobs=state(env).cache,key='entry:'+id;if(jobs.has(key))return jobs.get(key);
  const job=limited(env,async()=>{
    const e=await env.DB.prepare('SELECT e.*,s.revision AS source_revision FROM icon_entries e JOIN icon_sources s ON s.id=e.source_id WHERE e.id=? AND e.active=1 AND s.enabled=1').bind(id).first();if(!e)throw Error('图标已下架或图标源已停用');
    const cached=e.asset_hash&&await env.DB.prepare('SELECT hash,mime,ext,size FROM icon_assets WHERE hash=?').bind(e.asset_hash).first();if(cached)return {...cached,url:iconPath(cached)};
    const epoch=env.CONTENT_EPOCH||0,response=await remote(env,e.url,ICON_LIMITS.image),asset=validateIcon(response.bytes,response.contentType);
    return atomic(env,async()=>{const current=await env.DB.prepare(`SELECT e.*,s.revision AS source_revision FROM icon_entries e JOIN icon_sources s ON s.id=e.source_id
      WHERE e.id=? AND e.active=1 AND s.enabled=1`).bind(id).first();if(!current||current.source_revision!==e.source_revision||epoch!==(env.CONTENT_EPOCH||0))throw Error('图标下载已被取消，请重新选择');
      await storeAsset(env,asset);await env.DB.prepare('UPDATE icon_entries SET asset_hash=?,cached_at=? WHERE id=?').bind(asset.hash,Date.now(),id).run();return {hash:asset.hash,mime:asset.mime,ext:asset.ext,url:iconPath(asset)};});
  }).finally(()=>jobs.delete(key));jobs.set(key,job);return job;
}
export async function prepareCollectionIcon(env,body,current){
  const hasEntry=Object.hasOwn(body,'icon_entry_id'),hasUrl=Object.hasOwn(body,'icon_url');if(!hasEntry&&!hasUrl)return null;
  if(hasEntry&&body.icon_entry_id){if(typeof body.icon_entry_id!=='string'||(hasUrl&&body.icon_url))throw Error('请只选择图标库或图片 URL 中的一种');return {url:(await cacheIcon(env,body.icon_entry_id)).url};}
  if(hasEntry&&!hasUrl){if(body.icon_entry_id!==null&&body.icon_entry_id!=='')throw Error('图标选择无效');return {url:''};}
  if(typeof body.icon_url!=='string')throw Error('图标 URL 无效');const url=body.icon_url.trim();if(!url)return {url:''};
  if(url===current?.icon_url)return null; // A metadata-only edit never migrates old external icons.
  const local=url.match(/^\/api\/icons\/([a-f0-9]{64})\.(png|jpg|webp)$/);if(local){const row=await env.DB.prepare('SELECT hash FROM icon_assets WHERE hash=? AND ext=?').bind(local[1],local[2]).first();if(!row)throw Error('缓存图标不存在');return {url};}
  sourceUrl(env,url);const epoch=env.CONTENT_EPOCH||0;const response=await limited(env,()=>remote(env,url,ICON_LIMITS.image)),asset=validateIcon(response.bytes,response.contentType);
  return atomic(env,async()=>{if(epoch!==(env.CONTENT_EPOCH||0))throw Error('图标下载已被取消');await storeAsset(env,asset);return {url:iconPath(asset)};});
}
export async function iconTick(env){const row=await env.DB.prepare('SELECT id FROM icon_sources WHERE enabled=1 AND next_sync_at<=? AND lease_until<? ORDER BY next_sync_at LIMIT 1').bind(Date.now(),Date.now()).first();
  if(row)await refreshIconSource(env,row.id);await cleanupIcons(env);}
export async function iconResponse(env,path,request){const match=path.match(/^\/api\/icons\/([a-f0-9]{64})\.(png|jpg|webp)$/);if(!match)return new Response('Not found',{status:404});
  const asset=await env.DB.prepare('SELECT * FROM icon_assets WHERE hash=? AND ext=?').bind(match[1],match[2]).first();if(!asset)return new Response('Not found',{status:404});
  const headers={'Content-Type':asset.mime,'Content-Length':String(asset.size),'Cache-Control':'public, max-age=31536000, immutable','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'*',ETag:'"'+asset.hash+'"'};
  if(request.headers.get('if-none-match')===headers.ETag)return new Response(null,{status:304,headers});
  const bytes=request.method==='HEAD'?null:await env.KV.get(asset.kv_key,'stream');
  if(request.method!=='HEAD'&&!bytes)return new Response('Image unavailable',{status:503,headers:{'Cache-Control':'no-store'}});
  return new Response(bytes,{headers});}

export async function assertStoredIcon(env,url){if(!url?.startsWith('/api/icons/'))return;const row=await env.DB.prepare("SELECT hash FROM icon_assets WHERE '/api/icons/'||hash||'.'||ext=?").bind(url).first();if(!row)throw Error('图片缓存已被回收，请重新选择图标');
  await env.DB.prepare('UPDATE icon_assets SET last_used_at=? WHERE hash=?').bind(Date.now(),row.hash).run();}
// Backup code streams the KV bytes separately; D1 contains metadata only.
export async function exportIcons(env){
  const sources=(await env.DB.prepare('SELECT * FROM icon_sources').all()).results.map(({lease_token,lease_until,...s})=>s);
  const entries=(await env.DB.prepare('SELECT * FROM icon_entries').all()).results;
  const assets=(await env.DB.prepare('SELECT * FROM icon_assets').all()).results;
  return {sources,entries,assets};
}

