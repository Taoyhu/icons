import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {managementUI} from './management-ui.js';

function functionSource(start,end){return managementUI.slice(managementUI.indexOf(start),managementUI.indexOf(end));}
test('batch UI keeps failures selected, clears successful items, and retries in bounded chunks',async()=>{
 const calls=[],ids=Array.from({length:7},(_,i)=>String(i));
 const ctx={bulkBusy:false,selectedModuleIds:new Set(ids),state:{modules:[]},document:{getElementById(){return null;}},renderBulkBar(){},loadAll:async()=>{},showModal(){},toast(){},esc:x=>x,
  api:async(path,{json})=>{calls.push(json.ids);return {ok:true,results:json.ids.map(id=>({id,ok:id!=='3',error:'test failure'}))};}};
 vm.createContext(ctx);vm.runInContext(functionSource('async function runManagedBulk','function chooseBulkTarget'),ctx);
 assert.equal(await ctx.runManagedBulk(ids,'delete'),false);
 assert.deepEqual(calls.map(c=>c.length),[2,2,2,1]);assert.deepEqual([...ctx.selectedModuleIds],['3']);assert.equal(ctx.bulkBusy,false);
 calls.length=0;ctx.api=async(path,{json})=>{calls.push(json.ids);return {ok:true,results:json.ids.map(id=>({id,ok:true}))};};
 assert.equal(await ctx.runManagedBulk([...ctx.selectedModuleIds],'delete'),true);assert.deepEqual(calls,[['3']]);assert.equal(ctx.selectedModuleIds.size,0);
});
test('unconfirmed batch responses preserve every affected selection for retry',async()=>{
 const ctx={bulkBusy:false,selectedModuleIds:new Set(['a','b']),state:{modules:[]},document:{getElementById(){return null;}},renderBulkBar(){},loadAll:async()=>{},showModal(){},toast(){},esc:x=>x,api:async()=>{throw Error('network failure');}};
 vm.createContext(ctx);vm.runInContext(functionSource('async function runManagedBulk','function chooseBulkTarget'),ctx);
 await ctx.runManagedBulk(['a','b'],'append',{collectionId:'mine'});assert.deepEqual([...ctx.selectedModuleIds],['a','b']);assert.equal(ctx.bulkBusy,false);
});
test('Rex import encodes public URL once and never claims a successful client import',()=>{
 const messages=[],ctx={window:{location:{href:''}},toast:m=>messages.push(m)};
 vm.createContext(ctx);vm.runInContext(functionSource('function importToRex','var selectButton'),ctx);
 const url='https://example.com/api/collections/中文.rex?x=a&y=b';ctx.importToRex(url);
 assert.equal(ctx.window.location.href,'rex://widget?url='+encodeURIComponent(url));assert.match(messages[0],/尝试/);assert.doesNotMatch(messages[0],/导入成功/);
 ctx.window.location.href='';ctx.importToRex('javascript:alert(1)');assert.equal(ctx.window.location.href,'');
});
test('subscription sorting is stable, null-safe and never mutates the stored list',()=>{
 const ctx={localStorage:{v:'',getItem(){return this.v;}}};vm.createContext(ctx);
 vm.runInContext(functionSource('var HUB_SOURCE_SORTS','renderSubscriptions=function'),ctx);
 const list=[
  {id:'a',title:'Zeta',enabled:1,status:'ok',last_finished_at:100,imported:5},
  {id:'b',title:'alpha 10',enabled:1,status:'error',last_finished_at:300,imported:0},
  {id:'c',title:'alpha 2',enabled:0,status:'ok',last_finished_at:0,imported:50},
  {id:'d',title:null,enabled:1,status:'partial',imported:null},
  {id:'e',title:'Mid',enabled:1,status:'syncing',last_finished_at:200,imported:5}];
 const ids=m=>ctx.hubSortSources(list,m).map(s=>s.id).join('');
 assert.equal(ids('default'),'abcde');
 assert.equal(ids('title'),'dcbea');      // empty title first; 'alpha 2' before 'alpha 10' (numeric); Mid; Zeta
 assert.equal(ids('recent'),'beadc');     // 300, 200, 100, then the two never-synced by title (empty title first)
 assert.equal(ids('failed'),'bdeac');     // error, partial, syncing, ok, paused last
 assert.equal(ids('imported'),'ceadb');   // 50; 5 and 5 tie -> by title (Mid, Zeta); then 0 and null by title
 assert.equal(list.map(s=>s.id).join(''),'abcde');                        // original order untouched
 assert.equal(ctx.hubSortSources(null,'title').length,0);
 ctx.localStorage.v='bogus';assert.equal(ctx.hubSourceSortMode(),'default');ctx.localStorage.v='failed';assert.equal(ctx.hubSourceSortMode(),'failed');
});
test('retry-failed selects only enabled, idle sources that failed, and skips syncing or busy ones',()=>{
 const ctx={};vm.createContext(ctx);vm.runInContext(functionSource('function hubFailedSources','var hubFailedRunning'),ctx);
 const list=[
  {id:'ok',enabled:1,status:'ok'},{id:'err',enabled:1,status:'error'},{id:'part',enabled:1,status:'partial'},
  {id:'paused',enabled:0,status:'error'},{id:'busy',enabled:1,status:'error'},{id:'running',enabled:1,status:'syncing',last_error:'x'},
  {id:'stale',enabled:1,status:'ok',last_error:'last item failed'},{id:'idle',enabled:1,status:'idle'}];
 assert.deepEqual(ctx.hubFailedSources(list,{busy:true}).map(s=>s.id),['err','part','stale']);
 assert.deepEqual(ctx.hubFailedSources(list,null).map(s=>s.id),['err','part','busy','stale']);
 assert.equal(ctx.hubFailedSources(null,null).length,0);
});
test('retry-failed syncs one source at a time and reports how many still fail',async()=>{
 const order=[],toasts=[];let state={subscriptions:[
  {id:'a',enabled:1,status:'error'},{id:'b',enabled:1,status:'ok'},{id:'c',enabled:1,status:'partial'},{id:'d',enabled:1,status:'error'}]};
 const ctx={state,sourceSyncing:{},toast:m=>toasts.push(m),renderSubscriptions(){},document:{querySelector(){return null;}},
  syncSource:async id=>{order.push('start '+id);await Promise.resolve();order.push('end '+id);ctx.state.subscriptions.find(s=>s.id===id).status=id==='d'?'error':'ok';}};
 vm.createContext(ctx);vm.runInContext(functionSource('function hubFailedSources','renderSubscriptions=function'),ctx);
 await ctx.hubSyncFailed();
 assert.deepEqual(order,['start a','end a','start c','end c','start d','end d']);   // never overlapping, ok source untouched
 assert.match(toasts.at(-1),/已重试 3 个：成功 2 个，仍失败 1 个/);
 toasts.length=0;ctx.state.subscriptions.forEach(s=>s.status='ok');await ctx.hubSyncFailed();assert.match(toasts[0],/没有需要重新同步/);
});
