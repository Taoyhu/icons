import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fetchCapped} from './worker.js';

test('external fetch uses one 60-second budget across redirects and preserves bytes',async t=>{
 const controller=new AbortController(),timeouts=[],signals=[];
 t.mock.method(AbortSignal,'timeout',ms=>{timeouts.push(ms);return controller.signal;});
 const bytes=new Uint8Array([0,255,128,65]);
 t.mock.method(globalThis,'fetch',async(url,opts)=>{
  signals.push(opts.signal);assert.equal(opts.redirect,'manual');
  return signals.length===1?new Response(null,{status:302,headers:{location:'/actual.js'}}):new Response(bytes);
 });
 assert.deepEqual(new Uint8Array(await fetchCapped('https://example.com/widget.js',100)),bytes);
 assert.deepEqual(timeouts,[60000]);assert.equal(signals.length,2);assert.ok(signals.every(s=>s===controller.signal));
});
test('header timeout reports a Chinese message',async t=>{
 const controller=new AbortController();
 t.mock.method(AbortSignal,'timeout',()=>controller.signal);
 t.mock.method(globalThis,'fetch',async()=>{controller.abort(new DOMException('timeout','TimeoutError'));throw controller.signal.reason;});
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/读取外部链接超时（60 秒）/);
});
test('timeout during body download also reports the same Chinese message',async t=>{
 const controller=new AbortController();
 t.mock.method(AbortSignal,'timeout',()=>controller.signal);
 t.mock.method(globalThis,'fetch',async()=>new Response(new ReadableStream({pull(c){controller.abort(new DOMException('timeout','TimeoutError'));c.error(controller.signal.reason);}})));
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/读取外部链接超时（60 秒）/);
});
test('HTTP errors and size limits are not mislabeled as timeouts',async t=>{
 t.mock.method(globalThis,'fetch',async()=>new Response(null,{status:404}));
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/Failed to fetch: 404/);
 globalThis.fetch.mock.mockImplementation(async()=>new Response('large',{headers:{'content-length':'101'}}));
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/文件过大/);
 globalThis.fetch.mock.mockImplementation(async()=>new Response(new Uint8Array(101)));
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/文件过大/);
});
test('private destinations remain blocked, including redirects',async t=>{
 let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return new Response(null,{status:302,headers:{location:'http://127.0.0.1/widget.js'}});});
 await assert.rejects(fetchCapped('http://127.0.0.1/widget.js',100),/不允许的地址/);assert.equal(calls,0);
 await assert.rejects(fetchCapped('https://example.com/widget.js',100),/不允许的地址/);assert.equal(calls,1);
});
