const names=['rex-mulberry-v1-192.png','rex-mulberry-v1-512.png','rex-mulberry-v1-maskable-192.png','rex-mulberry-v1-maskable-512.png','rex-mulberry-v1-180.png','rex-mulberry-v1-32.png','rex-mulberry-v1-16.png','favicon.ico'];
const manifest={id:'/',name:'Rex Widgets Hub',short_name:'Rex Hub',description:'Rex 模块与合集管理',lang:'zh-CN',start_url:'/',scope:'/',display:'standalone',background_color:'#f2f2f6',theme_color:'#f2f2f6',icons:names.slice(0,4).map(n=>({src:'/app-icons/'+n,sizes:n.includes('192')?'192x192':'512x512',type:'image/png',purpose:n.includes('maskable')?'maskable':'any'}))};
export async function pwaResponse(request,env){
  const path=new URL(request.url).pathname,isManifest=path==='/manifest.webmanifest';
  const name=path==='/favicon.ico'?'favicon.ico':path.startsWith('/app-icons/')?path.slice(11):'';
  if(!isManifest&&!names.includes(name))return null;
  if(!['GET','HEAD'].includes(request.method))return new Response(null,{status:405,headers:{Allow:'GET, HEAD'}});
  const headers={'Content-Type':isManifest?'application/manifest+json; charset=utf-8':name.endsWith('.ico')?'image/x-icon':'image/png','Cache-Control':isManifest||path==='/favicon.ico'?'no-cache':'public, max-age=31536000, immutable','X-Content-Type-Options':'nosniff'};
  if(isManifest)return new Response(request.method==='HEAD'?null:JSON.stringify(manifest),{headers});
  const resource=await env.ASSETS.fetch(new Request(new URL('/app-icons/'+name,request.url),{method:request.method}));
  const resultHeaders=new Headers(resource.headers);for(const [key,value] of Object.entries(headers))resultHeaders.set(key,value);
  return new Response(resource.body,{status:resource.status,headers:resultHeaders});
}
