import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fixture} from './test-fixtures/platform.mjs';
import {HubCoordinator} from './worker.js';
import {safeFilename,validateFilename,contentDisposition,downloadFilename,modulePath} from './filenames.js';
import {collectionOption,fillAutoAll,assertAutoAllCapacity} from './auto-all.js';
import {replaceMembers,memberIds} from './management.js';

const bytes=Buffer.concat([Buffer.from('REXENC\n'),Buffer.from([0,255,128,13,10,91,93,9])]);
const code=(id,v=1)=>`var WidgetMetadata={id:'${id}',title:'REX 模块标题',version:'${v}'};function load(){return '${v}';}`;
async function app(){
 const f=await fixture(),pending=[];
 f.sql.prepare('INSERT INTO sessions VALUES(?,?,?)').run('test-session',Date.now(),Date.now()+3600000);
 const worker=new HubCoordinator({waitUntil:p=>pending.push(p)},f.env);
 f.call=async(path,{method='GET',json,body,auth=true}={})=>worker.fetch(new Request('https://hub.example'+path,{method,
   headers:{...(auth?{cookie:'fwh_admin=test-session'}:{}),...(json?{'content-type':'application/json'}:{})},body:json?JSON.stringify(json):body}));
 f.ok=async(path,options)=>{const r=await f.call(path,options),data=await r.json();assert.ok(r.ok,JSON.stringify(data));return data;};
 f.preview=async(file,target='')=>{const body=new FormData();body.append('files',file);if(target)body.append('target_id',target);return f.ok('/api/admin/modules/upload/preview',{method:'POST',body});};
 f.commit=async(file,p,filename)=>{const row=p.rows[0],body=new FormData();
  for(const [key,value] of Object.entries({job_id:p.job_id,index:'0',action:row.target?'replace':'new',target_id:row.target?.id||'',mode:'temporary'}))body.append(key,value);
  if(filename!==undefined)body.append('filename',filename);body.append('file',file);
  return f.ok('/api/admin/modules/upload/commit',{method:'POST',body});};
 f.upload=async(name,content=bytes,filename,target)=>{const file=new File([content],name),p=await f.preview(file,target);return f.commit(file,p,filename);};
 return f;
}
async function restore(f,data){
 const body=structuredClone(data),resources=[];
 function append(id,file){const value=file.encoding==='base64'?Buffer.from(file.content,'base64'):Buffer.from(file.content);file.size=value.length;file.hash=createHash('sha256').update(value).digest('hex');delete file.content;resources.push({id,value});}
 for(const [id,file] of Object.entries(body.files))append('module:'+id,file);
 for(const p of body.meta.previousVersions||[])append('previous:'+p.module_id,p);
 for(const a of body.meta.icons?.assets||[])append('icon:'+a.hash,a);
 const job=await f.ok('/api/admin/backup/restore/start',{method:'POST',json:body});
 for(const r of resources)await f.ok('/api/admin/backup/restore/'+job.job_id+'/files/'+encodeURIComponent(r.id),{method:'PUT',body:r.value});
 return f.ok('/api/admin/backup/restore/'+job.job_id+'/commit',{method:'POST',json:{}});
}

test('filename rules and download titles are safe, readable, bounded and never invent encrypted versions',()=>{
 assert.equal(safeFilename('REX__视频-reX - 4K.js','id',true),'视频-4K.js');
 assert.equal(safeFilename('pREXfix.JS','id',true),'pfix.js');
 assert.equal(safeFilename('rex.js','abcd-1234',true),'module-abcd1234.js');
 assert.ok([...safeFilename('字'.repeat(180)+'.js')].length<=153);
 for(const name of ['../a.js','a\r\n.js','bad.txt','.js','a/b.js'])assert.throws(()=>validateFilename(name));
 assert.doesNotThrow(()=>contentDisposition(safeFilename('\ud800.js')));
 assert.match(contentDisposition('视频.js',true),/^attachment; filename="__\.js"; filename\*=UTF-8''%/);
 const mod={id:'abc',filename:'abc.js',manifest_title:'Javheo',is_encrypted:1};
 assert.equal(downloadFilename(mod),'Javheo.js');
 for(const title of ['Javheo-v1.3.2','Javheo 1.3.2','Javheo (v1.3.2)','Javheo[v1.3.2]'])
  assert.equal(downloadFilename({...mod,manifest_title:title,version:'1.3.2'}),'Javheo-v1.3.2.js');
 assert.equal(downloadFilename({...mod,title_locked:1,title:'我的模块',version:'2.0'}),'我的模块-v2.0.js');
 assert.equal(modulePath({id:'old'}),'/api/modules/old.js');
});

test('authenticated download keeps exact encrypted bytes, accepted names and all legacy routes',async()=>{
 const f=await app(),added=await f.upload('REX__视频.js'),id=added.module_id;
 assert.equal(added.effective_filename,'视频.js');
 await f.ok('/api/admin/collections',{method:'POST',json:{slug:'stable',title:'我的合集',moduleIds:[id]}});
 const m=(await f.ok('/api/admin/modules'))[0],endpoint='/api/admin/modules/'+id+'/download';
 assert.equal((await f.call(endpoint,{auth:false})).status,401);
 assert.equal((await f.call(endpoint,{method:'POST'})).status,405);
 const r=await f.call(endpoint);assert.match(r.headers.get('content-disposition'),/attachment;.*UTF-8''%E8%A7%86%E9%A2%91\.js/);
 assert.equal(r.headers.get('content-length'),String(bytes.length));assert.deepEqual(Buffer.from(await r.arrayBuffer()),bytes);
 for(const path of [m.public_path,'/api/modules/'+id+'/raw','/api/modules/'+id+'.js','/'+id+'.js']){
  const raw=await f.call(path,{auth:false});assert.equal(raw.status,200,path);assert.deepEqual(Buffer.from(await raw.arrayBuffer()),bytes);
  const head=await f.call(path,{auth:false,method:'HEAD'});assert.equal(head.status,200);assert.equal((await head.arrayBuffer()).byteLength,0);
 }
 const widgets=(await f.ok('/api/collections/stable.rex')).widgets;
 assert.equal(widgets[0].id,m.widget_id);assert.equal(widgets[0].url,'https://hub.example'+m.public_path);
 const version=m.file_key;await f.call(endpoint);assert.equal(f.sql.prepare('SELECT file_key FROM modules WHERE id=?').get(id).file_key,version);
});

test('cleaned collisions never merge modules, while historical source filenames keep replacement identity',async()=>{
 const f=await app(),a=await f.upload('REX-video.js'),b=await f.upload('video.js',Buffer.from('REXENC\nsecond encrypted payload'));
 assert.notEqual(a.module_id,b.module_id);assert.equal(a.effective_filename,'video.js');assert.match(b.effective_filename,/^video-[a-f0-9]{8}\.js$/);
 await f.upload('new-source.js',Buffer.from('REXENC\nupdated payload'),'我的名字.js',a.module_id);
 const file=new File(['REXENC\nthird encrypted payload'],'REX-video.js'),p=await f.preview(file);
 assert.equal(p.rows[0].target.id,a.module_id);assert.equal(p.rows[0].effective_filename,'我的名字.js');
 await f.commit(file,p);const modules=await f.ok('/api/admin/modules');assert.equal(modules.length,2);
 const accepted=modules.find(m=>m.id===a.module_id);assert.equal(accepted.effective_filename,'我的名字.js');assert.ok(accepted.original_filenames.includes('new-source.js'));
});

test('existing modules stay unchanged until explicit repair; stale scans reject all writes and old named links survive',async()=>{
 const f=await app();await f.ok('/api/admin/filename-settings',{method:'PATCH',json:{auto_clean:false}});
 const a=await f.upload('A_REX.js',code('a')),b=await f.upload('B_rex.js',code('b'));
 await f.ok('/api/admin/filename-settings',{method:'PATCH',json:{auto_clean:true}});
 const before=(await f.ok('/api/admin/modules')).find(m=>m.id===a.module_id);assert.equal(before.effective_filename,'A_REX.js');
 let rows=(await f.ok('/api/admin/modules/filenames')).rows;assert.equal(rows.length,2);
 f.sql.prepare('UPDATE modules SET updated_at=updated_at+1 WHERE id=?').run(a.module_id);
 let response=await f.call('/api/admin/modules/filenames',{method:'POST',json:{rows:rows.map(r=>({...r,filename:r.suggested}))}});
 assert.equal(response.status,409);assert.equal(f.sql.prepare('SELECT filename FROM module_names WHERE module_id=?').get(b.module_id).filename,'B_rex.js');
 rows=(await f.ok('/api/admin/modules/filenames')).rows;
 await f.ok('/api/admin/modules/filenames',{method:'POST',json:{rows:rows.map(r=>({...r,filename:r.suggested}))}});
 const after=(await f.ok('/api/admin/modules')).find(m=>m.id===a.module_id);
 for(const key of ['id','filename','widget_id','file_key','content_hash','sort_order','group_id'])assert.equal(after[key],before[key]);
 assert.equal(after.effective_filename,'A.js');assert.equal((await f.call(before.public_path)).status,200);
 assert.equal((await f.ok('/api/admin/modules/filenames')).rows.length,0);
});

test('URL and subscription naming preserve accepted names, ids, bytes and download title across upstream changes',async t=>{
 let version='1.3.2',name='REX-%E8%A7%86%E9%A2%91.js';
 t.mock.method(globalThis,'fetch',async url=>new Response(String(url).endsWith('.rex')?JSON.stringify({title:'订阅',widgets:[{id:'remote',title:'Javheo',version,url:'https://modules.example/'+name}]}):bytes));
 const f=await app(),preview=await f.ok('/api/admin/filename-preview',{method:'POST',json:{url:'https://modules.example/'+name}});
 assert.equal(preview.original,'REX-视频.js');assert.equal(preview.suggested,'视频.js');
 const imported=await f.ok('/api/admin/modules/import',{method:'POST',json:{url:'https://modules.example/'+name}}),before=imported.added[0];
 const source=(await f.ok('/api/admin/modules/import',{method:'POST',json:{url:'https://modules.example/source.rex'}})).subscription.id;
 async function cycle(){for(let n=0;n<5;n++)if((await f.ok('/api/admin/subscriptions/'+source+'/sync',{method:'POST'})).done)return;throw Error('sync incomplete');}
 await cycle();version='1.3.3';name='other-REX.js';await cycle();
 const m=(await f.ok('/api/admin/modules'))[0];assert.equal(m.id,before.id);assert.equal(m.effective_filename,before.effective_filename);assert.equal(m.public_path,before.public_path);
 const download=await f.call('/api/admin/modules/'+m.id+'/download');assert.match(download.headers.get('content-disposition'),/Javheo-v1.3.3.js/);assert.deepEqual(Buffer.from(await download.arrayBuffer()),bytes);
});

test('format 7 restores names, settings, auto-all and bytes, rejects malformed names; formats 5/6 remain readable',async()=>{
 const f=await app(),a=await f.upload('REX-file.js',code('a'),'我的名字.js');
 await f.ok('/api/admin/filename-settings',{method:'PATCH',json:{auto_clean:false}});
 await f.ok('/api/admin/collections',{method:'POST',json:{slug:'all',title:'全部',autoAll:true}});
 const saved=await f.ok('/api/admin/backup');assert.equal(saved.format,7);assert.equal(saved.meta.names.length,1);
 const other=await app();await restore(other,saved);
 const m=(await other.ok('/api/admin/modules'))[0];assert.equal(m.id,a.module_id);assert.equal(m.effective_filename,'我的名字.js');
 assert.equal((await other.ok('/api/admin/filename-settings')).auto_clean,false);assert.equal((await other.ok('/api/admin/collections'))[0].autoAll,true);
 assert.equal(await (await other.call(m.public_path)).text(),code('a'));
 const six=structuredClone(saved);six.format=6;delete six.meta.shareAliases;
 const previous=await app();await restore(previous,six);assert.equal((await previous.ok('/api/admin/modules'))[0].effective_filename,'我的名字.js');
 const bad=structuredClone(saved);bad.meta.names[0].filename='../bad.js';await assert.rejects(()=>restore(other,bad),/文件名/);
 assert.equal((await other.ok('/api/admin/modules'))[0].effective_filename,'我的名字.js');
 const legacy=structuredClone(saved);legacy.format=5;delete legacy.meta.names;delete legacy.meta.filenameSettings;
 const old=await app();await restore(old,legacy);assert.equal((await old.ok('/api/admin/modules'))[0].effective_filename,'REX-file.js');
 await other.ok('/api/admin/modules?id='+a.module_id,{method:'DELETE'});assert.equal((await other.ok('/api/admin/backup')).meta.names.length,0);
});

test('automatic collections are opt-in, preserve order, include only new modules and prevent partial removal',async()=>{
 const f=await app(),a=await f.upload('a.js',code('a')),b=await f.upload('b.js',code('b'));
 const normal=await f.ok('/api/admin/collections',{method:'POST',json:{slug:'normal',title:'手动',moduleIds:[b.module_id]}});
 const all=await f.ok('/api/admin/collections',{method:'POST',json:{slug:'all',title:'全部',autoAll:true,moduleIds:[b.module_id]}});
 assert.deepEqual(await memberIds(f.env.DB,all.id),[b.module_id,a.module_id]);
 await f.env.DB.batch([fillAutoAll(f.env.DB,all.id)]);assert.deepEqual(await memberIds(f.env.DB,all.id),[b.module_id,a.module_id]);
 const c=await f.upload('c.js',code('c'));assert.deepEqual(await memberIds(f.env.DB,all.id),[b.module_id,a.module_id,c.module_id]);assert.deepEqual(await memberIds(f.env.DB,normal.id),[b.module_id]);
 await assert.rejects(()=>replaceMembers(f.env,all.id,[a.module_id]),/先关闭/);
 await f.ok('/api/admin/collections',{method:'PATCH',json:{id:all.id,autoAll:false}});
 await replaceMembers(f.env,all.id,[a.module_id]);await f.upload('d.js',code('d'));assert.deepEqual(await memberIds(f.env.DB,all.id),[a.module_id]);
});

test('auto-all fill assigns stable distinct positions, enforces 1000 and rolls back failed collection creation',async t=>{
 const f=await app();f.sql.exec("INSERT INTO collections VALUES('all','all','all','','',0,0)");
 for(let n=0;n<1000;n++)f.sql.prepare('INSERT INTO modules(id,filename,sort_order,created_at) VALUES(?,?,?,?)').run('m'+n,'m'+n+'.js',n,n);
 await f.env.DB.batch([await collectionOption(f.env.DB,'all',true),fillAutoAll(f.env.DB,'all')]);
 const positions=f.sql.prepare('SELECT position FROM collection_modules ORDER BY position').all().map(r=>r.position);assert.deepEqual(positions,Array.from({length:1000},(_,i)=>i));
 await assert.rejects(()=>assertAutoAllCapacity(f.env.DB,1),/1000/);
 f.sql.exec("INSERT INTO modules(id,filename) VALUES('overflow','overflow.js')");
 await assert.rejects(()=>collectionOption(f.env.DB,'other',true),/1000/);
 await f.env.DB.batch([await collectionOption(f.env.DB,'all',false)]);
 t.mock.method(console,'error',()=>{});f.fail();const response=await f.call('/api/admin/collections',{method:'POST',json:{slug:'broken',title:'broken'}});assert.equal(response.status,500);
 assert.equal(f.sql.prepare("SELECT COUNT(*) AS n FROM collections WHERE slug='broken'").get().n,0);
});

test('parallel subscription downloads serialize colliding cleaned names without merging module IDs',async t=>{
 t.mock.method(globalThis,'fetch',async url=>new Response(String(url).endsWith('.rex')?JSON.stringify({title:'订阅',widgets:[
  {id:'remote-a',url:'https://modules.example/REX-video.js'},
  {id:'remote-b',url:'https://modules.example/video.js'}]}):bytes));
 const f=await app(),source=(await f.ok('/api/admin/modules/import',{method:'POST',json:{url:'https://modules.example/collision.rex'}})).subscription.id;
 await f.ok('/api/admin/subscriptions/'+source+'/sync',{method:'POST'});
 f.resetCount();const result=await f.ok('/api/admin/subscriptions/'+source+'/sync',{method:'POST'});assert.equal(result.summary.failed,0);assert.equal(result.summary.added,2);
 assert.ok(f.counts().queries<60,'bounded per-request database work: '+f.counts().queries);
 const modules=await f.ok('/api/admin/modules');assert.equal(modules.length,2);assert.notEqual(modules[0].effective_filename,modules[1].effective_filename);
});

test('manual refresh works once without re-enabling automatic updates or changing the accepted filename',async t=>{
 let version=1;t.mock.method(globalThis,'fetch',async()=>new Response(code('source',version)));
 const f=await app(),r=await f.ok('/api/admin/modules/import',{method:'POST',json:{url:'https://modules.example/REX-source.js'}}),m=r.added[0];
 await f.ok('/api/admin/modules/'+m.id+'/maintenance',{method:'PATCH',json:{manual:true}});version=2;
 await f.ok('/api/admin/modules/'+m.id+'/refresh',{method:'POST'});
 const updated=(await f.ok('/api/admin/modules'))[0];assert.equal(updated.manual_override,1);assert.equal(updated.version,'2');assert.equal(updated.effective_filename,m.effective_filename);
 assert.equal(await (await f.call(updated.public_path)).text(),code('source',2));
});

test('pre-v3.2 schema upgrade does not rename existing modules or rewrite legacy manifest URLs',async()=>{
 const f=await app(),a=await f.upload('Legacy-REX.js',code('old'));
 f.sql.exec("DROP TABLE module_names;DROP TABLE collection_options;DELETE FROM settings WHERE key='schema_cf_v32_1'");
 // A fresh DB binding models a new Worker instance, bypassing warm-isolate schema caches.
 const env={...f.env,DB:{...f.env.DB}},worker=new HubCoordinator({waitUntil(){}},env);
 const r=await worker.fetch(new Request('https://hub.example/api/admin/modules',{headers:{cookie:'fwh_admin=test-session'}}));assert.equal(r.status,200);
 const m=(await r.json())[0];assert.equal(m.id,a.module_id);assert.equal(m.effective_filename,'Legacy-REX.js');assert.equal(m.public_path,'/api/modules/'+a.module_id+'.js');
});
